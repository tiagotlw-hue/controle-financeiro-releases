package com.controlefinanceiro.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import com.controlefinanceiro.app.data.ItemLista
import com.controlefinanceiro.app.viewmodel.AppViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val fmtData = SimpleDateFormat("dd/MM/yyyy", Locale("pt", "BR"))

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ListaScreen(
    viewModel: AppViewModel,
    aoVoltar: () -> Unit
) {
    val itens by viewModel.listaCompras
    var mostrarComprados by remember { mutableStateOf(false) }
    var itemParaEditar by remember { mutableStateOf<ItemLista?>(null) }
    var mostrarFormNovo by remember { mutableStateOf(false) }
    var itemParaExcluir by remember { mutableStateOf<ItemLista?>(null) }
    val snackbarHostState = remember { SnackbarHostState() }
    val erro = viewModel.erro.value

    LaunchedEffect(Unit) { viewModel.iniciarEscutaLista() }

    LaunchedEffect(erro) {
        if (erro != null) {
            snackbarHostState.showSnackbar(erro)
            viewModel.limparErro()
        }
    }

    val itensVisiveis = if (mostrarComprados) itens else itens.filterNot { it.comprado }
    val qtdComprados = itens.count { it.comprado }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Lista de compras") },
                navigationIcon = {
                    IconButton(onClick = aoVoltar) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Voltar")
                    }
                },
                actions = {
                    IconButton(onClick = { mostrarComprados = !mostrarComprados }) {
                        Icon(
                            if (mostrarComprados) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                            contentDescription = if (mostrarComprados)
                                "Ocultar já comprados"
                            else
                                "Mostrar já comprados"
                        )
                    }
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        floatingActionButton = {
            FloatingActionButton(onClick = { mostrarFormNovo = true }) {
                Icon(Icons.Default.Add, contentDescription = "Novo item")
            }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            if (!mostrarComprados && qtdComprados > 0) {
                Text(
                    "$qtdComprados já comprado${if (qtdComprados > 1) "s" else ""} oculto${if (qtdComprados > 1) "s" else ""}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                )
            }
            if (itensVisiveis.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(
                        if (itens.isEmpty())
                            "Nenhum item na lista ainda. Toque em + para adicionar."
                        else
                            "Tudo comprado! 🎉",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                LazyColumn(Modifier.fillMaxSize()) {
                    items(itensVisiveis, key = { it.id }) { item ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { itemParaEditar = item }
                                .padding(horizontal = 16.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = item.comprado,
                                onCheckedChange = { marcado ->
                                    viewModel.marcarItemListaComprado(item.id, marcado)
                                }
                            )
                            Column(Modifier.weight(1f)) {
                                Text(
                                    item.descricao,
                                    style = MaterialTheme.typography.bodyLarge,
                                    textDecoration = if (item.comprado) TextDecoration.LineThrough else null,
                                    color = if (item.comprado)
                                        MaterialTheme.colorScheme.onSurfaceVariant
                                    else
                                        MaterialTheme.colorScheme.onSurface
                                )
                                if (item.observacao.isNotBlank()) {
                                    Text(
                                        item.observacao,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Text(
                                    if (item.comprado && item.dataComprado != null)
                                        "Registrado ${fmtData.format(Date(item.dataCriacao))} · comprado ${fmtData.format(Date(item.dataComprado))}"
                                    else
                                        "Registrado ${fmtData.format(Date(item.dataCriacao))}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            if (item.valorLimite != null) {
                                Text(
                                    "até R$ %.2f".format(item.valorLimite),
                                    style = MaterialTheme.typography.bodySmall,
                                    fontWeight = FontWeight.Medium
                                )
                                Spacer(Modifier.width(4.dp))
                            }
                            IconButton(onClick = { itemParaExcluir = item }) {
                                Icon(Icons.Default.Delete, contentDescription = "Excluir item")
                            }
                        }
                        HorizontalDivider()
                    }
                }
            }
        }
    }

    if (mostrarFormNovo) {
        FormItemListaDialog(
            item = null,
            onDismiss = { mostrarFormNovo = false },
            onSalvar = { descricao, observacao, valorLimite ->
                viewModel.salvarItemLista(descricao, observacao, valorLimite) {
                    mostrarFormNovo = false
                }
            }
        )
    }

    itemParaEditar?.let { item ->
        FormItemListaDialog(
            item = item,
            onDismiss = { itemParaEditar = null },
            onSalvar = { descricao, observacao, valorLimite ->
                viewModel.editarItemLista(item, descricao, observacao, valorLimite) {
                    itemParaEditar = null
                }
            }
        )
    }

    itemParaExcluir?.let { item ->
        AlertDialog(
            onDismissRequest = { itemParaExcluir = null },
            title = { Text("Excluir item") },
            text = { Text("Tem certeza que deseja excluir \"${item.descricao}\" da lista?") },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.excluirItemLista(item.id)
                    itemParaExcluir = null
                }) { Text("Excluir") }
            },
            dismissButton = {
                TextButton(onClick = { itemParaExcluir = null }) { Text("Cancelar") }
            }
        )
    }
}

@Composable
private fun FormItemListaDialog(
    item: ItemLista?,
    onDismiss: () -> Unit,
    onSalvar: (descricao: String, observacao: String, valorLimite: Double?) -> Unit
) {
    var descricao by remember { mutableStateOf(item?.descricao ?: "") }
    var observacao by remember { mutableStateOf(item?.observacao ?: "") }
    var valorLimiteTexto by remember {
        mutableStateOf(item?.valorLimite?.let { "%.2f".format(it).replace(".", ",") } ?: "")
    }
    var tentouSalvar by remember { mutableStateOf(false) }
    val descricaoInvalida = tentouSalvar && descricao.isBlank()

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (item == null) "Novo item" else "Editar item") },
        text = {
            Column {
                OutlinedTextField(
                    value = descricao,
                    onValueChange = { descricao = it },
                    label = { Text("O que precisa comprar *") },
                    isError = descricaoInvalida,
                    supportingText = { if (descricaoInvalida) Text("Campo obrigatório") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = observacao,
                    onValueChange = { observacao = it },
                    label = { Text("Observação") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(
                    value = valorLimiteTexto,
                    onValueChange = { valorLimiteTexto = it },
                    label = { Text("Valor limite") },
                    prefix = { Text("R$") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                tentouSalvar = true
                if (descricao.isNotBlank()) {
                    val valorLimite = valorLimiteTexto.replace(",", ".").toDoubleOrNull()
                    onSalvar(descricao.trim(), observacao.trim(), valorLimite)
                }
            }) { Text("Salvar") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancelar") }
        }
    )
}
