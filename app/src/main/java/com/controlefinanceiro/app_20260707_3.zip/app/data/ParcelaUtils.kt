package com.controlefinanceiro.app.data

import java.util.Calendar
import java.util.UUID
import kotlin.math.min
import kotlin.math.round

object ParcelaUtils {

    /**
     * Gera as parcelas/duplicatas de uma movimentação paga em dinheiro.
     * Cada parcela vence sempre no mesmo "diaVencimento" (ex: dia 15),
     * começando no mês seguinte à criação. Se o mês não tiver esse dia
     * (ex: dia 31 em fevereiro), usa o último dia do mês.
     * A diferença de arredondamento é jogada na última parcela.
     */
    fun gerarParcelas(
        valorTotal: Double,
        numParcelas: Int,
        dataCriacao: Long,
        diaVencimento: Int
    ): List<Parcela> {
        require(numParcelas >= 1) { "Número de parcelas deve ser >= 1" }
        val calendarBase = Calendar.getInstance().apply { timeInMillis = dataCriacao }
        return gerarParcelasAPartirDoMesBase(valorTotal, numParcelas, calendarBase, diaVencimento, offsetMeses = 1)
    }

    /**
     * Gera as parcelas/duplicatas de uma movimentação paga no cartão, seguindo a regra
     * de fechamento de fatura: se o dia da compra for >= "melhorDia" (dia de fechamento),
     * a primeira parcela vai pra fatura que vence no "diaVencimento" do mês SEGUINTE ao da
     * compra. Se for antes do "melhorDia", vai pra fatura que vence no "diaVencimento" do
     * MESMO mês da compra. As parcelas seguintes vencem sempre um mês depois da anterior.
     */
    fun gerarParcelasCartao(
        valorTotal: Double,
        numParcelas: Int,
        dataCriacao: Long,
        melhorDia: Int,
        diaVencimentoCartao: Int
    ): List<Parcela> {
        require(numParcelas >= 1) { "Número de parcelas deve ser >= 1" }
        val calCompra = Calendar.getInstance().apply { timeInMillis = dataCriacao }
        val diaCompra = calCompra.get(Calendar.DAY_OF_MONTH)
        val calBase = calCompra.clone() as Calendar
        if (diaCompra >= melhorDia) {
            calBase.add(Calendar.MONTH, 1)
        }
        return gerarParcelasAPartirDoMesBase(valorTotal, numParcelas, calBase, diaVencimentoCartao, offsetMeses = 0)
    }

    private fun gerarParcelasAPartirDoMesBase(
        valorTotal: Double,
        numParcelas: Int,
        calendarBase: Calendar,
        diaVencimento: Int,
        offsetMeses: Int
    ): List<Parcela> {
        val valorParcelaBase = round((valorTotal / numParcelas) * 100) / 100.0
        val parcelas = mutableListOf<Parcela>()
        var somaAcumulada = 0.0

        for (i in 1..numParcelas) {
            val cal = calendarBase.clone() as Calendar
            cal.add(Calendar.MONTH, offsetMeses + (i - 1))
            val ultimoDiaDoMes = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
            cal.set(Calendar.DAY_OF_MONTH, min(diaVencimento, ultimoDiaDoMes))
            cal.set(Calendar.HOUR_OF_DAY, 0)
            cal.set(Calendar.MINUTE, 0)
            cal.set(Calendar.SECOND, 0)
            cal.set(Calendar.MILLISECOND, 0)

            val valorDaParcela = if (i == numParcelas) {
                round((valorTotal - somaAcumulada) * 100) / 100.0
            } else {
                valorParcelaBase
            }
            somaAcumulada += valorDaParcela

            parcelas.add(
                Parcela(
                    numero = i,
                    valorOriginal = valorDaParcela,
                    dataVencimento = cal.timeInMillis
                )
            )
        }
        return parcelas
    }

    /**
     * Dado o valor digitado, seleciona automaticamente as parcelas em aberto mais antigas
     * (já ordenadas) até esse valor se esgotar. Usado tanto para pré-seleção automática
     * quanto para saber o total das parcelas marcadas manualmente.
     */
    fun selecionarMaisAntigasAte(abertasOrdenadas: List<ParcelaRef>, valor: Double): Set<Pair<String, Int>> {
        val selecionadas = mutableSetOf<Pair<String, Int>>()
        var restante = valor
        for (ref in abertasOrdenadas) {
            if (restante <= 0.0) break
            val faltante = round((ref.parcela.valorOriginal - ref.parcela.valorPago) * 100) / 100.0
            selecionadas.add(ref.movimentacaoId to ref.parcela.numero)
            restante -= faltante
        }
        return selecionadas
    }

    /**
     * Aplica uma baixa (pagamento/recebimento) espalhando o valor pelas parcelas
     * selecionadas, na ordem em que aparecem em `selecionadas`. Parcelas de várias
     * movimentações podem estar envolvidas (por isso o retorno é um mapa por movimentação).
     * Se o valor não cobrir tudo, a última parcela fica "parcial". Guarda quanto foi
     * aplicado em cada parcela (parcelasAplicadas), pra dar pra reverter a baixa depois.
     */
    fun aplicarBaixaConsolidada(
        movimentacoesPorId: Map<String, Movimentacao>,
        selecionadas: List<ParcelaRef>,
        valorPago: Double,
        descricaoManual: String = "",
        dataBaixa: Long = System.currentTimeMillis()
    ): Map<String, Movimentacao> {
        var restante = valorPago
        val agora = dataBaixa
        val resultado = mutableMapOf<String, Movimentacao>()
        // agrupa números de parcela e valor aplicado por movimentação, para montar o Pagamento
        val aplicadoPorMovimentacao = mutableMapOf<String, MutableMap<Int, Double>>()

        for (ref in selecionadas) {
            if (restante <= 0.0) break
            val mov = resultado[ref.movimentacaoId] ?: movimentacoesPorId[ref.movimentacaoId] ?: continue
            val parcelaAtual = mov.parcelas.firstOrNull { it.numero == ref.parcela.numero } ?: continue
            if (parcelaAtual.status == "paga") continue

            val faltante = round((parcelaAtual.valorOriginal - parcelaAtual.valorPago) * 100) / 100.0
            val valorAplicado = min(restante, faltante)
            restante = round((restante - valorAplicado) * 100) / 100.0

            val novoValorPago = round((parcelaAtual.valorPago + valorAplicado) * 100) / 100.0
            val novoStatus = if (novoValorPago >= parcelaAtual.valorOriginal - 0.005) "paga" else "parcial"

            val novasParcelas = mov.parcelas.map { p ->
                if (p.numero == parcelaAtual.numero) {
                    p.copy(valorPago = novoValorPago, status = novoStatus, dataUltimoPagamento = agora)
                } else p
            }
            aplicadoPorMovimentacao.getOrPut(ref.movimentacaoId) { mutableMapOf() }[parcelaAtual.numero] = valorAplicado
            resultado[ref.movimentacaoId] = mov.copy(parcelas = novasParcelas)
        }

        // adiciona o histórico de pagamento em cada movimentação afetada
        return resultado.mapValues { (movId, mov) ->
            val aplicado = aplicadoPorMovimentacao[movId].orEmpty()
            val numeros = aplicado.keys.sorted()
            val descricaoAuto = buildString {
                append("Baixa de R$ %.2f".format(valorPago))
                if (descricaoManual.isNotBlank()) append(" - $descricaoManual")
                append(". Parcelas ${numeros.joinToString(", ")} desta movimentação.")
            }
            mov.copy(
                historicoPagamentos = mov.historicoPagamentos + Pagamento(
                    id = UUID.randomUUID().toString(),
                    data = agora,
                    valorPago = round(aplicado.values.sum() * 100) / 100.0,
                    parcelasNumeros = numeros,
                    parcelasAplicadas = aplicado.mapKeys { it.key.toString() },
                    descricao = descricaoAuto
                )
            )
        }
    }

    /**
     * Reverte uma baixa específica: tira exatamente o valor que ela aplicou de cada
     * parcela afetada (usando parcelasAplicadas) e remove o registro do histórico.
     */
    fun reverterBaixa(movimentacao: Movimentacao, pagamento: Pagamento): Movimentacao {
        val novasParcelas = movimentacao.parcelas.map { p ->
            val valorAplicado = pagamento.parcelasAplicadas[p.numero.toString()] ?: 0.0
            if (valorAplicado > 0.0) {
                val novoValorPago = (round((p.valorPago - valorAplicado) * 100) / 100.0).coerceAtLeast(0.0)
                val novoStatus = when {
                    novoValorPago <= 0.005 -> "aberta"
                    novoValorPago < p.valorOriginal - 0.005 -> "parcial"
                    else -> "paga"
                }
                p.copy(valorPago = novoValorPago, status = novoStatus)
            } else p
        }
        return movimentacao.copy(
            parcelas = novasParcelas,
            historicoPagamentos = movimentacao.historicoPagamentos.filterNot { it.id == pagamento.id }
        )
    }
}
