package com.controlefinanceiro.app.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp

/** Um cálculo já feito, guardado no histórico (o que foi digitado + o resultado). */
private data class CalculoHistorico(val expressao: String, val resultado: String)

/** Mini calculadora flutuante, pensada para ficar disponível em todas as telas do
 *  app (é colocada uma única vez, no nível do MainActivity, por cima da tela atual).
 *
 *  Sem grade de botões: o usuário digita a conta pelo próprio teclado do celular
 *  (ex: "120+35*2") e aperta o "concluído"/enter do teclado para calcular. Suporta
 *  apenas soma, subtração, multiplicação e divisão — sem parênteses, sem outras
 *  funções.
 *
 *  Guarda as últimas 10 contas feitas (mais recente primeiro). Como o estado
 *  (expressão atual, histórico, expandida ou não) fica lembrado aqui, ele persiste
 *  enquanto o usuário navega de uma tela para outra dentro do app. */
@Composable
fun MiniCalculadora(modifier: Modifier = Modifier) {
    var expandida by remember { mutableStateOf(false) }
    var expressao by remember { mutableStateOf("") }
    var erro by remember { mutableStateOf(false) }
    var historico by remember { mutableStateOf(listOf<CalculoHistorico>()) }

    fun calcular() {
        val texto = expressao.trim()
        if (texto.isEmpty()) return
        val resultado = avaliarExpressao(texto)
        if (resultado == null) {
            erro = true
            return
        }
        erro = false
        val resultadoTexto = formatarResultado(resultado)
        historico = (listOf(CalculoHistorico(texto, resultadoTexto)) + historico).take(10)
        expressao = resultadoTexto
    }

    Surface(
        modifier = modifier.shadow(4.dp, RoundedCornerShape(16.dp)),
        shape = RoundedCornerShape(16.dp),
        tonalElevation = 4.dp,
        color = MaterialTheme.colorScheme.surfaceVariant
    ) {
        if (!expandida) {
            // Estado recolhido: só um "carimbo" pequeno pra não atrapalhar a tela.
            Box(
                Modifier
                    .size(44.dp)
                    .clickable { expandida = true },
                contentAlignment = Alignment.Center
            ) {
                Text("🧮", style = MaterialTheme.typography.titleMedium)
            }
        } else {
            Column(Modifier.padding(12.dp).width(210.dp)) {
                Row(
                    Modifier.fillMaxWidth().clickable { expandida = false },
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "Calculadora",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Text("✕", style = MaterialTheme.typography.labelLarge)
                }
                Spacer(Modifier.height(6.dp))
                OutlinedTextField(
                    value = expressao,
                    onValueChange = {
                        expressao = it
                        erro = false
                    },
                    singleLine = true,
                    placeholder = { Text("ex: 120+35*2") },
                    isError = erro,
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Text,
                        imeAction = ImeAction.Done
                    ),
                    keyboardActions = KeyboardActions(onDone = { calcular() }),
                    modifier = Modifier.fillMaxWidth()
                )
                if (erro) {
                    Text(
                        "Conta inválida",
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                if (historico.isNotEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    Text("Últimos 10 cálculos", style = MaterialTheme.typography.labelSmall)
                    LazyColumn(Modifier.heightIn(max = 180.dp)) {
                        items(historico) { calc ->
                            Text(
                                "${calc.expressao} = ${calc.resultado}",
                                style = MaterialTheme.typography.bodySmall,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { expressao = calc.resultado }
                                    .padding(vertical = 3.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

/** Avalia uma expressão simples com +, -, * e / (sem parênteses), respeitando a
 *  precedência: multiplicação e divisão primeiro, depois soma e subtração, sempre
 *  da esquerda para a direita. Retorna null se a expressão for inválida (sintaxe
 *  errada, vazia, ou divisão por zero). */
private fun avaliarExpressao(expressaoOriginal: String): Double? {
    val expr = expressaoOriginal.replace(" ", "").replace(",", ".")
    if (expr.isEmpty()) return null
    // Só números (com ponto decimal opcional) separados por um único operador +-*/,
    // com sinal de menos opcional só no começo (número negativo inicial).
    if (!expr.matches(Regex("^-?\\d+(\\.\\d+)?([+\\-*/]\\d+(\\.\\d+)?)*$"))) return null

    return try {
        val tokens = tokenizar(expr)

        // 1ª passada: resolve * e / da esquerda para a direita.
        val semMulDiv = mutableListOf(tokens[0])
        var i = 1
        while (i < tokens.size) {
            val op = tokens[i]
            val num = tokens[i + 1].toDouble()
            if (op == "*" || op == "/") {
                val anterior = semMulDiv.removeAt(semMulDiv.size - 1).toDouble()
                if (op == "/" && num == 0.0) return null
                val resultado = if (op == "*") anterior * num else anterior / num
                semMulDiv.add(resultado.toString())
            } else {
                semMulDiv.add(op)
                semMulDiv.add(tokens[i + 1])
            }
            i += 2
        }

        // 2ª passada: soma e subtração, da esquerda para a direita.
        var total = semMulDiv[0].toDouble()
        var j = 1
        while (j < semMulDiv.size) {
            val op = semMulDiv[j]
            val num = semMulDiv[j + 1].toDouble()
            total = if (op == "+") total + num else total - num
            j += 2
        }
        total
    } catch (e: Exception) {
        null
    }
}

/** Separa a expressão em números e operadores, tomando cuidado para não confundir
 *  um "-" de número negativo no início com um operador de subtração. */
private fun tokenizar(expr: String): List<String> {
    val tokens = mutableListOf<String>()
    var atual = StringBuilder()
    expr.forEachIndexed { indice, c ->
        if (c in "+-*/" && !(c == '-' && indice == 0)) {
            tokens.add(atual.toString())
            tokens.add(c.toString())
            atual = StringBuilder()
        } else {
            atual.append(c)
        }
    }
    tokens.add(atual.toString())
    return tokens
}

/** Formata o resultado sem casas decimais desnecessárias (ex: 10.0 -> "10"),
 *  senão com até 2 casas decimais (ex: 10.333... -> "10.33"). */
private fun formatarResultado(valor: Double): String {
    return if (valor == valor.toLong().toDouble()) {
        valor.toLong().toString()
    } else {
        "%.2f".format(valor)
    }
}
