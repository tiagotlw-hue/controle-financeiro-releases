package com.controlefinanceiro.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.controlefinanceiro.app.data.Movimentacao
import com.controlefinanceiro.app.data.ParcelaRef
import com.controlefinanceiro.app.data.ParcelaUtils
import com.controlefinanceiro.app.data.TipoMovimentacao
import com.controlefinanceiro.app.viewmodel.AppViewModel
import java.text.SimpleDateFormat
import java.util.Locale
import kotlin.math.round

private val fmtData = SimpleDateFormat("dd/MM/yyyy", Locale("pt", "BR"))

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SaidaScreen(
    viewModel: AppViewModel,
    clienteId: String,
    tipoInicial: String,
    movimentacaoIdFiltro: String? = null,
    aoVoltar: () -> Unit
) {
    val movimentacoes by viewModel.movimentacoes
    var tipo by remember { mutableStateOf(tipoInicial) }
    var valorTexto by remember { mutableStateOf("") }
    var descricaoManual by remember { mutableStateOf("") }
    var salvando by remember { mutableStateOf(false) }
    val snackbarHostState = remember { SnackbarHostState() }
    val erro = viewModel.erro.value

    LaunchedEffect(erro) {
        if (erro != null) {
            salvando = false
            snackbarHostState.showSnackbar(erro)
            viewModel.limparErro()
        }
    }

    // Junta as duplicatas em aberto de todas as movimentações desse tipo (mais antigas
    // primeiro) — ou só da movimentação específica, se veio da tela de extrato dela.
    val abertas = remember(movimentacoes, tipo, movimentacaoIdFiltro) {
        movimentacoes
            .filter { it.tipo == tipo && (movimentacaoIdFiltro == null || it.id == movimentacaoIdFiltro) }
            .flatMap { mov ->
                mov.parcelas.filter { it.status != "paga" }
                    .map { p -> ParcelaRef(mov.id, mov.descricao, p) }
            }
            .sortedBy { it.parcela.dataVencimento }
    }

    val valorPago = valorTexto.replace(",", ".").toDoubleOrNull() ?: 0.0

    var selecaoManualAtiva by remember { mutableStateOf(false) }
    var selecionadas by remember { mutableStateOf<Set<Pair<String, Int>>>(emptySet()) }

    LaunchedEffect(valorPago, selecaoManualAtiva, abertas) {
        if (!selecaoManualAtiva) {
            selecionadas = ParcelaUtils.selecionarMaisAntigasAte(abertas, valorPago)
        }
    }

    val totalSelecionado = abertas.filter { (it.movimentacaoId to it.parcela.numero) in selecionadas }
        .sumOf { it.parcela.valorOriginal - it.parcela.valorPago }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Saída — dar baixa") }) },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            if (movimentacaoIdFiltro == null) {
                SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                    SegmentedButton(
                        selected = tipo == TipoMovimentacao.RECEBER,
                        onClick = { tipo = TipoMovimentacao.RECEBER; selecaoManualAtiva = false },
                        shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2)
                    ) { Text("Receber (cliente pagando)") }
                    SegmentedButton(
                        selected = tipo == TipoMovimentacao.PAGAR,
                        onClick = { tipo = TipoMovimentacao.PAGAR; selecaoManualAtiva = false },
                        shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2)
                    ) { Text("Pagar (eu pagando)") }
                }
                Spacer(Modifier.height(12.dp))
            }

            OutlinedTextField(
                value = valorTexto,
                onValueChange = { valorTexto = it },
                label = { Text("Valor (R$)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(4.dp))
            OutlinedTextField(
                value = descricaoManual,
                onValueChange = { descricaoManual = it },
                label = { Text("Observação (opcional)") },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(Modifier.height(12.dp))
            if (abertas.isEmpty()) {
                Text(
                    "Não há duplicatas em aberto desse tipo para este cliente.",
                    style = MaterialTheme.typography.bodyMedium
                )
            } else {
                Text(
                    "Selecionadas automaticamente pelas mais antigas. Toque para trocar:",
                    style = MaterialTheme.typography.bodySmall
                )
                LazyColumn(Modifier.weight(1f)) {
                    items(abertas, key = { it.movimentacaoId + "_" + it.parcela.numero }) { ref ->
                        val chave = ref.movimentacaoId to ref.parcela.numero
                        val marcada = chave in selecionadas
                        val p = ref.parcela
                        ListItem(
                            headlineContent = {
                                Text("${ref.movimentacaoDescricao} — duplicata ${p.numero}")
                            },
                            supportingContent = {
                                val faltante = p.valorOriginal - p.valorPago
                                Text(
                                    "Vence ${fmtData.format(java.util.Date(p.dataVencimento))} — " +
                                        if (p.status == "parcial")
                                            "falta R$ %.2f (de R$ %.2f)".format(faltante, p.valorOriginal)
                                        else
                                            "R$ %.2f".format(faltante)
                                )
                            },
                            trailingContent = {
                                Checkbox(
                                    checked = marcada,
                                    onCheckedChange = { checado ->
                                        selecaoManualAtiva = true
                                        selecionadas = if (checado) selecionadas + chave else selecionadas - chave
                                    }
                                )
                            }
                        )
                        HorizontalDivider()
                    }
                }

                Spacer(Modifier.height(8.dp))
                Text("Total das duplicatas selecionadas: R$ %.2f".format(totalSelecionado))
                if (valorPago > 0 && valorPago < totalSelecionado - 0.01) {
                    Text(
                        "O valor é menor que o total selecionado: a última duplicata ficará parcialmente paga.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error
                    )
                }

                Spacer(Modifier.height(8.dp))
                Button(
                    enabled = !salvando && valorPago > 0 && selecionadas.isNotEmpty(),
                    onClick = {
                        salvando = true
                        val selecionadasOrdenadas = abertas.filter {
                            (it.movimentacaoId to it.parcela.numero) in selecionadas
                        }
                        viewModel.darBaixa(
                            clienteId = clienteId,
                            selecionadas = selecionadasOrdenadas,
                            valorPago = valorPago,
                            descricaoManual = descricaoManual
                        ) {
                            salvando = false
                            aoVoltar()
                        }
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    if (salvando) {
                        CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                        Spacer(Modifier.width(8.dp))
                    }
                    Text("Confirmar baixa")
                }
            }
        }
    }
}
