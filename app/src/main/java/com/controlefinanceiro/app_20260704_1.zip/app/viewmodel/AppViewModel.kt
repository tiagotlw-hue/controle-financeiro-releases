package com.controlefinanceiro.app.viewmodel

import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.controlefinanceiro.app.data.Cliente
import com.controlefinanceiro.app.data.FirebaseRepository
import com.controlefinanceiro.app.data.Movimentacao
import com.controlefinanceiro.app.data.ParcelaRef
import com.controlefinanceiro.app.data.ParcelaUtils
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.launch

class AppViewModel : ViewModel() {

    private val repo = FirebaseRepository()

    val clientes = mutableStateOf<List<Cliente>>(emptyList())
    val movimentacoes = mutableStateOf<List<Movimentacao>>(emptyList())
    val carregando = mutableStateOf(false)
    val erro = mutableStateOf<String?>(null)

    private var jobMovimentacoes: Job? = null
    private var jobClientes: Job? = null

    fun usuarioLogado() = repo.usuarioLogado()

    /** Começa a escuta contínua dos clientes. Só deve ser chamada quando já
     *  existe um usuário autenticado. Funciona offline normalmente: entrega
     *  o cache local na hora e sincroniza sozinho quando a conexão volta. */
    fun iniciarEscutaClientes() {
        if (jobClientes != null) return // já está escutando
        jobClientes = viewModelScope.launch {
            repo.escutarClientes()
                .catch { e -> erro.value = e.message }
                .collect { clientes.value = it }
        }
    }

    fun limparErro() {
        erro.value = null
    }

    /** Começa (ou reinicia, se o cliente mudou) a escuta das movimentações desse cliente. */
    fun observarMovimentacoes(clienteId: String) {
        jobMovimentacoes?.cancel()
        jobMovimentacoes = viewModelScope.launch {
            carregando.value = true
            repo.escutarMovimentacoes(clienteId)
                .catch { e ->
                    erro.value = e.message
                    carregando.value = false
                }
                .collect { lista ->
                    movimentacoes.value = lista
                    carregando.value = false
                }
        }
    }

    fun salvarCliente(cliente: Cliente, aoConcluir: () -> Unit = {}) {
        viewModelScope.launch {
            try {
                repo.salvarCliente(cliente)
                aoConcluir()
            } catch (e: Exception) {
                erro.value = e.message
            }
        }
    }

    fun excluirCliente(clienteId: String) {
        viewModelScope.launch {
            try {
                repo.excluirCliente(clienteId)
            } catch (e: Exception) {
                erro.value = e.message
            }
        }
    }

    fun criarMovimentacao(
        clienteId: String,
        tipo: String,
        descricao: String,
        valorTotal: Double,
        numParcelas: Int,
        diaVencimento: Int,
        aoConcluir: () -> Unit = {}
    ) {
        viewModelScope.launch {
            try {
                val parcelas = ParcelaUtils.gerarParcelas(
                    valorTotal = valorTotal,
                    numParcelas = numParcelas,
                    dataCriacao = System.currentTimeMillis(),
                    diaVencimento = diaVencimento
                )
                val movimentacao = Movimentacao(
                    clienteId = clienteId,
                    tipo = tipo,
                    descricao = descricao,
                    valorTotal = valorTotal,
                    numParcelas = numParcelas,
                    diaVencimento = diaVencimento,
                    parcelas = parcelas
                )
                repo.salvarMovimentacao(clienteId, movimentacao)
                aoConcluir()
            } catch (e: Exception) {
                erro.value = e.message
            }
        }
    }

    fun excluirMovimentacao(clienteId: String, movimentacaoId: String) {
        viewModelScope.launch {
            try {
                repo.excluirMovimentacao(clienteId, movimentacaoId)
            } catch (e: Exception) {
                erro.value = e.message
            }
        }
    }

    /** Dá baixa distribuindo `valorPago` pelas parcelas selecionadas (de uma ou mais
     *  movimentações do mesmo tipo), sempre respeitando a ordem em que foram passadas
     *  (a tela já manda as mais antigas primeiro). */
    fun darBaixa(
        clienteId: String,
        selecionadas: List<ParcelaRef>,
        valorPago: Double,
        descricaoManual: String,
        aoConcluir: () -> Unit = {}
    ) {
        viewModelScope.launch {
            try {
                val movimentacoesPorId = movimentacoes.value.associateBy { it.id }
                val atualizadas = ParcelaUtils.aplicarBaixaConsolidada(
                    movimentacoesPorId = movimentacoesPorId,
                    selecionadas = selecionadas,
                    valorPago = valorPago,
                    descricaoManual = descricaoManual
                )
                repo.aplicarBaixa(clienteId, atualizadas)
                aoConcluir()
            } catch (e: Exception) {
                erro.value = e.message
            }
        }
    }
}
