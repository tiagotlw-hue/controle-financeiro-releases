package com.controlefinanceiro.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.*
import androidx.lifecycle.viewmodel.compose.viewModel
import com.controlefinanceiro.app.data.Cliente
import com.controlefinanceiro.app.data.Movimentacao
import com.controlefinanceiro.app.data.TipoMovimentacao
import com.controlefinanceiro.app.ui.screens.*
import com.controlefinanceiro.app.ui.theme.ControleFinanceiroTheme
import com.controlefinanceiro.app.viewmodel.AppViewModel
import com.google.firebase.auth.FirebaseAuth

// Cole aqui o "Web client ID" (tipo 3 / Web) que aparece em:
// Firebase Console > Authentication > Sign-in method > Google > detalhes do SDK Web
const val WEB_CLIENT_ID = "530471929124-7cntd4equh7obf6dul2dcocm10lpe5tk.apps.googleusercontent.com"

private sealed class Tela {
    data object Login : Tela()
    data object Clientes : Tela()
    data object VisaoGeral : Tela()
    data class ClienteForm(val cliente: Cliente?) : Tela()
    data class Movimentacoes(val cliente: Cliente) : Tela()
    data class Entrada(val cliente: Cliente, val tipoFixo: String? = null) : Tela()
    data class Saida(val cliente: Cliente, val tipoInicial: String, val movimentacaoIdFiltro: String? = null) : Tela()
    data class MovimentacaoDetalhe(val cliente: Cliente, val movimentacao: Movimentacao) : Tela()
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ControleFinanceiroTheme {
                val viewModel: AppViewModel = viewModel()
                var tela by remember {
                    mutableStateOf<Tela>(
                        if (FirebaseAuth.getInstance().currentUser != null) Tela.Clientes else Tela.Login
                    )
                }

                LaunchedEffect(Unit) {
                    if (FirebaseAuth.getInstance().currentUser != null) {
                        viewModel.iniciarEscutaClientes()
                    }
                }

                when (val t = tela) {
                    is Tela.Login -> LoginScreen(webClientId = WEB_CLIENT_ID) {
                        viewModel.iniciarEscutaClientes()
                        tela = Tela.Clientes
                    }
                    is Tela.Clientes -> ClientesScreen(
                        viewModel = viewModel,
                        aoAbrirCliente = { tela = Tela.Movimentacoes(it) },
                        aoNovoCliente = { tela = Tela.ClienteForm(null) },
                        aoEditarCliente = { tela = Tela.ClienteForm(it) },
                        aoAbrirVisaoGeral = { tela = Tela.VisaoGeral }
                    )
                    is Tela.VisaoGeral -> VisaoGeralScreen(
                        viewModel = viewModel,
                        aoAbrirCliente = { tela = Tela.Movimentacoes(it) },
                        aoVoltar = { tela = Tela.Clientes }
                    )
                    is Tela.ClienteForm -> ClienteFormScreen(
                        viewModel = viewModel,
                        clienteExistente = t.cliente,
                        aoVoltar = { tela = Tela.Clientes }
                    )
                    is Tela.Movimentacoes -> MovimentacoesScreen(
                        viewModel = viewModel,
                        cliente = t.cliente,
                        aoAbrirMovimentacao = { tela = Tela.MovimentacaoDetalhe(t.cliente, it) },
                        aoNovaEntrada = { tela = Tela.Entrada(t.cliente) },
                        aoNovaSaida = { tela = Tela.Saida(t.cliente, TipoMovimentacao.RECEBER) },
                        aoVoltar = { tela = Tela.Clientes }
                    )
                    is Tela.Entrada -> EntradaScreen(
                        viewModel = viewModel,
                        clienteId = t.cliente.id,
                        tipoFixo = t.tipoFixo,
                        aoVoltar = { tela = Tela.Movimentacoes(t.cliente) }
                    )
                    is Tela.Saida -> SaidaScreen(
                        viewModel = viewModel,
                        clienteId = t.cliente.id,
                        tipoInicial = t.tipoInicial,
                        movimentacaoIdFiltro = t.movimentacaoIdFiltro,
                        aoVoltar = { tela = Tela.Movimentacoes(t.cliente) }
                    )
                    is Tela.MovimentacaoDetalhe -> MovimentacaoDetalheScreen(
                        movimentacao = t.movimentacao,
                        aoBaixar = {
                            tela = Tela.Saida(t.cliente, t.movimentacao.tipo, t.movimentacao.id)
                        },
                        aoNovaMovimentacaoMesmoTipo = {
                            tela = Tela.Entrada(t.cliente, t.movimentacao.tipo)
                        },
                        aoVoltar = { tela = Tela.Movimentacoes(t.cliente) }
                    )
                }
            }
        }
    }
}
