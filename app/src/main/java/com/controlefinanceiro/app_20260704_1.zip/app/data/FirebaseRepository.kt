package com.controlefinanceiro.app.data

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.MetadataChanges
import com.google.firebase.firestore.Source
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

class FirebaseRepository {

    private val auth = FirebaseAuth.getInstance()
    private val db = FirebaseFirestore.getInstance()

    private fun uid(): String =
        auth.currentUser?.uid ?: error("Usuário não autenticado")

    private fun clientesRef() =
        db.collection("usuarios").document(uid()).collection("clientes")

    private fun movimentacoesRef(clienteId: String) =
        clientesRef().document(clienteId).collection("movimentacoes")

    // ---------- CLIENTES ----------
    // Usa addSnapshotListener (em vez de get() único) para funcionar offline:
    // o Firestore mantém um cache local e entrega os dados salvos no aparelho
    // instantaneamente, mesmo sem internet, e sincroniza sozinho quando a
    // conexão volta (tanto leituras quanto escritas pendentes).

    fun escutarClientes(): Flow<List<Cliente>> = callbackFlow {
        val registration = clientesRef().addSnapshotListener(MetadataChanges.INCLUDE) { snap, error ->
            if (error != null) {
                close(error)
                return@addSnapshotListener
            }
            val lista = snap?.documents?.map { doc ->
                doc.toObject(Cliente::class.java)?.copy(id = doc.id) ?: Cliente(id = doc.id)
            }?.sortedBy { it.nome } ?: emptyList()
            trySend(lista)
        }
        awaitClose { registration.remove() }
    }

    suspend fun salvarCliente(cliente: Cliente): String {
        return if (cliente.id.isBlank()) {
            val ref = clientesRef().add(cliente).await()
            ref.id
        } else {
            clientesRef().document(cliente.id).set(cliente).await()
            cliente.id
        }
    }

    suspend fun excluirCliente(clienteId: String) {
        clientesRef().document(clienteId).delete().await()
    }

    // ---------- MOVIMENTAÇÕES ----------

    fun escutarMovimentacoes(clienteId: String): Flow<List<Movimentacao>> = callbackFlow {
        val registration = movimentacoesRef(clienteId).addSnapshotListener(MetadataChanges.INCLUDE) { snap, error ->
            if (error != null) {
                close(error)
                return@addSnapshotListener
            }
            val lista = snap?.documents?.map { doc ->
                doc.toObject(Movimentacao::class.java)?.copy(id = doc.id) ?: Movimentacao(id = doc.id)
            }?.sortedByDescending { it.dataCriacao } ?: emptyList()
            trySend(lista)
        }
        awaitClose { registration.remove() }
    }

    /** Busca única (usada internamente para recalcular saldo); tenta cache primeiro para funcionar offline. */
    private suspend fun listarMovimentacoesUmaVez(clienteId: String): List<Movimentacao> {
        val snap = try {
            movimentacoesRef(clienteId).get(Source.CACHE).await()
        } catch (e: Exception) {
            movimentacoesRef(clienteId).get(Source.SERVER).await()
        }
        return snap.documents.map { doc ->
            doc.toObject(Movimentacao::class.java)?.copy(id = doc.id) ?: Movimentacao(id = doc.id)
        }
    }

    suspend fun salvarMovimentacao(clienteId: String, movimentacao: Movimentacao): String {
        val ref = movimentacoesRef(clienteId)
        val id = if (movimentacao.id.isBlank()) {
            ref.add(movimentacao.copy(clienteId = clienteId)).await().id
        } else {
            ref.document(movimentacao.id).set(movimentacao).await()
            movimentacao.id
        }
        recalcularSaldoCliente(clienteId)
        return id
    }

    suspend fun excluirMovimentacao(clienteId: String, movimentacaoId: String) {
        movimentacoesRef(clienteId).document(movimentacaoId).delete().await()
        recalcularSaldoCliente(clienteId)
    }

    /** Grava a baixa em todas as movimentações afetadas de uma vez (atômico via batch;
     *  o batch funciona offline também — fica na fila local e sincroniza depois). */
    suspend fun aplicarBaixa(clienteId: String, movimentacoesAtualizadas: Map<String, Movimentacao>) {
        val batch = db.batch()
        val ref = movimentacoesRef(clienteId)
        movimentacoesAtualizadas.forEach { (id, mov) ->
            batch.set(ref.document(id), mov)
        }
        batch.commit().await()
        recalcularSaldoCliente(clienteId)
    }

    /** Recalcula e grava o saldo denormalizado do cliente = total a receber em aberto
     *  menos total a pagar em aberto, considerando todas as movimentações dele.
     *  Também grava os dois totais separados, usados na tela de visão geral. */
    suspend fun recalcularSaldoCliente(clienteId: String) {
        val movimentacoes = listarMovimentacoesUmaVez(clienteId)
        val aReceber = movimentacoes.filter { it.tipo == TipoMovimentacao.RECEBER }.sumOf { it.valorEmAberto }
        val aPagar = movimentacoes.filter { it.tipo == TipoMovimentacao.PAGAR }.sumOf { it.valorEmAberto }
        val saldo = aReceber - aPagar
        clientesRef().document(clienteId).update(
            mapOf(
                "saldo" to saldo,
                "totalAReceber" to aReceber,
                "totalAPagar" to aPagar
            )
        ).await()
    }

    fun usuarioLogado() = auth.currentUser
}
