package com.controlefinanceiro.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.controlefinanceiro.app.data.ParcelaUtils
import com.controlefinanceiro.app.data.TipoMovimentacao
import com.controlefinanceiro.app.viewmodel.AppViewModel
import java.text.SimpleDateFormat
import java.util.Locale

private val fmtData = SimpleDateFormat("dd/MM/yyyy", Locale("pt", "BR"))

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EntradaScreen(
    viewModel: AppViewModel,
    clienteId: String,
    tipoFixo: String? = null,
    aoVoltar: () -> Unit
) {
    var tipo by remember { mutableStateOf(tipoFixo ?: TipoMovimentacao.RECEBER) }
    var descricao by remember { mutableStateOf("") }
    var valorTexto by remember { mutableStateOf("") }
    var numParcelasTexto by remember { mutableStateOf("1") }
    var diaVencimentoTexto by remember { mutableStateOf("15") }
    var salvando by remember { mutableStateOf(false) }
    val snackbarHostState = remember { SnackbarHostState() }
    val erro = viewModel.erro.value

    LaunchedEffect(erro) {
        if (erro != null) {
            salvando = false
            snackbarHostState.showSnackbar(erro)
            viewModel.limparErro()
        }
    }

    val valorTotal = valorTexto.replace(",", ".").toDoubleOrNull() ?: 0.0
    val numParcelas = numParcelasTexto.toIntOrNull()?.coerceAtLeast(1) ?: 1
    val diaVencimento = diaVencimentoTexto.toIntOrNull()?.coerceIn(1, 31) ?: 15

    // Prévia ao vivo: recalcula as duplicatas geradas conforme a pessoa digita,
    // para confirmar antes de salvar de verdade.
    val previa = remember(valorTotal, numParcelas, diaVencimento) {
        if (valorTotal > 0) {
            try {
                ParcelaUtils.gerarParcelas(valorTotal, numParcelas, System.currentTimeMillis(), diaVencimento)
            } catch (e: Exception) {
                emptyList()
            }
        } else emptyList()
    }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Nova entrada") }) },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            Text("Tipo de cobrança", style = MaterialTheme.typography.labelLarge)
            Spacer(Modifier.height(4.dp))
            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                SegmentedButton(
                    selected = tipo == TipoMovimentacao.RECEBER,
                    onClick = { if (tipoFixo == null) tipo = TipoMovimentacao.RECEBER },
                    enabled = tipoFixo == null,
                    shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2)
                ) { Text("A receber") }
                SegmentedButton(
                    selected = tipo == TipoMovimentacao.PAGAR,
                    onClick = { if (tipoFixo == null) tipo = TipoMovimentacao.PAGAR },
                    enabled = tipoFixo == null,
                    shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2)
                ) { Text("A pagar") }
            }
            if (tipoFixo != null) {
                Text(
                    "Tipo fixo porque você abriu essa tela a partir de uma cobrança existente.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Spacer(Modifier.height(12.dp))

            OutlinedTextField(
                value = descricao, onValueChange = { descricao = it },
                label = { Text("Descrição") }, modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = valorTexto, onValueChange = { valorTexto = it },
                label = { Text("Valor total (R$)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            Row {
                OutlinedTextField(
                    value = numParcelasTexto, onValueChange = { numParcelasTexto = it },
                    label = { Text("Nº de duplicatas") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f)
                )
                Spacer(Modifier.width(8.dp))
                OutlinedTextField(
                    value = diaVencimentoTexto, onValueChange = { diaVencimentoTexto = it },
                    label = { Text("Dia venc.") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(Modifier.height(16.dp))
            Text("Prévia das duplicatas", style = MaterialTheme.typography.labelLarge)
            Spacer(Modifier.height(4.dp))
            if (previa.isEmpty()) {
                Text(
                    "Digite um valor para ver a prévia.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                LazyColumn(Modifier.weight(1f)) {
                    items(previa) { p ->
                        ListItem(
                            headlineContent = { Text("Duplicata ${p.numero}/$numParcelas") },
                            supportingContent = { Text("Vence em ${fmtData.format(java.util.Date(p.dataVencimento))}") },
                            trailingContent = { Text("R$ %.2f".format(p.valorOriginal)) }
                        )
                        HorizontalDivider()
                    }
                }
            }

            Spacer(Modifier.height(8.dp))
            Button(
                onClick = {
                    salvando = true
                    viewModel.criarMovimentacao(
                        clienteId = clienteId,
                        tipo = tipo,
                        descricao = descricao.ifBlank { if (tipo == TipoMovimentacao.RECEBER) "A receber" else "A pagar" },
                        valorTotal = valorTotal,
                        numParcelas = numParcelas,
                        diaVencimento = diaVencimento
                    ) {
                        salvando = false
                        aoVoltar()
                    }
                },
                enabled = !salvando && valorTotal > 0,
                modifier = Modifier.fillMaxWidth()
            ) {
                if (salvando) {
                    CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(8.dp))
                }
                Text("Confirmar entrada")
            }
        }
    }
}
