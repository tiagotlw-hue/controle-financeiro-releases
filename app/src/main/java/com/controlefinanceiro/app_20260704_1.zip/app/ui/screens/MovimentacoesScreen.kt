package com.controlefinanceiro.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.controlefinanceiro.app.data.Cliente
import com.controlefinanceiro.app.data.Movimentacao
import com.controlefinanceiro.app.data.Pagamento
import com.controlefinanceiro.app.data.TipoMovimentacao
import com.controlefinanceiro.app.viewmodel.AppViewModel
import java.text.SimpleDateFormat
import java.util.Locale

private val fmtData = SimpleDateFormat("dd/MM/yyyy", Locale("pt", "BR"))
private val fmtDataHora = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("pt", "BR"))
private val VerdeSaldo = Color(0xFF2E7D32)
private val VermelhoSaldo = Color(0xFFC62828)

private enum class AbaCliente { MOVIMENTACOES, EXTRATO }

// Evento de extrato: pode ser a criação de uma cobrança (Entrada) ou uma baixa
// registrada nela (Saída) — juntos formam a linha do tempo completa do cliente.
private sealed class EventoExtrato(val data: Long) {
    class Entrada(data: Long, val mov: Movimentacao) : EventoExtrato(data)
    class Saida(data: Long, val mov: Movimentacao, val pagamento: Pagamento) : EventoExtrato(data)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MovimentacoesScreen(
    viewModel: AppViewModel,
    cliente: Cliente,
    aoAbrirMovimentacao: (Movimentacao) -> Unit,
    aoNovaEntrada: () -> Unit,
    aoNovaSaida: () -> Unit,
    aoVoltar: () -> Unit
) {
    LaunchedEffect(cliente.id) { viewModel.observarMovimentacoes(cliente.id) }
    val movimentacoes by viewModel.movimentacoes
    val snackbarHostState = remember { SnackbarHostState() }
    val erro = viewModel.erro.value
    var aba by remember { mutableStateOf(AbaCliente.MOVIMENTACOES) }
    var mostrarQuitadas by remember { mutableStateOf(false) }

    LaunchedEffect(erro) {
        if (erro != null) {
            snackbarHostState.showSnackbar(erro)
            viewModel.limparErro()
        }
    }

    val aReceber = movimentacoes.filter { it.tipo == TipoMovimentacao.RECEBER }.sumOf { it.valorEmAberto }
    val aPagar = movimentacoes.filter { it.tipo == TipoMovimentacao.PAGAR }.sumOf { it.valorEmAberto }
    val saldo = aReceber - aPagar

    val movimentacoesVisiveis = remember(movimentacoes, mostrarQuitadas) {
        if (mostrarQuitadas) movimentacoes else movimentacoes.filterNot { it.quitada }
    }

    val eventosExtrato = remember(movimentacoes) {
        val lista = mutableListOf<EventoExtrato>()
        movimentacoes.forEach { mov ->
            lista += EventoExtrato.Entrada(mov.dataCriacao, mov)
            mov.historicoPagamentos.forEach { pag -> lista += EventoExtrato.Saida(pag.data, mov, pag) }
        }
        lista.sortedByDescending { it.data }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(cliente.nome) },
                navigationIcon = {
                    IconButton(onClick = aoVoltar) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Voltar")
                    }
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        bottomBar = {
            BottomAppBar {
                Button(
                    onClick = aoNovaEntrada,
                    modifier = Modifier.weight(1f).padding(horizontal = 8.dp)
                ) {
                    Icon(Icons.Default.ArrowDownward, contentDescription = null)
                    Spacer(Modifier.width(4.dp))
                    Text("Entrada")
                }
                Button(
                    onClick = aoNovaSaida,
                    modifier = Modifier.weight(1f).padding(horizontal = 8.dp),
                    enabled = movimentacoes.any { it.valorEmAberto > 0.01 }
                ) {
                    Icon(Icons.Default.ArrowUpward, contentDescription = null)
                    Spacer(Modifier.width(4.dp))
                    Text("Saída")
                }
            }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            Card(Modifier.fillMaxWidth().padding(16.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text("Saldo do cliente", style = MaterialTheme.typography.labelLarge)
                    Text(
                        "R$ %.2f".format(saldo),
                        style = MaterialTheme.typography.headlineMedium,
                        color = if (saldo >= 0) VerdeSaldo else VermelhoSaldo
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("A receber: R$ %.2f".format(aReceber), color = VerdeSaldo, style = MaterialTheme.typography.bodyMedium)
                        Text("A pagar: R$ %.2f".format(aPagar), color = VermelhoSaldo, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }

            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
                SegmentedButton(
                    selected = aba == AbaCliente.MOVIMENTACOES,
                    onClick = { aba = AbaCliente.MOVIMENTACOES },
                    shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2)
                ) { Text("Movimentações") }
                SegmentedButton(
                    selected = aba == AbaCliente.EXTRATO,
                    onClick = { aba = AbaCliente.EXTRATO },
                    shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2)
                ) { Text("Extrato") }
            }
            Spacer(Modifier.height(8.dp))

            when (aba) {
                AbaCliente.MOVIMENTACOES -> {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 16.dp).clickable { mostrarQuitadas = !mostrarQuitadas },
                        verticalAlignment = androidx.compose.ui.Alignment.CenterVertically
                    ) {
                        Checkbox(checked = mostrarQuitadas, onCheckedChange = { mostrarQuitadas = it })
                        Text("Mostrar quitadas", style = MaterialTheme.typography.bodySmall)
                    }

                    if (movimentacoesVisiveis.isEmpty()) {
                        Box(Modifier.fillMaxSize(), contentAlignment = androidx.compose.ui.Alignment.Center) {
                            Text(
                                if (movimentacoes.isEmpty())
                                    "Nenhuma movimentação ainda. Toque em \"Entrada\" para lançar a primeira."
                                else
                                    "Nenhuma movimentação em aberto. Marque \"Mostrar quitadas\" para ver as já quitadas."
                            )
                        }
                    } else {
                        LazyColumn(Modifier.fillMaxSize()) {
                            items(movimentacoesVisiveis, key = { it.id }) { mov ->
                                val corTipo = if (mov.tipo == TipoMovimentacao.RECEBER) VerdeSaldo else VermelhoSaldo
                                ListItem(
                                    headlineContent = { Text(mov.descricao) },
                                    supportingContent = {
                                        Column {
                                            Text("Desde ${fmtData.format(java.util.Date(mov.dataCriacao))}")
                                            Text(
                                                if (mov.quitada) "Quitada — R$ %.2f".format(mov.valorTotal)
                                                else "Em aberto: R$ %.2f de R$ %.2f".format(mov.valorEmAberto, mov.valorTotal)
                                            )
                                        }
                                    },
                                    leadingContent = {
                                        AssistChip(
                                            onClick = {},
                                            label = { Text(if (mov.tipo == TipoMovimentacao.RECEBER) "A receber" else "A pagar") },
                                            colors = AssistChipDefaults.assistChipColors(labelColor = corTipo)
                                        )
                                    },
                                    modifier = Modifier.clickable { aoAbrirMovimentacao(mov) }
                                )
                                HorizontalDivider()
                            }
                        }
                    }
                }

                AbaCliente.EXTRATO -> {
                    if (eventosExtrato.isEmpty()) {
                        Box(Modifier.fillMaxSize(), contentAlignment = androidx.compose.ui.Alignment.Center) {
                            Text("Nenhuma movimentação registrada ainda.")
                        }
                    } else {
                        LazyColumn(Modifier.fillMaxSize()) {
                            items(eventosExtrato) { evento ->
                                when (evento) {
                                    is EventoExtrato.Entrada -> {
                                        val mov = evento.mov
                                        val cor = if (mov.tipo == TipoMovimentacao.RECEBER) VerdeSaldo else VermelhoSaldo
                                        ListItem(
                                            leadingContent = {
                                                Icon(Icons.Default.ArrowDownward, contentDescription = null, tint = cor)
                                            },
                                            headlineContent = { Text("Entrada — ${mov.descricao}") },
                                            supportingContent = {
                                                Text(
                                                    "${fmtDataHora.format(java.util.Date(evento.data))} — " +
                                                        (if (mov.tipo == TipoMovimentacao.RECEBER) "a receber" else "a pagar")
                                                )
                                            },
                                            trailingContent = {
                                                Text("R$ %.2f".format(mov.valorTotal), color = cor)
                                            },
                                            modifier = Modifier.clickable { aoAbrirMovimentacao(mov) }
                                        )
                                    }
                                    is EventoExtrato.Saida -> {
                                        ListItem(
                                            leadingContent = {
                                                Icon(Icons.Default.ArrowUpward, contentDescription = null)
                                            },
                                            headlineContent = { Text("Saída — ${evento.mov.descricao}") },
                                            supportingContent = {
                                                Text(fmtDataHora.format(java.util.Date(evento.data)))
                                            },
                                            trailingContent = {
                                                Text("R$ %.2f".format(evento.pagamento.valorPago))
                                            },
                                            modifier = Modifier.clickable { aoAbrirMovimentacao(evento.mov) }
                                        )
                                    }
                                }
                                HorizontalDivider()
                            }
                        }
                    }
                }
            }
        }
    }
}
