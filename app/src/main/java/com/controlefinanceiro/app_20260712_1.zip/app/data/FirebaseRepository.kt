package com.controlefinanceiro.app.data

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.MetadataChanges
import com.google.firebase.firestore.Source
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

class FirebaseRepository {

    private val auth = FirebaseAuth.getInstance()
    private val db = FirebaseFirestore.getInstance()

    private fun uid(): String =
        auth.currentUser?.uid ?: error("Usuário não autenticado")

    private fun clientesRef() =
        db.collection("usuarios").document(uid()).collection("clientes")

    private fun categoriasRef(clienteId: String) =
        clientesRef().document(clienteId).collection("categorias")

    private fun movimentacoesRef(clienteId: String, categoriaId: String) =
        categoriasRef(clienteId).document(categoriaId).collection("movimentacoes")

    private fun cartoesRef() =
        db.collection("usuarios").document(uid()).collection("cartoes")

    private fun configuracoesRef() =
        db.collection("usuarios").document(uid()).collection("config").document("geral")

    // ---------- CLIENTES ----------
    // Usa addSnapshotListener (em vez de get() único) para funcionar offline:
    // o Firestore mantém um cache local e entrega os dados salvos no aparelho
    // instantaneamente, mesmo sem internet, e sincroniza sozinho quando a
    // conexão volta (tanto leituras quanto escritas pendentes).

    fun escutarClientes(): Flow<List<Cliente>> = callbackFlow {
        val registration = clientesRef().addSnapshotListener(MetadataChanges.INCLUDE) { snap, error ->
            if (error != null) {
                close(error)
                return@addSnapshotListener
            }
            val lista = snap?.documents?.map { doc ->
                doc.toObject(Cliente::class.java)?.copy(id = doc.id) ?: Cliente(id = doc.id)
            }?.sortedBy { it.nome } ?: emptyList()
            trySend(lista)
        }
        awaitClose { registration.remove() }
    }

    suspend fun salvarCliente(cliente: Cliente): String {
        return if (cliente.id.isBlank()) {
            val ref = clientesRef().add(cliente).await()
            ref.id
        } else {
            clientesRef().document(cliente.id).set(cliente).await()
            cliente.id
        }
    }

    suspend fun excluirCliente(clienteId: String) {
        clientesRef().document(clienteId).delete().await()
    }

    // ---------- CATEGORIAS ----------
    // Uma "conta" dentro do cliente (ex: "Construção a pagar"), que agrupa várias
    // movimentações do mesmo tipo.

    fun escutarCategorias(clienteId: String): Flow<List<Categoria>> = callbackFlow {
        val registration = categoriasRef(clienteId).addSnapshotListener(MetadataChanges.INCLUDE) { snap, error ->
            if (error != null) {
                close(error)
                return@addSnapshotListener
            }
            val lista = snap?.documents?.map { doc ->
                doc.toObject(Categoria::class.java)?.copy(id = doc.id) ?: Categoria(id = doc.id)
            }?.sortedByDescending { it.dataCriacao } ?: emptyList()
            trySend(lista)
        }
        awaitClose { registration.remove() }
    }

    suspend fun salvarCategoria(clienteId: String, categoria: Categoria): String {
        return if (categoria.id.isBlank()) {
            val ref = categoriasRef(clienteId).add(categoria.copy(clienteId = clienteId)).await()
            ref.id
        } else {
            categoriasRef(clienteId).document(categoria.id).set(categoria).await()
            categoria.id
        }
    }

    suspend fun excluirCategoria(clienteId: String, categoriaId: String) {
        categoriasRef(clienteId).document(categoriaId).delete().await()
        recalcularSaldoCliente(clienteId)
    }

    // ---------- CARTÕES ----------
    // Configuração global do app (não é por cliente): cartões cadastrados, cada um com
    // seu próprio dia de fechamento ("melhor dia") e dia de vencimento da fatura.

    fun escutarCartoes(): Flow<List<Cartao>> = callbackFlow {
        val registration = cartoesRef().addSnapshotListener(MetadataChanges.INCLUDE) { snap, error ->
            if (error != null) {
                close(error)
                return@addSnapshotListener
            }
            val lista = snap?.documents?.map { doc ->
                doc.toObject(Cartao::class.java)?.copy(id = doc.id) ?: Cartao(id = doc.id)
            }?.sortedBy { it.nome } ?: emptyList()
            trySend(lista)
        }
        awaitClose { registration.remove() }
    }

    suspend fun salvarCartao(cartao: Cartao): String {
        return if (cartao.id.isBlank()) {
            val ref = cartoesRef().add(cartao).await()
            ref.id
        } else {
            cartoesRef().document(cartao.id).set(cartao).await()
            cartao.id
        }
    }

    suspend fun excluirCartao(cartaoId: String) {
        cartoesRef().document(cartaoId).delete().await()
    }

    // ---------- CONFIGURAÇÕES ----------

    fun escutarConfiguracoes(): Flow<Configuracoes> = callbackFlow {
        val registration = configuracoesRef().addSnapshotListener(MetadataChanges.INCLUDE) { snap, error ->
            if (error != null) {
                close(error)
                return@addSnapshotListener
            }
            val config = try {
                snap?.toObject(Configuracoes::class.java) ?: Configuracoes()
            } catch (e: Exception) {
                Configuracoes()
            }
            trySend(config)
        }
        awaitClose { registration.remove() }
    }

    suspend fun salvarConfiguracoes(configuracoes: Configuracoes) {
        configuracoesRef().set(configuracoes).await()
    }

    // ---------- MOVIMENTAÇÕES ----------

    fun escutarMovimentacoes(clienteId: String, categoriaId: String): Flow<List<Movimentacao>> = callbackFlow {
        val registration = movimentacoesRef(clienteId, categoriaId).addSnapshotListener(MetadataChanges.INCLUDE) { snap, error ->
            if (error != null) {
                close(error)
                return@addSnapshotListener
            }
            val lista = snap?.documents?.map { doc ->
                doc.toObject(Movimentacao::class.java)?.copy(id = doc.id) ?: Movimentacao(id = doc.id)
            }?.sortedByDescending { it.dataCriacao } ?: emptyList()
            trySend(lista)
        }
        awaitClose { registration.remove() }
    }

    /** Busca única (usada internamente para recalcular saldos); tenta cache primeiro para funcionar offline. */
    private suspend fun listarMovimentacoesUmaVez(clienteId: String, categoriaId: String): List<Movimentacao> {
        val snap = try {
            movimentacoesRef(clienteId, categoriaId).get(Source.CACHE).await()
        } catch (e: Exception) {
            movimentacoesRef(clienteId, categoriaId).get(Source.SERVER).await()
        }
        return snap.documents.map { doc ->
            doc.toObject(Movimentacao::class.java)?.copy(id = doc.id) ?: Movimentacao(id = doc.id)
        }
    }

    private suspend fun listarCategoriasUmaVez(clienteId: String): List<Categoria> {
        val snap = try {
            categoriasRef(clienteId).get(Source.CACHE).await()
        } catch (e: Exception) {
            categoriasRef(clienteId).get(Source.SERVER).await()
        }
        return snap.documents.map { doc ->
            doc.toObject(Categoria::class.java)?.copy(id = doc.id) ?: Categoria(id = doc.id)
        }
    }

    /** Cria uma movimentação nova, ou sobrescreve uma existente (edição) se movimentacao.id
     *  já vier preenchido. */
    suspend fun salvarMovimentacao(clienteId: String, categoriaId: String, movimentacao: Movimentacao): String {
        val ref = movimentacoesRef(clienteId, categoriaId)
        val id = if (movimentacao.id.isBlank()) {
            ref.add(movimentacao.copy(clienteId = clienteId, categoriaId = categoriaId)).await().id
        } else {
            ref.document(movimentacao.id).set(movimentacao).await()
            movimentacao.id
        }
        recalcularSaldoCategoria(clienteId, categoriaId)
        recalcularSaldoCliente(clienteId)
        return id
    }

    suspend fun excluirMovimentacao(clienteId: String, categoriaId: String, movimentacaoId: String) {
        movimentacoesRef(clienteId, categoriaId).document(movimentacaoId).delete().await()
        recalcularSaldoCategoria(clienteId, categoriaId)
        recalcularSaldoCliente(clienteId)
    }

    /** Grava a baixa em todas as movimentações afetadas de uma vez (atômico via batch;
     *  o batch funciona offline também — fica na fila local e sincroniza depois).
     *  Todas as movimentações de uma baixa pertencem à mesma categoria (a tela de baixa
     *  só junta duplicatas dentro de uma categoria). */
    suspend fun aplicarBaixa(clienteId: String, categoriaId: String, movimentacoesAtualizadas: Map<String, Movimentacao>) {
        val batch = db.batch()
        val ref = movimentacoesRef(clienteId, categoriaId)
        movimentacoesAtualizadas.forEach { (id, mov) ->
            batch.set(ref.document(id), mov)
        }
        batch.commit().await()
        recalcularSaldoCategoria(clienteId, categoriaId)
        recalcularSaldoCliente(clienteId)
    }

    /** Exclui uma baixa específica: busca a movimentação, devolve exatamente o valor que
     *  aquela baixa tinha aplicado em cada parcela afetada, e regrava. */
    suspend fun excluirBaixa(clienteId: String, categoriaId: String, movimentacaoId: String, pagamento: Pagamento) {
        val ref = movimentacoesRef(clienteId, categoriaId).document(movimentacaoId)
        val snap = ref.get(Source.SERVER).await()
        val mov = snap.toObject(Movimentacao::class.java)?.copy(id = snap.id) ?: return
        val movRevertida = ParcelaUtils.reverterBaixa(mov, pagamento)
        ref.set(movRevertida).await()
        recalcularSaldoCategoria(clienteId, categoriaId)
        recalcularSaldoCliente(clienteId)
    }

    /** Edita apenas a data/hora de uma baixa já registrada (valores e parcelas afetadas
     *  continuam os mesmos, então não precisa recalcular saldo). */
    suspend fun editarDataBaixa(
        clienteId: String,
        categoriaId: String,
        movimentacaoId: String,
        pagamento: Pagamento,
        novaData: Long
    ) {
        val ref = movimentacoesRef(clienteId, categoriaId).document(movimentacaoId)
        val snap = ref.get(Source.SERVER).await()
        val mov = snap.toObject(Movimentacao::class.java)?.copy(id = snap.id) ?: return
        val movEditada = ParcelaUtils.editarDataBaixa(mov, pagamento, novaData)
        ref.set(movEditada).await()
    }

    /** Recalcula e grava o total em aberto denormalizado da categoria, somando
     *  todas as movimentações dela. */
    suspend fun recalcularSaldoCategoria(clienteId: String, categoriaId: String) {
        val movimentacoes = listarMovimentacoesUmaVez(clienteId, categoriaId)
        val totalAberto = movimentacoes.sumOf { it.valorEmAberto }
        categoriasRef(clienteId).document(categoriaId).update("totalAberto", totalAberto).await()
    }

    /** Recalcula e grava o saldo denormalizado do cliente = total a receber em aberto
     *  menos total a pagar em aberto, somando as movimentações de TODAS as categorias
     *  dele. Também grava os dois totais separados, usados na tela de visão geral. */
    suspend fun recalcularSaldoCliente(clienteId: String) {
        val categorias = listarCategoriasUmaVez(clienteId)
        var aReceber = 0.0
        var aPagar = 0.0
        for (categoria in categorias) {
            val movimentacoes = listarMovimentacoesUmaVez(clienteId, categoria.id)
            val totalAberto = movimentacoes.sumOf { it.valorEmAberto }
            if (categoria.tipo == TipoMovimentacao.RECEBER) aReceber += totalAberto else aPagar += totalAberto
        }
        val saldo = aReceber - aPagar
        clientesRef().document(clienteId).update(
            mapOf(
                "saldo" to saldo,
                "totalAReceber" to aReceber,
                "totalAPagar" to aPagar
            )
        ).await()
    }

    fun usuarioLogado() = auth.currentUser
}
