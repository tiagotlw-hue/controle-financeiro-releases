package com.controlefinanceiro.app.data

import android.app.DownloadManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.Build
import android.os.Environment
import androidx.core.content.FileProvider
import java.io.File

/**
 * Baixa o APK da atualização em segundo plano (usando o DownloadManager do próprio
 * Android, que já cuida de mostrar notificação de progresso, continuar mesmo se a
 * pessoa sair do app, retomar se a rede cair, etc) e, quando terminar, abre a tela
 * de instalação automaticamente.
 *
 * IMPORTANTE (limite do Android, não dá pra contornar): a pessoa ainda vai precisar
 * dar UM toque em "Instalar" na tela que abre no final — o Android não deixa nenhum
 * app comum instalar outro APK sem essa confirmação manual, é uma proteção de
 * segurança do sistema. O que essa função automatiza é só o download: a pessoa não
 * precisa mais abrir navegador, achar o arquivo, nada disso.
 *
 * Pré-requisitos no projeto (ver instruções completas que acompanham este arquivo):
 * 1. Permissão REQUEST_INSTALL_PACKAGES no AndroidManifest.xml
 * 2. Um <provider> do FileProvider configurado no AndroidManifest.xml
 * 3. O "url" dentro do versao.json precisa ser o link de download DIRETO do arquivo
 *    .apk (não de uma pasta do Drive) — troca lá se ainda estiver apontando pra pasta.
 */
fun baixarEInstalarAtualizacao(context: Context, urlApk: String, nomeVersao: String) {
    val gerenciador = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
    val nomeArquivo = "atualizacao-$nomeVersao.apk"

    val requisicao = DownloadManager.Request(Uri.parse(urlApk))
        .setTitle("Baixando atualização")
        .setDescription("Versão $nomeVersao")
        .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
        .setDestinationInExternalFilesDir(context, Environment.DIRECTORY_DOWNLOADS, nomeArquivo)
        .setAllowedOverMetered(true)
        .setAllowedOverRoaming(true)

    val idDownload = gerenciador.enqueue(requisicao)

    // Escuta o momento em que esse download específico termina, pra abrir a
    // instalação sozinho (só falta o toque final da pessoa em "Instalar").
    val receiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            val idRecebido = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1)
            if (idRecebido != idDownload) return

            val arquivo = File(
                context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS),
                nomeArquivo
            )
            if (!arquivo.exists()) return

            val uriArquivo = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                arquivo
            )

            val intentInstalar = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uriArquivo, "application/vnd.android.package-archive")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION
            }
            context.startActivity(intentInstalar)

            try {
                context.unregisterReceiver(this)
            } catch (e: Exception) {
                // já desregistrado, ignora
            }
        }
    }

    val filtro = IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE)
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        context.registerReceiver(receiver, filtro, Context.RECEIVER_EXPORTED)
    } else {
        context.registerReceiver(receiver, filtro)
    }
}
