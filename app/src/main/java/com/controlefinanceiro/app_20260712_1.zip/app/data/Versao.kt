package com.controlefinanceiro.app.data

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Versão atual deste app. Muda esses dois valores a cada nova versão publicada:
 *  `CODIGO` sempre sobe 1 (é o que decide se tem atualização ou não), `NOME` é só o
 *  texto bonito mostrado pra pessoa (ex: "1.3.0"). */
object Versao {
    const val CODIGO = 3
    const val NOME = "0.0.3"
}

/** Informação da versão mais nova disponível, lida do arquivo de versão no GitHub. */
data class InfoAtualizacao(
    val codigo: Int,
    val nome: String,
    val urlDownload: String
)

/**
 * Verifica se tem uma versão mais nova do app disponível, lendo um arquivinho de
 * texto (JSON) hospedado num repositório do GitHub.
 *
 * Como configurar:
 * 1. Cria (ou já tem) um repositório PÚBLICO no GitHub, ex: github.com/SEU_USUARIO/SEU_REPO
 * 2. Sobe/edita nele um arquivo `versao.json` na raiz, com este conteúdo (ajustando os
 *    valores a cada nova versão publicada):
 *    {"codigo": 2, "nome": "1.1.0", "url": "https://raw.githubusercontent.com/tiagotlw-hue/controle-financeiro-releases/main/app-debug.apk"}
 *    - "codigo": o novo CODIGO (tem que ser maior que o Versao.CODIGO atual do app
 *      pra ele avisar que tem atualização).
 *    - "nome": o texto da versão nova, só pra mostrar pra pessoa.
 *    - "url": o link direto de download do APK (de uma GitHub Release, por exemplo)
 *      que abre quando a pessoa toca em "Atualizar".
 * 3. Substitui [URL_ARQUIVO_VERSAO] logo abaixo com a URL "raw" desse arquivo (troca
 *    SEU_USUARIO, SEU_REPO e o branch se não for "main").
 */
private const val URL_ARQUIVO_VERSAO =
    "https://raw.githubusercontent.com/tiagotlw-hue/controle-financeiro-releases/main/versao.json"

/**
 * Faz a checagem de verdade (rede), tem que ser chamada fora da thread principal
 * (ex: dentro de um `viewModelScope.launch(Dispatchers.IO)` ou `withContext(Dispatchers.IO)`).
 *
 * IMPORTANTE: se não tiver internet (ou a conexão cair no meio, der timeout, o link
 * estiver errado, o arquivo não existir mais, etc.), essa função simplesmente retorna
 * `null` — o app não trava, não mostra nenhum erro pra pessoa, e continua funcionando
 * normalmente, exatamente como se não tivesse nenhuma atualização disponível. A
 * checagem é só "tentativa e melhor esforço": qualquer coisa que dê errado é
 * silenciosamente ignorada.
 */
fun verificarNovaVersao(): InfoAtualizacao? {
    if (URL_ARQUIVO_VERSAO.contains("SEU_USUARIO")) return null
    var conexao: HttpURLConnection? = null
    return try {
        conexao = (URL(URL_ARQUIVO_VERSAO).openConnection() as HttpURLConnection).apply {
            connectTimeout = 5000 // sem rede, falha rápido em vez de segurar o app tentando
            readTimeout = 5000
            requestMethod = "GET"
        }
        if (conexao.responseCode != HttpURLConnection.HTTP_OK) return null

        val texto = conexao.inputStream.bufferedReader().use { it.readText() }
        val json = JSONObject(texto)
        val info = InfoAtualizacao(
            codigo = json.getInt("codigo"),
            nome = json.optString("nome", ""),
            urlDownload = json.optString("url", "")
        )
        if (info.codigo > Versao.CODIGO) info else null
    } catch (e: Exception) {
        // Sem internet, DNS falhou, timeout, JSON inválido, o que for — ignora e segue
        // o app normalmente, como se não tivesse atualização nenhuma.
        null
    } finally {
        conexao?.disconnect()
    }
}
