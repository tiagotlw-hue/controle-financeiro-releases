package com.controlefinanceiro.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import android.content.Intent
import android.net.Uri
import com.controlefinanceiro.app.data.Cartao
import com.controlefinanceiro.app.data.Configuracoes
import com.controlefinanceiro.app.data.FormaPagamento
import com.controlefinanceiro.app.data.InfoAtualizacao
import com.controlefinanceiro.app.data.Versao
import com.controlefinanceiro.app.data.verificarNovaVersao
import com.controlefinanceiro.app.viewmodel.AppViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConfiguracoesScreen(
    viewModel: AppViewModel,
    aoVoltar: () -> Unit
) {
    LaunchedEffect(Unit) {
        viewModel.iniciarEscutaCartoes()
        viewModel.iniciarEscutaConfiguracoes()
    }
    val cartoes by viewModel.cartoes
    val configuracoes by viewModel.configuracoes
    val snackbarHostState = remember { SnackbarHostState() }
    val erro = viewModel.erro.value

    var mostrarNovoCartao by remember { mutableStateOf(false) }
    var cartaoParaEditar by remember { mutableStateOf<Cartao?>(null) }
    var cartaoParaExcluir by remember { mutableStateOf<Cartao?>(null) }
    var expandirDropdownCartaoPadrao by remember { mutableStateOf(false) }
    var verificandoAtualizacao by remember { mutableStateOf(false) }
    var infoAtualizacaoManual by remember { mutableStateOf<InfoAtualizacao?>(null) }
    val escopo = rememberCoroutineScope()

    LaunchedEffect(erro) {
        if (erro != null) {
            snackbarHostState.showSnackbar(erro)
            viewModel.limparErro()
        }
    }

    val cartaoPadraoAtual = cartoes.firstOrNull { it.id == configuracoes.cartaoPadraoId }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Configurações") },
                navigationIcon = {
                    IconButton(onClick = aoVoltar) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Voltar")
                    }
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        floatingActionButton = {
            FloatingActionButton(onClick = { mostrarNovoCartao = true }) {
                Icon(Icons.Default.Add, contentDescription = "Novo cartão")
            }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            Text("Forma de pagamento padrão", style = MaterialTheme.typography.labelLarge)
            Text(
                "Já vem selecionada ao criar uma nova cobrança (pode trocar na hora).",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(8.dp))
            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                SegmentedButton(
                    selected = configuracoes.formaPagamentoPadrao == FormaPagamento.DINHEIRO,
                    onClick = {
                        viewModel.salvarConfiguracoes(configuracoes.copy(formaPagamentoPadrao = FormaPagamento.DINHEIRO))
                    },
                    shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2)
                ) { Text("Dinheiro") }
                SegmentedButton(
                    selected = configuracoes.formaPagamentoPadrao == FormaPagamento.CARTAO,
                    onClick = {
                        viewModel.salvarConfiguracoes(configuracoes.copy(formaPagamentoPadrao = FormaPagamento.CARTAO))
                    },
                    shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2)
                ) { Text("Cartão") }
            }

            if (configuracoes.formaPagamentoPadrao == FormaPagamento.CARTAO) {
                Spacer(Modifier.height(16.dp))
                Text("Cartão padrão", style = MaterialTheme.typography.labelLarge)
                Spacer(Modifier.height(4.dp))
                if (cartoes.isEmpty()) {
                    Text(
                        "Nenhum cartão cadastrado ainda. Toque em + para adicionar.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    ExposedDropdownMenuBox(
                        expanded = expandirDropdownCartaoPadrao,
                        onExpandedChange = { expandirDropdownCartaoPadrao = it }
                    ) {
                        OutlinedTextField(
                            value = cartaoPadraoAtual?.nome ?: "Selecione um cartão",
                            onValueChange = {},
                            readOnly = true,
                            modifier = Modifier.fillMaxWidth().menuAnchor(),
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandirDropdownCartaoPadrao) }
                        )
                        ExposedDropdownMenu(
                            expanded = expandirDropdownCartaoPadrao,
                            onDismissRequest = { expandirDropdownCartaoPadrao = false }
                        ) {
                            cartoes.forEach { cartao ->
                                DropdownMenuItem(
                                    text = { Text(cartao.nome) },
                                    onClick = {
                                        viewModel.salvarConfiguracoes(configuracoes.copy(cartaoPadraoId = cartao.id))
                                        expandirDropdownCartaoPadrao = false
                                    }
                                )
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.height(24.dp))
            Row(
                Modifier
                    .fillMaxWidth()
                    .clickable {
                        viewModel.salvarConfiguracoes(configuracoes.copy(confirmarSaida = !configuracoes.confirmarSaida))
                    },
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text("Confirmar saída", style = MaterialTheme.typography.labelLarge)
                    Text(
                        "Pede confirmação antes de fechar o app pelo botão/gesto de voltar do celular.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Switch(
                    checked = configuracoes.confirmarSaida,
                    onCheckedChange = { viewModel.salvarConfiguracoes(configuracoes.copy(confirmarSaida = it)) }
                )
            }

            Spacer(Modifier.height(16.dp))
            Row(
                Modifier
                    .fillMaxWidth()
                    .clickable {
                        viewModel.salvarConfiguracoes(configuracoes.copy(atualizacaoAutomatica = !configuracoes.atualizacaoAutomatica))
                    },
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text("Atualização automática", style = MaterialTheme.typography.labelLarge)
                    Text(
                        "Checa sozinho, ao abrir o app, se tem uma versão nova disponível.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Switch(
                    checked = configuracoes.atualizacaoAutomatica,
                    onCheckedChange = { viewModel.salvarConfiguracoes(configuracoes.copy(atualizacaoAutomatica = it)) }
                )
            }

            Spacer(Modifier.height(8.dp))
            OutlinedButton(
                onClick = {
                    verificandoAtualizacao = true
                    escopo.launch {
                        val resultado = withContext(Dispatchers.IO) { verificarNovaVersao() }
                        verificandoAtualizacao = false
                        if (resultado != null) {
                            infoAtualizacaoManual = resultado
                        } else {
                            snackbarHostState.showSnackbar("Você já está usando a versão mais recente (${Versao.NOME}).")
                        }
                    }
                },
                enabled = !verificandoAtualizacao,
                modifier = Modifier.fillMaxWidth()
            ) {
                if (verificandoAtualizacao) {
                    CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(8.dp))
                }
                Text("Verificar atualização agora")
            }

            Spacer(Modifier.height(24.dp))
            Text("Cartões cadastrados", style = MaterialTheme.typography.labelLarge)
            Spacer(Modifier.height(4.dp))

            if (cartoes.isEmpty()) {
                Text(
                    "Nenhum cartão ainda. Toque em + pra cadastrar (ex: melhor dia 6, vencimento dia 15).",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                LazyColumn(Modifier.weight(1f)) {
                    items(cartoes, key = { it.id }) { cartao ->
                        ListItem(
                            headlineContent = { Text(cartao.nome) },
                            supportingContent = { Text("Melhor dia ${cartao.melhorDia} • Vence dia ${cartao.diaVencimento}") },
                            trailingContent = {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    IconButton(onClick = { cartaoParaEditar = cartao }) {
                                        Icon(Icons.Default.Edit, contentDescription = "Editar cartão")
                                    }
                                    IconButton(onClick = { cartaoParaExcluir = cartao }) {
                                        Icon(Icons.Default.Delete, contentDescription = "Excluir cartão")
                                    }
                                }
                            },
                            modifier = Modifier.clickable { cartaoParaEditar = cartao }
                        )
                        HorizontalDivider()
                    }
                }
            }

            Spacer(Modifier.height(24.dp))
            Text(
                "Versão do app: ${Versao.NOME}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }

    if (mostrarNovoCartao) {
        CartaoFormDialog(
            cartaoExistente = null,
            onConfirmar = { cartao ->
                viewModel.salvarCartao(cartao) { mostrarNovoCartao = false }
            },
            onCancelar = { mostrarNovoCartao = false }
        )
    }

    cartaoParaEditar?.let { cartao ->
        CartaoFormDialog(
            cartaoExistente = cartao,
            onConfirmar = { atualizado ->
                viewModel.salvarCartao(atualizado) { cartaoParaEditar = null }
            },
            onCancelar = { cartaoParaEditar = null }
        )
    }

    cartaoParaExcluir?.let { cartao ->
        AlertDialog(
            onDismissRequest = { cartaoParaExcluir = null },
            title = { Text("Excluir cartão") },
            text = { Text("Tem certeza que deseja excluir \"${cartao.nome}\"? Cobranças já criadas com ele não serão alteradas.") },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.excluirCartao(cartao.id)
                    cartaoParaExcluir = null
                }) { Text("Excluir") }
            },
            dismissButton = {
                TextButton(onClick = { cartaoParaExcluir = null }) { Text("Cancelar") }
            }
        )
    }

    infoAtualizacaoManual?.let { info ->
        val context = LocalContext.current
        AlertDialog(
            onDismissRequest = { infoAtualizacaoManual = null },
            title = { Text("Nova versão disponível") },
            text = {
                Text("Tem uma versão nova do app (${info.nome}). Você está usando a ${Versao.NOME}. Quer atualizar agora?")
            },
            confirmButton = {
                TextButton(onClick = {
                    infoAtualizacaoManual = null
                    if (info.urlDownload.isNotBlank()) {
                        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(info.urlDownload)))
                    }
                }) { Text("Atualizar") }
            },
            dismissButton = {
                TextButton(onClick = { infoAtualizacaoManual = null }) { Text("Agora não") }
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CartaoFormDialog(
    cartaoExistente: Cartao?,
    onConfirmar: (Cartao) -> Unit,
    onCancelar: () -> Unit
) {
    var nome by remember { mutableStateOf(cartaoExistente?.nome ?: "") }
    var melhorDiaTexto by remember { mutableStateOf(cartaoExistente?.melhorDia?.toString() ?: "1") }
    var diaVencimentoTexto by remember { mutableStateOf(cartaoExistente?.diaVencimento?.toString() ?: "10") }
    var tentouSalvar by remember { mutableStateOf(false) }
    val nomeInvalido = tentouSalvar && nome.isBlank()

    AlertDialog(
        onDismissRequest = onCancelar,
        title = { Text(if (cartaoExistente == null) "Novo cartão" else "Editar cartão") },
        text = {
            Column {
                OutlinedTextField(
                    value = nome,
                    onValueChange = { nome = it },
                    label = { Text("Nome (ex: Nubank) *") },
                    isError = nomeInvalido,
                    supportingText = { if (nomeInvalido) Text("Campo obrigatório") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                Row {
                    OutlinedTextField(
                        value = melhorDiaTexto,
                        onValueChange = { melhorDiaTexto = it },
                        label = { Text("Melhor dia") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(Modifier.width(8.dp))
                    OutlinedTextField(
                        value = diaVencimentoTexto,
                        onValueChange = { diaVencimentoTexto = it },
                        label = { Text("Vencimento") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                }
                Spacer(Modifier.height(4.dp))
                Text(
                    "Compras a partir do \"melhor dia\" caem na fatura que vence no mês seguinte.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        },
        confirmButton = {
            TextButton(onClick = {
                tentouSalvar = true
                if (nome.isBlank()) return@TextButton
                val melhorDia = melhorDiaTexto.toIntOrNull()?.coerceIn(1, 31) ?: 1
                val diaVencimento = diaVencimentoTexto.toIntOrNull()?.coerceIn(1, 31) ?: 10
                onConfirmar(
                    (cartaoExistente ?: Cartao()).copy(
                        nome = nome,
                        melhorDia = melhorDia,
                        diaVencimento = diaVencimento
                    )
                )
            }) { Text(if (cartaoExistente == null) "Criar" else "Salvar") }
        },
        dismissButton = {
            TextButton(onClick = onCancelar) { Text("Cancelar") }
        }
    )
}
