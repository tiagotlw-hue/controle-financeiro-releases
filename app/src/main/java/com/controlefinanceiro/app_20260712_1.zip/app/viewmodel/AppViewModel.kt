package com.controlefinanceiro.app.viewmodel

import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.controlefinanceiro.app.data.Cartao
import com.controlefinanceiro.app.data.Categoria
import com.controlefinanceiro.app.data.Cliente
import com.controlefinanceiro.app.data.Configuracoes
import com.controlefinanceiro.app.data.FirebaseRepository
import com.controlefinanceiro.app.data.FormaPagamento
import com.controlefinanceiro.app.data.Movimentacao
import com.controlefinanceiro.app.data.Pagamento
import com.controlefinanceiro.app.data.ParcelaRef
import com.controlefinanceiro.app.data.ParcelaUtils
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.launch

class AppViewModel : ViewModel() {

    private val repo = FirebaseRepository()

    val clientes = mutableStateOf<List<Cliente>>(emptyList())
    val categorias = mutableStateOf<List<Categoria>>(emptyList())
    val movimentacoes = mutableStateOf<List<Movimentacao>>(emptyList())
    val cartoes = mutableStateOf<List<Cartao>>(emptyList())
    val configuracoes = mutableStateOf(Configuracoes())
    val carregando = mutableStateOf(false)
    val erro = mutableStateOf<String?>(null)

    private var jobClientes: Job? = null
    private var jobCategorias: Job? = null
    private var jobMovimentacoes: Job? = null
    private var jobCartoes: Job? = null
    private var jobConfiguracoes: Job? = null

    fun usuarioLogado() = repo.usuarioLogado()

    fun limparErro() {
        erro.value = null
    }

    /** Começa a escuta contínua dos clientes. Só deve ser chamada quando já existe um
     *  usuário autenticado (por isso não fica no init: instanciar o ViewModel cedo
     *  demais, antes do login, fazia a escuta falhar e nunca mais religar).
     *  Continua funcionando offline normalmente: entrega o cache local na hora e
     *  atualiza sozinho quando sincroniza com o servidor. */
    fun iniciarEscutaClientes() {
        if (jobClientes != null) return
        jobClientes = viewModelScope.launch {
            repo.escutarClientes()
                .catch { e -> erro.value = e.message }
                .collect { clientes.value = it }
        }
    }

    /** Escuta contínua dos cartões cadastrados (configuração global do app). */
    fun iniciarEscutaCartoes() {
        if (jobCartoes != null) return
        jobCartoes = viewModelScope.launch {
            repo.escutarCartoes()
                .catch { e -> erro.value = e.message }
                .collect { cartoes.value = it }
        }
    }

    /** Escuta contínua das preferências gerais (forma de pagamento padrão etc). */
    fun iniciarEscutaConfiguracoes() {
        if (jobConfiguracoes != null) return
        jobConfiguracoes = viewModelScope.launch {
            repo.escutarConfiguracoes()
                .catch { e -> erro.value = e.message }
                .collect { configuracoes.value = it }
        }
    }

    fun salvarCartao(cartao: Cartao, aoConcluir: () -> Unit = {}) {
        viewModelScope.launch {
            try {
                repo.salvarCartao(cartao)
                aoConcluir()
            } catch (e: Exception) {
                erro.value = e.message
            }
        }
    }

    fun excluirCartao(cartaoId: String) {
        viewModelScope.launch {
            try {
                repo.excluirCartao(cartaoId)
            } catch (e: Exception) {
                erro.value = e.message
            }
        }
    }

    fun salvarConfiguracoes(config: Configuracoes) {
        viewModelScope.launch {
            try {
                repo.salvarConfiguracoes(config)
            } catch (e: Exception) {
                erro.value = e.message
            }
        }
    }

    /** Começa (ou reinicia, se o cliente mudou) a escuta das categorias desse cliente. */
    fun observarCategorias(clienteId: String) {
        jobCategorias?.cancel()
        jobCategorias = viewModelScope.launch {
            repo.escutarCategorias(clienteId)
                .catch { e -> erro.value = e.message }
                .collect { categorias.value = it }
        }
    }

    fun criarCategoria(clienteId: String, nome: String, tipo: String, aoConcluir: (Categoria) -> Unit = {}) {
        viewModelScope.launch {
            try {
                val categoria = Categoria(clienteId = clienteId, nome = nome, tipo = tipo)
                val id = repo.salvarCategoria(clienteId, categoria)
                aoConcluir(categoria.copy(id = id))
            } catch (e: Exception) {
                erro.value = e.message
            }
        }
    }

    /** Edita uma categoria já existente (por enquanto só o nome é alterado pela tela;
     *  o tipo não é reeditável para não deixar movimentações antigas inconsistentes). */
    fun editarCategoria(clienteId: String, categoria: Categoria, aoConcluir: () -> Unit = {}) {
        viewModelScope.launch {
            try {
                repo.salvarCategoria(clienteId, categoria)
                aoConcluir()
            } catch (e: Exception) {
                erro.value = e.message
            }
        }
    }

    fun excluirCategoria(clienteId: String, categoriaId: String, aoConcluir: () -> Unit = {}) {
        viewModelScope.launch {
            try {
                repo.excluirCategoria(clienteId, categoriaId)
                aoConcluir()
            } catch (e: Exception) {
                erro.value = e.message
            }
        }
    }

    /** Começa (ou reinicia, se mudou) a escuta das movimentações de uma categoria. */
    fun observarMovimentacoes(clienteId: String, categoriaId: String) {
        jobMovimentacoes?.cancel()
        jobMovimentacoes = viewModelScope.launch {
            carregando.value = true
            repo.escutarMovimentacoes(clienteId, categoriaId)
                .catch { e ->
                    erro.value = e.message
                    carregando.value = false
                }
                .collect { lista ->
                    movimentacoes.value = lista
                    carregando.value = false
                }
        }
    }

    fun salvarCliente(cliente: Cliente, aoConcluir: () -> Unit = {}) {
        viewModelScope.launch {
            try {
                repo.salvarCliente(cliente)
                aoConcluir()
            } catch (e: Exception) {
                erro.value = e.message
            }
        }
    }

    fun excluirCliente(clienteId: String) {
        viewModelScope.launch {
            try {
                repo.excluirCliente(clienteId)
            } catch (e: Exception) {
                erro.value = e.message
            }
        }
    }

    private fun gerarParcelasConforme(
        formaPagamento: String,
        cartao: Cartao?,
        valorTotal: Double,
        numParcelas: Int,
        diaVencimento: Int,
        dataCriacao: Long
    ) = if (formaPagamento == FormaPagamento.CARTAO && cartao != null) {
        ParcelaUtils.gerarParcelasCartao(valorTotal, numParcelas, dataCriacao, cartao.melhorDia, cartao.diaVencimento)
    } else if (formaPagamento == FormaPagamento.DINHEIRO) {
        // Dinheiro é sempre à vista: uma única duplicata, vencendo no mesmo dia da cobrança.
        ParcelaUtils.gerarParcelaAvista(valorTotal, dataCriacao)
    } else {
        ParcelaUtils.gerarParcelas(valorTotal, numParcelas, dataCriacao, diaVencimento)
    }

    fun criarMovimentacao(
        clienteId: String,
        categoriaId: String,
        tipo: String,
        descricao: String,
        valorTotal: Double,
        numParcelas: Int,
        diaVencimento: Int,
        formaPagamento: String = FormaPagamento.DINHEIRO,
        cartao: Cartao? = null,
        dataCriacao: Long = System.currentTimeMillis(),
        valoresManuaisParcelas: Map<Int, Double> = emptyMap(),
        aoConcluir: () -> Unit = {}
    ) {
        viewModelScope.launch {
            try {
                val parcelasBase = gerarParcelasConforme(formaPagamento, cartao, valorTotal, numParcelas, diaVencimento, dataCriacao)
                val parcelas = ParcelaUtils.aplicarValoresManuais(parcelasBase, valoresManuaisParcelas, valorTotal)
                val movimentacao = Movimentacao(
                    clienteId = clienteId,
                    categoriaId = categoriaId,
                    tipo = tipo,
                    descricao = descricao,
                    valorTotal = valorTotal,
                    numParcelas = numParcelas,
                    diaVencimento = diaVencimento,
                    dataCriacao = dataCriacao,
                    formaPagamento = formaPagamento,
                    cartaoId = cartao?.id ?: "",
                    parcelas = parcelas
                )
                repo.salvarMovimentacao(clienteId, categoriaId, movimentacao)
                aoConcluir()
            } catch (e: Exception) {
                erro.value = e.message
            }
        }
    }

    /** Edita uma movimentação já existente. Só deve ser chamada se ela ainda não tiver
     *  nenhum pagamento (a tela já checa `podeEditarOuExcluir` antes de permitir isso). */
    fun editarMovimentacao(
        movimentacaoExistente: Movimentacao,
        descricao: String,
        valorTotal: Double,
        numParcelas: Int,
        diaVencimento: Int,
        formaPagamento: String,
        cartao: Cartao?,
        dataCriacao: Long,
        valoresManuaisParcelas: Map<Int, Double> = emptyMap(),
        aoConcluir: () -> Unit = {}
    ) {
        viewModelScope.launch {
            try {
                val parcelasBase = gerarParcelasConforme(formaPagamento, cartao, valorTotal, numParcelas, diaVencimento, dataCriacao)
                val parcelas = ParcelaUtils.aplicarValoresManuais(parcelasBase, valoresManuaisParcelas, valorTotal)
                val atualizada = movimentacaoExistente.copy(
                    descricao = descricao,
                    valorTotal = valorTotal,
                    numParcelas = numParcelas,
                    diaVencimento = diaVencimento,
                    dataCriacao = dataCriacao,
                    formaPagamento = formaPagamento,
                    cartaoId = cartao?.id ?: "",
                    parcelas = parcelas
                )
                repo.salvarMovimentacao(movimentacaoExistente.clienteId, movimentacaoExistente.categoriaId, atualizada)
                aoConcluir()
            } catch (e: Exception) {
                erro.value = e.message
            }
        }
    }

    /** Edita só a data/hora (e a descrição) de uma movimentação que já tem baixa registrada
     *  — nesse caso não dá pra mexer em valor, número de parcelas, forma de pagamento etc.,
     *  só recalcula os vencimentos das duplicatas a partir da nova data, preservando o que
     *  já foi pago em cada uma. */
    fun editarDataMovimentacao(
        movimentacaoExistente: Movimentacao,
        novaDescricao: String,
        novaDataCriacao: Long,
        aoConcluir: () -> Unit = {}
    ) {
        viewModelScope.launch {
            try {
                val cartao = cartoes.value.firstOrNull { it.id == movimentacaoExistente.cartaoId }
                val parcelasModelo = gerarParcelasConforme(
                    movimentacaoExistente.formaPagamento,
                    cartao,
                    movimentacaoExistente.valorTotal,
                    movimentacaoExistente.numParcelas,
                    movimentacaoExistente.diaVencimento,
                    novaDataCriacao
                )
                val novasParcelas = ParcelaUtils.reaplicarVencimentos(movimentacaoExistente.parcelas, parcelasModelo)
                val atualizada = movimentacaoExistente.copy(
                    descricao = novaDescricao,
                    dataCriacao = novaDataCriacao,
                    parcelas = novasParcelas
                )
                repo.salvarMovimentacao(movimentacaoExistente.clienteId, movimentacaoExistente.categoriaId, atualizada)
                aoConcluir()
            } catch (e: Exception) {
                erro.value = e.message
            }
        }
    }

    fun excluirMovimentacao(clienteId: String, categoriaId: String, movimentacaoId: String, aoConcluir: () -> Unit = {}) {
        viewModelScope.launch {
            try {
                repo.excluirMovimentacao(clienteId, categoriaId, movimentacaoId)
                aoConcluir()
            } catch (e: Exception) {
                erro.value = e.message
            }
        }
    }

    /** Dá baixa distribuindo `valorPago` pelas parcelas selecionadas (de uma ou mais
     *  movimentações da mesma categoria), sempre respeitando a ordem em que foram
     *  passadas (a tela já manda as mais antigas primeiro). */
    fun darBaixa(
        clienteId: String,
        categoriaId: String,
        selecionadas: List<ParcelaRef>,
        valorPago: Double,
        descricaoManual: String,
        dataBaixa: Long = System.currentTimeMillis(),
        proporcional: Boolean = false,
        aoConcluir: () -> Unit = {}
    ) {
        viewModelScope.launch {
            try {
                val movimentacoesPorId = movimentacoes.value.associateBy { it.id }
                val atualizadas = ParcelaUtils.aplicarBaixaConsolidada(
                    movimentacoesPorId = movimentacoesPorId,
                    selecionadas = selecionadas,
                    valorPago = valorPago,
                    descricaoManual = descricaoManual,
                    dataBaixa = dataBaixa,
                    proporcional = proporcional
                )
                repo.aplicarBaixa(clienteId, categoriaId, atualizadas)
                aoConcluir()
            } catch (e: Exception) {
                erro.value = e.message
            }
        }
    }

    /** Exclui uma baixa específica, devolvendo as duplicatas afetadas ao estado de antes. */
    fun excluirBaixa(
        clienteId: String,
        categoriaId: String,
        movimentacaoId: String,
        pagamento: Pagamento,
        aoConcluir: () -> Unit = {}
    ) {
        viewModelScope.launch {
            try {
                repo.excluirBaixa(clienteId, categoriaId, movimentacaoId, pagamento)
                aoConcluir()
            } catch (e: Exception) {
                erro.value = e.message
            }
        }
    }

    /** Exclui de uma vez todas as partes de uma baixa que foi dividida entre duplicatas
     *  de mais de uma movimentação (mesmo baixaId). Devolve todas as duplicatas afetadas,
     *  em todas as movimentações envolvidas, ao estado de antes. */
    fun excluirBaixaGrupo(
        clienteId: String,
        categoriaId: String,
        itens: List<Pair<String, Pagamento>>,
        aoConcluir: () -> Unit = {}
    ) {
        viewModelScope.launch {
            try {
                itens.forEach { (movimentacaoId, pagamento) ->
                    repo.excluirBaixa(clienteId, categoriaId, movimentacaoId, pagamento)
                }
                aoConcluir()
            } catch (e: Exception) {
                erro.value = e.message
            }
        }
    }

    /** Edita a data/hora de uma baixa, em todas as movimentações que ela afeta (quando
     *  ela foi dividida entre mais de uma de uma vez). Valores e parcelas continuam
     *  os mesmos, só a data muda. */
    fun editarDataBaixaGrupo(
        clienteId: String,
        categoriaId: String,
        itens: List<Pair<String, Pagamento>>,
        novaData: Long,
        aoConcluir: () -> Unit = {}
    ) {
        viewModelScope.launch {
            try {
                itens.forEach { (movimentacaoId, pagamento) ->
                    repo.editarDataBaixa(clienteId, categoriaId, movimentacaoId, pagamento, novaData)
                }
                aoConcluir()
            } catch (e: Exception) {
                erro.value = e.message
            }
        }
    }
}
