package com.controlefinanceiro.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.controlefinanceiro.app.data.ParcelaRef
import com.controlefinanceiro.app.data.ParcelaUtils
import com.controlefinanceiro.app.data.TipoMovimentacao
import com.controlefinanceiro.app.viewmodel.AppViewModel
import java.text.SimpleDateFormat
import java.util.Locale

private val fmtData = SimpleDateFormat("dd/MM/yyyy", Locale("pt", "BR"))

/** Dá baixa (pagamento/recebimento) nas duplicatas em aberto de uma categoria.
 *  O tipo vem fixo da categoria; opcionalmente pode ser filtrado para uma única
 *  movimentação (quando aberto a partir do detalhe dela). */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SaidaScreen(
    viewModel: AppViewModel,
    clienteId: String,
    categoriaId: String,
    tipo: String,
    movimentacaoIdFiltro: String? = null,
    aoVoltar: () -> Unit
) {
    val movimentacoes by viewModel.movimentacoes
    var valorTexto by remember { mutableStateOf("") }
    var descricaoManual by remember { mutableStateOf("") }
    var salvando by remember { mutableStateOf(false) }
    val snackbarHostState = remember { SnackbarHostState() }
    val erro = viewModel.erro.value

    LaunchedEffect(erro) {
        if (erro != null) {
            salvando = false
            snackbarHostState.showSnackbar(erro)
            viewModel.limparErro()
        }
    }

    // Junta as duplicatas em aberto de todas as movimentações da categoria (mais antigas
    // primeiro) — ou só da movimentação específica, se veio da tela de detalhe dela.
    val abertas = remember(movimentacoes, movimentacaoIdFiltro) {
        movimentacoes
            .filter { movimentacaoIdFiltro == null || it.id == movimentacaoIdFiltro }
            .flatMap { mov ->
                mov.parcelas.filter { it.status != "paga" }
                    .map { p -> ParcelaRef(mov.id, mov.descricao, p) }
            }
            .sortedBy { it.parcela.dataVencimento }
    }

    val valorPago = valorTexto.replace(",", ".").toDoubleOrNull() ?: 0.0

    var selecaoManualAtiva by remember { mutableStateOf(false) }
    var selecionadas by remember { mutableStateOf<Set<Pair<String, Int>>>(emptySet()) }

    // Modo 1: a pessoa digita um valor -> seleciona automaticamente as duplicatas
    // mais antigas até completar esse valor.
    LaunchedEffect(valorPago, selecaoManualAtiva, abertas) {
        if (!selecaoManualAtiva) {
            selecionadas = ParcelaUtils.selecionarMaisAntigasAte(abertas, valorPago)
        }
    }

    val totalSelecionado = abertas.filter { (it.movimentacaoId to it.parcela.numero) in selecionadas }
        .sumOf { it.parcela.valorOriginal - it.parcela.valorPago }

    // Modo 2: a pessoa marca/desmarca duplicatas manualmente -> o campo de valor
    // é atualizado sozinho com a soma das que estão selecionadas.
    LaunchedEffect(selecionadas, selecaoManualAtiva) {
        if (selecaoManualAtiva) {
            valorTexto = if (totalSelecionado > 0.0) {
                "%.2f".format(totalSelecionado).replace(".", ",")
            } else ""
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (tipo == TipoMovimentacao.RECEBER) "Registrar recebimento" else "Registrar pagamento") },
                navigationIcon = {
                    IconButton(onClick = aoVoltar) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Cancelar")
                    }
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            OutlinedTextField(
                value = valorTexto,
                onValueChange = {
                    // Se a pessoa volta a digitar direto no campo, some com a seleção
                    // manual e volta para o modo "seleciona automático pelo valor".
                    selecaoManualAtiva = false
                    valorTexto = it
                },
                label = { Text("Valor (R$)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(4.dp))
            OutlinedTextField(
                value = descricaoManual,
                onValueChange = { descricaoManual = it },
                label = { Text("Observação (opcional)") },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(Modifier.height(12.dp))
            if (abertas.isEmpty()) {
                Text(
                    "Não há duplicatas em aberto para dar baixa.",
                    style = MaterialTheme.typography.bodyMedium
                )
            } else {
                Text(
                    "Digite um valor (seleciona as mais antigas automaticamente) ou toque " +
                        "nas duplicatas abaixo para selecionar manualmente:",
                    style = MaterialTheme.typography.bodySmall
                )
                LazyColumn(Modifier.weight(1f)) {
                    items(abertas, key = { it.movimentacaoId + "_" + it.parcela.numero }) { ref ->
                        val chave = ref.movimentacaoId to ref.parcela.numero
                        val marcada = chave in selecionadas
                        val p = ref.parcela
                        ListItem(
                            headlineContent = {
                                Text("${ref.movimentacaoDescricao} — duplicata ${p.numero}")
                            },
                            supportingContent = {
                                val faltante = p.valorOriginal - p.valorPago
                                Text(
                                    "Vence ${fmtData.format(java.util.Date(p.dataVencimento))} — " +
                                        if (p.status == "parcial")
                                            "falta R$ %.2f (de R$ %.2f)".format(faltante, p.valorOriginal)
                                        else
                                            "R$ %.2f".format(faltante)
                                )
                            },
                            trailingContent = {
                                Checkbox(
                                    checked = marcada,
                                    onCheckedChange = { checado ->
                                        selecaoManualAtiva = true
                                        selecionadas = if (checado) selecionadas + chave else selecionadas - chave
                                    }
                                )
                            }
                        )
                        HorizontalDivider()
                    }
                }

                Spacer(Modifier.height(8.dp))
                Text("Total das duplicatas selecionadas: R$ %.2f".format(totalSelecionado))
                if (valorPago > 0 && valorPago < totalSelecionado - 0.01) {
                    Text(
                        "O valor é menor que o total selecionado: a última duplicata ficará parcialmente paga.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error
                    )
                }

                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth()) {
                    OutlinedButton(
                        onClick = aoVoltar,
                        enabled = !salvando,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Cancelar")
                    }
                    Spacer(Modifier.width(8.dp))
                    Button(
                        enabled = !salvando && valorPago > 0 && selecionadas.isNotEmpty(),
                        onClick = {
                            salvando = true
                            val selecionadasOrdenadas = abertas.filter {
                                (it.movimentacaoId to it.parcela.numero) in selecionadas
                            }
                            viewModel.darBaixa(
                                clienteId = clienteId,
                                categoriaId = categoriaId,
                                selecionadas = selecionadasOrdenadas,
                                valorPago = valorPago,
                                descricaoManual = descricaoManual
                            ) {
                                salvando = false
                                aoVoltar()
                            }
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        if (salvando) {
                            CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                            Spacer(Modifier.width(8.dp))
                        }
                        Text("Confirmar baixa")
                    }
                }
            }
        }
    }
}
