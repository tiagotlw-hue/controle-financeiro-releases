package com.controlefinanceiro.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.ui.graphics.Color

private val PrimaryColor = Color(0xFF2E7D32)
private val LightColors = lightColorScheme(primary = PrimaryColor)
private val DarkColors = darkColorScheme(primary = PrimaryColor)

@Composable
fun ControleFinanceiroTheme(content: @Composable () -> Unit) {
    val colors = if (isSystemInDarkTheme()) DarkColors else LightColors
    MaterialTheme(colorScheme = colors, content = content)
}
