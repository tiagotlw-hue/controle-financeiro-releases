package com.controlefinanceiro.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.controlefinanceiro.app.data.Movimentacao
import com.controlefinanceiro.app.data.Pagamento
import com.controlefinanceiro.app.viewmodel.AppViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val fmtData = SimpleDateFormat("dd/MM/yyyy", Locale("pt", "BR"))
private val fmtDataHora = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("pt", "BR"))
private val VerdeSaldo = Color(0xFF2E7D32)
private val VermelhoSaldo = Color(0xFFC62828)

/** Tela simples que mostra apenas as duplicatas quitadas por uma baixa específica
 *  (aberta a partir da lista de movimentações ou do extrato do cliente), com opção
 *  de excluir essa baixa (devolve as duplicatas afetadas ao estado de antes). */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BaixaDetalheScreen(
    viewModel: AppViewModel,
    clienteId: String,
    categoriaId: String,
    movimentacao: Movimentacao,
    pagamento: Pagamento,
    aoExcluida: () -> Unit,
    aoVoltar: () -> Unit
) {
    val duplicatasQuitadas = movimentacao.parcelas
        .filter { it.numero in pagamento.parcelasNumeros }
        .sortedBy { it.numero }
    var mostrarConfirmacaoExclusao by remember { mutableStateOf(false) }
    var excluindo by remember { mutableStateOf(false) }
    val snackbarHostState = remember { SnackbarHostState() }
    val erro = viewModel.erro.value

    LaunchedEffect(erro) {
        if (erro != null) {
            excluindo = false
            snackbarHostState.showSnackbar(erro)
            viewModel.limparErro()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Detalhe da baixa") },
                navigationIcon = {
                    IconButton(onClick = aoVoltar) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Voltar")
                    }
                },
                actions = {
                    IconButton(onClick = { mostrarConfirmacaoExclusao = true }) {
                        Icon(Icons.Default.Delete, contentDescription = "Excluir baixa")
                    }
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            Text(movimentacao.descricao, style = MaterialTheme.typography.titleMedium)
            Text(
                "R$ %.2f".format(pagamento.valorPago),
                style = MaterialTheme.typography.headlineMedium,
                color = VerdeSaldo
            )
            Text(
                fmtDataHora.format(Date(pagamento.data)),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            if (pagamento.descricao.isNotBlank()) {
                Spacer(Modifier.height(8.dp))
                Text(pagamento.descricao, style = MaterialTheme.typography.bodyMedium)
            }

            Spacer(Modifier.height(16.dp))
            Text("Duplicatas quitadas nesta baixa", style = MaterialTheme.typography.labelLarge)
            Spacer(Modifier.height(4.dp))

            if (duplicatasQuitadas.isEmpty()) {
                Text(
                    "Nenhuma duplicata encontrada para esta baixa.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                LazyColumn(Modifier.weight(1f)) {
                    items(duplicatasQuitadas) { p ->
                        val valorAplicadoNestaBaixa = pagamento.parcelasAplicadas[p.numero.toString()] ?: 0.0
                        val valorQueFalta = (p.valorOriginal - p.valorPago).coerceAtLeast(0.0)
                        ListItem(
                            headlineContent = { Text("Duplicata ${p.numero}/${movimentacao.numParcelas}") },
                            supportingContent = {
                                Column {
                                    Text("Vencia ${fmtData.format(Date(p.dataVencimento))}")
                                    Text("Valor da duplicata: R$ %.2f".format(p.valorOriginal))
                                }
                            },
                            trailingContent = {
                                Column(horizontalAlignment = androidx.compose.ui.Alignment.End) {
                                    Text(
                                        "Pago: R$ %.2f".format(valorAplicadoNestaBaixa),
                                        color = VerdeSaldo,
                                        style = MaterialTheme.typography.bodyMedium
                                    )
                                    if (valorQueFalta > 0.01) {
                                        Text(
                                            "Falta: R$ %.2f".format(valorQueFalta),
                                            color = VermelhoSaldo,
                                            style = MaterialTheme.typography.bodySmall
                                        )
                                    } else {
                                        Text(
                                            "Quitada",
                                            color = VerdeSaldo,
                                            style = MaterialTheme.typography.bodySmall
                                        )
                                    }
                                }
                            }
                        )
                        HorizontalDivider()
                    }
                }
            }
        }
    }

    if (mostrarConfirmacaoExclusao) {
        AlertDialog(
            onDismissRequest = { if (!excluindo) mostrarConfirmacaoExclusao = false },
            title = { Text("Excluir baixa") },
            text = {
                Text(
                    "Tem certeza que deseja excluir essa baixa de R$ %.2f? ".format(pagamento.valorPago) +
                        "As duplicatas afetadas voltam a ficar em aberto (ou parciais). Essa ação não pode ser desfeita."
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        excluindo = true
                        viewModel.excluirBaixa(clienteId, categoriaId, movimentacao.id, pagamento) {
                            excluindo = false
                            mostrarConfirmacaoExclusao = false
                            aoExcluida()
                        }
                    },
                    enabled = !excluindo
                ) { Text("Excluir") }
            },
            dismissButton = {
                TextButton(
                    onClick = { mostrarConfirmacaoExclusao = false },
                    enabled = !excluindo
                ) { Text("Cancelar") }
            }
        )
    }
}
