package com.controlefinanceiro.app.data

import java.util.Calendar
import java.util.UUID
import kotlin.math.min
import kotlin.math.round

object ParcelaUtils {

    /**
     * Gera as parcelas/duplicatas de uma movimentação paga em dinheiro.
     * Cada parcela vence sempre no mesmo "diaVencimento" (ex: dia 15),
     * começando no mês seguinte à criação. Se o mês não tiver esse dia
     * (ex: dia 31 em fevereiro), usa o último dia do mês.
     * A diferença de arredondamento é jogada na última parcela.
     */
    fun gerarParcelas(
        valorTotal: Double,
        numParcelas: Int,
        dataCriacao: Long,
        diaVencimento: Int
    ): List<Parcela> {
        require(numParcelas >= 1) { "Número de parcelas deve ser >= 1" }
        val calendarBase = Calendar.getInstance().apply { timeInMillis = dataCriacao }
        return gerarParcelasAPartirDoMesBase(valorTotal, numParcelas, calendarBase, diaVencimento, offsetMeses = 1)
    }

    /**
     * Gera as parcelas/duplicatas de uma movimentação paga no cartão, seguindo a regra
     * de fechamento de fatura: se o dia da compra for >= "melhorDia" (dia de fechamento),
     * a primeira parcela vai pra fatura que vence no "diaVencimento" do mês SEGUINTE ao da
     * compra. Se for antes do "melhorDia", vai pra fatura que vence no "diaVencimento" do
     * MESMO mês da compra. As parcelas seguintes vencem sempre um mês depois da anterior.
     */
    fun gerarParcelasCartao(
        valorTotal: Double,
        numParcelas: Int,
        dataCriacao: Long,
        melhorDia: Int,
        diaVencimentoCartao: Int
    ): List<Parcela> {
        require(numParcelas >= 1) { "Número de parcelas deve ser >= 1" }
        val calCompra = Calendar.getInstance().apply { timeInMillis = dataCriacao }
        val diaCompra = calCompra.get(Calendar.DAY_OF_MONTH)
        val calBase = calCompra.clone() as Calendar
        if (diaCompra >= melhorDia) {
            calBase.add(Calendar.MONTH, 1)
        }
        return gerarParcelasAPartirDoMesBase(valorTotal, numParcelas, calBase, diaVencimentoCartao, offsetMeses = 0)
    }

    private fun gerarParcelasAPartirDoMesBase(
        valorTotal: Double,
        numParcelas: Int,
        calendarBase: Calendar,
        diaVencimento: Int,
        offsetMeses: Int
    ): List<Parcela> {
        val valorParcelaBase = round((valorTotal / numParcelas) * 100) / 100.0
        val parcelas = mutableListOf<Parcela>()
        var somaAcumulada = 0.0

        for (i in 1..numParcelas) {
            val cal = calendarBase.clone() as Calendar
            cal.add(Calendar.MONTH, offsetMeses + (i - 1))
            val ultimoDiaDoMes = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
            cal.set(Calendar.DAY_OF_MONTH, min(diaVencimento, ultimoDiaDoMes))
            cal.set(Calendar.HOUR_OF_DAY, 0)
            cal.set(Calendar.MINUTE, 0)
            cal.set(Calendar.SECOND, 0)
            cal.set(Calendar.MILLISECOND, 0)

            val valorDaParcela = if (i == numParcelas) {
                round((valorTotal - somaAcumulada) * 100) / 100.0
            } else {
                valorParcelaBase
            }
            somaAcumulada += valorDaParcela

            parcelas.add(
                Parcela(
                    numero = i,
                    valorOriginal = valorDaParcela,
                    dataVencimento = cal.timeInMillis
                )
            )
        }
        return parcelas
    }

    /**
     * Aplica valores digitados manualmente pra cada duplicata (exceto a última), sobre
     * uma lista já gerada por [gerarParcelas]/[gerarParcelasCartao] — só troca o
     * `valorOriginal` de cada uma, mantendo data de vencimento e tudo mais como estava.
     * A ÚLTIMA duplicata nunca é editada diretamente: o valor dela é sempre recalculado
     * como "o que sobra" (valorTotal menos a soma de todas as outras), pra garantir que a
     * soma de todas as duplicatas sempre feche certinho com o valor total da cobrança.
     *
     * `valoresManuais` é um mapa número da parcela -> valor digitado; parcelas que não
     * estão no mapa continuam com o valor gerado automaticamente (split igual).
     */
    fun aplicarValoresManuais(
        parcelasBase: List<Parcela>,
        valoresManuais: Map<Int, Double>,
        valorTotal: Double
    ): List<Parcela> {
        if (parcelasBase.isEmpty()) return parcelasBase
        val numUltima = parcelasBase.maxOf { it.numero }
        var somaOutras = 0.0
        val comValorManual = parcelasBase.map { p ->
            if (p.numero == numUltima) {
                p // a última é ajustada depois, abaixo
            } else {
                val valor = round((valoresManuais[p.numero] ?: p.valorOriginal) * 100) / 100.0
                somaOutras += valor
                p.copy(valorOriginal = valor)
            }
        }
        return comValorManual.map { p ->
            if (p.numero == numUltima) {
                p.copy(valorOriginal = round((valorTotal - somaOutras) * 100) / 100.0)
            } else {
                p
            }
        }
    }

    /**
     * Dado o valor digitado, seleciona automaticamente as parcelas em aberto mais antigas
     * (já ordenadas) até esse valor se esgotar. Usado tanto para pré-seleção automática
     * quanto para saber o total das parcelas marcadas manualmente.
     */
    fun selecionarMaisAntigasAte(abertasOrdenadas: List<ParcelaRef>, valor: Double): Set<Pair<String, Int>> {
        val selecionadas = mutableSetOf<Pair<String, Int>>()
        var restante = valor
        for (ref in abertasOrdenadas) {
            if (restante <= 0.0) break
            val faltante = round((ref.parcela.valorOriginal - ref.parcela.valorPago) * 100) / 100.0
            selecionadas.add(ref.movimentacaoId to ref.parcela.numero)
            restante -= faltante
        }
        return selecionadas
    }

    /**
     * Aplica uma baixa (pagamento/recebimento) espalhando o valor pelas parcelas
     * selecionadas. Parcelas de várias movimentações podem estar envolvidas (por isso
     * o retorno é um mapa por movimentação). Guarda quanto foi aplicado em cada parcela
     * (parcelasAplicadas), pra dar pra reverter a baixa depois.
     *
     * Duas formas de distribuir o valor entre as parcelas selecionadas:
     * - `proporcional = false` (padrão): preenche na ordem em que aparecem em
     *   `selecionadas`, quitando cada uma por completo antes de passar pra próxima —
     *   se o valor não cobrir tudo, a última parcela tocada fica "parcial". É o
     *   comportamento certo quando a pessoa digitou um valor livre (ou um percentual
     *   sem ter marcado duplicatas específicas): quita as mais antigas primeiro.
     * - `proporcional = true`: aplica a MESMA proporção do valor total em cada parcela
     *   selecionada (ex: se o valor é 50% da soma das selecionadas, cada uma recebe
     *   50% do que falta dela, não só a primeira). É o comportamento certo quando a
     *   pessoa marcou duplicatas específicas e escolheu um percentual: todas elas devem
     *   ficar igualmente parciais, na mesma proporção.
     */
    fun aplicarBaixaConsolidada(
        movimentacoesPorId: Map<String, Movimentacao>,
        selecionadas: List<ParcelaRef>,
        valorPago: Double,
        descricaoManual: String = "",
        dataBaixa: Long = System.currentTimeMillis(),
        proporcional: Boolean = false
    ): Map<String, Movimentacao> {
        val agora = dataBaixa
        // Um único id pra essa transação de baixa inteira, mesmo que ela acabe sendo
        // dividida entre duplicatas de várias movimentações diferentes — é o que permite
        // depois juntar tudo numa linha só no extrato.
        val baixaId = UUID.randomUUID().toString()
        val resultado = mutableMapOf<String, Movimentacao>()
        // agrupa números de parcela e valor aplicado por movimentação, para montar o Pagamento
        val aplicadoPorMovimentacao = mutableMapOf<String, MutableMap<Int, Double>>()

        fun registrarAplicacao(movimentacaoId: String, numeroParcela: Int, valorAplicado: Double, mov: Movimentacao, parcelaAtual: Parcela) {
            val novoValorPago = round((parcelaAtual.valorPago + valorAplicado) * 100) / 100.0
            val novoStatus = if (novoValorPago >= parcelaAtual.valorOriginal - 0.005) "paga" else "parcial"
            val novasParcelas = mov.parcelas.map { p ->
                if (p.numero == numeroParcela) p.copy(valorPago = novoValorPago, status = novoStatus, dataUltimoPagamento = agora) else p
            }
            aplicadoPorMovimentacao.getOrPut(movimentacaoId) { mutableMapOf() }[numeroParcela] = valorAplicado
            resultado[movimentacaoId] = mov.copy(parcelas = novasParcelas)
        }

        if (proporcional) {
            // Descobre o quanto falta em cada parcela selecionada (ignorando as que já
            // estão pagas) e a mesma proporção (valorPago / total faltante) é aplicada
            // em todas elas.
            data class Alvo(val movimentacaoId: String, val numero: Int, val faltante: Double)
            val alvos = selecionadas.mapNotNull { ref ->
                val mov = movimentacoesPorId[ref.movimentacaoId] ?: return@mapNotNull null
                val parcelaAtual = mov.parcelas.firstOrNull { it.numero == ref.parcela.numero } ?: return@mapNotNull null
                if (parcelaAtual.status == "paga") return@mapNotNull null
                val faltante = round((parcelaAtual.valorOriginal - parcelaAtual.valorPago) * 100) / 100.0
                if (faltante <= 0.0) return@mapNotNull null
                Alvo(ref.movimentacaoId, parcelaAtual.numero, faltante)
            }
            val totalFaltante = alvos.sumOf { it.faltante }
            if (totalFaltante > 0.0) {
                val proporcao = (valorPago / totalFaltante).coerceIn(0.0, 1.0)
                var somaAplicada = 0.0
                alvos.forEachIndexed { index, alvo ->
                    val mov = resultado[alvo.movimentacaoId] ?: movimentacoesPorId[alvo.movimentacaoId] ?: return@forEachIndexed
                    val parcelaAtual = mov.parcelas.firstOrNull { it.numero == alvo.numero } ?: return@forEachIndexed
                    // Na última duplicata da lista, joga a diferença de arredondamento nela,
                    // pra a soma aplicada fechar certinho com o valor total informado.
                    val valorAplicado = (if (index == alvos.lastIndex) {
                        round((valorPago - somaAplicada) * 100) / 100.0
                    } else {
                        round(alvo.faltante * proporcao * 100) / 100.0
                    }).coerceIn(0.0, alvo.faltante)
                    somaAplicada = round((somaAplicada + valorAplicado) * 100) / 100.0
                    registrarAplicacao(alvo.movimentacaoId, alvo.numero, valorAplicado, mov, parcelaAtual)
                }
            }
        } else {
            // Preenche na ordem em que aparecem em `selecionadas`, quitando cada uma por
            // completo antes de passar pra próxima.
            var restante = valorPago
            for (ref in selecionadas) {
                if (restante <= 0.0) break
                val mov = resultado[ref.movimentacaoId] ?: movimentacoesPorId[ref.movimentacaoId] ?: continue
                val parcelaAtual = mov.parcelas.firstOrNull { it.numero == ref.parcela.numero } ?: continue
                if (parcelaAtual.status == "paga") continue

                val faltante = round((parcelaAtual.valorOriginal - parcelaAtual.valorPago) * 100) / 100.0
                val valorAplicado = min(restante, faltante)
                restante = round((restante - valorAplicado) * 100) / 100.0
                registrarAplicacao(ref.movimentacaoId, parcelaAtual.numero, valorAplicado, mov, parcelaAtual)
            }
        }

        // adiciona o histórico de pagamento em cada movimentação afetada
        return resultado.mapValues { (movId, mov) ->
            val aplicado = aplicadoPorMovimentacao[movId].orEmpty()
            val numeros = aplicado.keys.sorted()
            val descricaoAuto = buildString {
                append("Baixa de R$ %.2f".format(valorPago))
                if (descricaoManual.isNotBlank()) append(" - $descricaoManual")
                append(". Parcelas ${numeros.joinToString(", ")} desta movimentação.")
            }
            mov.copy(
                historicoPagamentos = mov.historicoPagamentos + Pagamento(
                    id = UUID.randomUUID().toString(),
                    data = agora,
                    valorPago = round(aplicado.values.sum() * 100) / 100.0,
                    parcelasNumeros = numeros,
                    parcelasAplicadas = aplicado.mapKeys { it.key.toString() },
                    descricao = descricaoAuto,
                    baixaId = baixaId
                )
            )
        }
    }

    /**
     * Recalcula só as datas de vencimento das parcelas já existentes, a partir de uma
     * lista "modelo" gerada com a nova data de criação (mesmo algoritmo de sempre) —
     * sem tocar em valor, status ou no que já foi pago em cada uma. Usado pra editar a
     * data de uma movimentação que já tem baixa: nesse caso não dá pra mexer em mais
     * nada além da data (e da descrição), só os vencimentos mudam.
     */
    fun reaplicarVencimentos(parcelasAtuais: List<Parcela>, parcelasComNovasDatas: List<Parcela>): List<Parcela> {
        val novaDataPorNumero = parcelasComNovasDatas.associateBy { it.numero }
        return parcelasAtuais.map { atual ->
            val novaData = novaDataPorNumero[atual.numero]?.dataVencimento ?: atual.dataVencimento
            atual.copy(dataVencimento = novaData)
        }
    }

    /**
     * Edita apenas a data/hora de uma baixa já registrada (não mexe em valores nem em
     * quais parcelas foram afetadas) — atualiza tanto o registro da baixa no histórico
     * quanto o `dataUltimoPagamento` de cada parcela que ela tocou.
     */
    fun editarDataBaixa(movimentacao: Movimentacao, pagamento: Pagamento, novaData: Long): Movimentacao {
        val novasParcelas = movimentacao.parcelas.map { p ->
            if (pagamento.parcelasAplicadas.containsKey(p.numero.toString())) {
                p.copy(dataUltimoPagamento = novaData)
            } else {
                p
            }
        }
        val novoHistorico = movimentacao.historicoPagamentos.map { pag ->
            if (pag.id == pagamento.id) pag.copy(data = novaData) else pag
        }
        return movimentacao.copy(parcelas = novasParcelas, historicoPagamentos = novoHistorico)
    }

    /**
     * Reverte uma baixa específica: tira exatamente o valor que ela aplicou de cada
     * parcela afetada (usando parcelasAplicadas) e remove o registro do histórico.
     */
    fun reverterBaixa(movimentacao: Movimentacao, pagamento: Pagamento): Movimentacao {
        val novasParcelas = movimentacao.parcelas.map { p ->
            val valorAplicado = pagamento.parcelasAplicadas[p.numero.toString()] ?: 0.0
            if (valorAplicado > 0.0) {
                val novoValorPago = (round((p.valorPago - valorAplicado) * 100) / 100.0).coerceAtLeast(0.0)
                val novoStatus = when {
                    novoValorPago <= 0.005 -> "aberta"
                    novoValorPago < p.valorOriginal - 0.005 -> "parcial"
                    else -> "paga"
                }
                p.copy(valorPago = novoValorPago, status = novoStatus)
            } else p
        }
        return movimentacao.copy(
            parcelas = novasParcelas,
            historicoPagamentos = movimentacao.historicoPagamentos.filterNot { it.id == pagamento.id }
        )
    }
}
