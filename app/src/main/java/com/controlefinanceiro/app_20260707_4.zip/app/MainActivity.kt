package com.controlefinanceiro.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.controlefinanceiro.app.data.Categoria
import com.controlefinanceiro.app.data.Cliente
import com.controlefinanceiro.app.data.Movimentacao
import com.controlefinanceiro.app.data.Pagamento
import com.controlefinanceiro.app.ui.components.MiniCalculadora
import com.controlefinanceiro.app.ui.screens.*
import com.controlefinanceiro.app.ui.theme.ControleFinanceiroTheme
import com.controlefinanceiro.app.viewmodel.AppViewModel
import com.google.firebase.auth.FirebaseAuth

// Cole aqui o "Web client ID" (tipo 3 / Web) que aparece em:
// Firebase Console > Authentication > Sign-in method > Google > detalhes do SDK Web
const val WEB_CLIENT_ID = "530471929124-7cntd4equh7obf6dul2dcocm10lpe5tk.apps.googleusercontent.com"

// Hierarquia de navegação: Cliente -> Categoria (ex: "Construção a pagar") ->
// Movimentações (cobranças parceladas dentro da categoria) -> Duplicatas/Baixas.
private sealed class Tela {
    data object Login : Tela()
    data object Clientes : Tela()
    data object VisaoGeral : Tela()
    data object Configuracoes : Tela()
    data class ClienteForm(val cliente: Cliente?) : Tela()
    data class Categorias(val cliente: Cliente) : Tela()
    data class Movimentacoes(val cliente: Cliente, val categoria: Categoria) : Tela()
    data class Entrada(val cliente: Cliente, val categoria: Categoria, val movimentacaoParaEditar: Movimentacao? = null) : Tela()
    data class Saida(val cliente: Cliente, val categoria: Categoria, val movimentacaoIdFiltro: String? = null) : Tela()
    data class MovimentacaoDetalhe(val cliente: Cliente, val categoria: Categoria, val movimentacao: Movimentacao) : Tela()
    data class BaixaDetalhe(val cliente: Cliente, val categoria: Categoria, val itens: List<Pair<Movimentacao, Pagamento>>) : Tela()
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ControleFinanceiroTheme {
                val viewModel: AppViewModel = viewModel()
                var tela by remember {
                    mutableStateOf<Tela>(
                        if (FirebaseAuth.getInstance().currentUser != null) Tela.Clientes else Tela.Login
                    )
                }

                LaunchedEffect(Unit) {
                    if (FirebaseAuth.getInstance().currentUser != null) {
                        viewModel.iniciarEscutaClientes()
                        viewModel.iniciarEscutaCartoes()
                        viewModel.iniciarEscutaConfiguracoes()
                    }
                }

                Box(Modifier.fillMaxSize()) {
                when (val t = tela) {
                    is Tela.Login -> LoginScreen(webClientId = WEB_CLIENT_ID) {
                        viewModel.iniciarEscutaClientes()
                        viewModel.iniciarEscutaCartoes()
                        viewModel.iniciarEscutaConfiguracoes()
                        tela = Tela.Clientes
                    }
                    is Tela.Clientes -> ClientesScreen(
                        viewModel = viewModel,
                        aoAbrirCliente = { tela = Tela.Categorias(it) },
                        aoNovoCliente = { tela = Tela.ClienteForm(null) },
                        aoEditarCliente = { tela = Tela.ClienteForm(it) },
                        aoAbrirVisaoGeral = { tela = Tela.VisaoGeral },
                        aoAbrirConfiguracoes = { tela = Tela.Configuracoes }
                    )
                    is Tela.VisaoGeral -> VisaoGeralScreen(
                        viewModel = viewModel,
                        aoAbrirCliente = { tela = Tela.Categorias(it) },
                        aoVoltar = { tela = Tela.Clientes }
                    )
                    is Tela.Configuracoes -> ConfiguracoesScreen(
                        viewModel = viewModel,
                        aoVoltar = { tela = Tela.Clientes }
                    )
                    is Tela.ClienteForm -> ClienteFormScreen(
                        viewModel = viewModel,
                        clienteExistente = t.cliente,
                        aoVoltar = { tela = Tela.Clientes }
                    )
                    is Tela.Categorias -> CategoriasScreen(
                        viewModel = viewModel,
                        cliente = t.cliente,
                        aoAbrirCategoria = { tela = Tela.Movimentacoes(t.cliente, it) },
                        aoVoltar = { tela = Tela.Clientes }
                    )
                    is Tela.Movimentacoes -> MovimentacoesScreen(
                        viewModel = viewModel,
                        cliente = t.cliente,
                        categoria = t.categoria,
                        aoAbrirMovimentacao = { tela = Tela.MovimentacaoDetalhe(t.cliente, t.categoria, it) },
                        aoAbrirBaixa = { itens -> tela = Tela.BaixaDetalhe(t.cliente, t.categoria, itens) },
                        aoNovaMovimentacao = { tela = Tela.Entrada(t.cliente, t.categoria) },
                        aoDarBaixa = { tela = Tela.Saida(t.cliente, t.categoria) },
                        aoVoltar = { tela = Tela.Categorias(t.cliente) }
                    )
                    is Tela.Entrada -> EntradaScreen(
                        viewModel = viewModel,
                        clienteId = t.cliente.id,
                        categoriaId = t.categoria.id,
                        tipo = t.categoria.tipo,
                        movimentacaoParaEditar = t.movimentacaoParaEditar,
                        aoVoltar = {
                            tela = if (t.movimentacaoParaEditar != null)
                                Tela.MovimentacaoDetalhe(t.cliente, t.categoria, t.movimentacaoParaEditar)
                            else
                                Tela.Movimentacoes(t.cliente, t.categoria)
                        }
                    )
                    is Tela.Saida -> SaidaScreen(
                        viewModel = viewModel,
                        clienteId = t.cliente.id,
                        categoriaId = t.categoria.id,
                        tipo = t.categoria.tipo,
                        movimentacaoIdFiltro = t.movimentacaoIdFiltro,
                        aoVoltar = { tela = Tela.Movimentacoes(t.cliente, t.categoria) }
                    )
                    is Tela.MovimentacaoDetalhe -> MovimentacaoDetalheScreen(
                        viewModel = viewModel,
                        clienteId = t.cliente.id,
                        categoriaId = t.categoria.id,
                        movimentacao = t.movimentacao,
                        aoBaixar = {
                            tela = Tela.Saida(t.cliente, t.categoria, t.movimentacao.id)
                        },
                        aoNovaMovimentacaoMesmoTipo = {
                            tela = Tela.Entrada(t.cliente, t.categoria)
                        },
                        aoEditar = {
                            tela = Tela.Entrada(t.cliente, t.categoria, movimentacaoParaEditar = t.movimentacao)
                        },
                        aoExcluida = { tela = Tela.Movimentacoes(t.cliente, t.categoria) },
                        aoVoltar = { tela = Tela.Movimentacoes(t.cliente, t.categoria) }
                    )
                    is Tela.BaixaDetalhe -> BaixaDetalheScreen(
                        viewModel = viewModel,
                        clienteId = t.cliente.id,
                        categoriaId = t.categoria.id,
                        itens = t.itens,
                        aoExcluida = { tela = Tela.Movimentacoes(t.cliente, t.categoria) },
                        aoVoltar = { tela = Tela.Movimentacoes(t.cliente, t.categoria) }
                    )
                }

                // Mini calculadora flutuante, disponível em todas as telas acima.
                MiniCalculadora(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(top = 64.dp, end = 8.dp)
                )
                }
            }
        }
    }
}
