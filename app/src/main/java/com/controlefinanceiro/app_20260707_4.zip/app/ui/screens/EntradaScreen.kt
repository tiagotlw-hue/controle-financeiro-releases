package com.controlefinanceiro.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.controlefinanceiro.app.data.Cartao
import com.controlefinanceiro.app.data.FormaPagamento
import com.controlefinanceiro.app.data.Movimentacao
import com.controlefinanceiro.app.data.ParcelaUtils
import com.controlefinanceiro.app.data.TipoMovimentacao
import com.controlefinanceiro.app.viewmodel.AppViewModel
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private val fmtData = SimpleDateFormat("dd/MM/yyyy", Locale("pt", "BR"))

/** Cria uma nova movimentação (cobrança parcelada) dentro de uma categoria já existente,
 *  ou edita uma já existente se `movimentacaoParaEditar` for passada (só permitido se
 *  ela ainda não tiver nenhuma baixa). O tipo (a pagar/a receber) vem fixo da categoria. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EntradaScreen(
    viewModel: AppViewModel,
    clienteId: String,
    categoriaId: String,
    tipo: String,
    movimentacaoParaEditar: Movimentacao? = null,
    aoVoltar: () -> Unit
) {
    LaunchedEffect(Unit) {
        viewModel.iniciarEscutaCartoes()
        viewModel.iniciarEscutaConfiguracoes()
    }
    val cartoesDisponiveis by viewModel.cartoes
    val configuracoes by viewModel.configuracoes

    var descricao by remember { mutableStateOf(movimentacaoParaEditar?.descricao ?: "") }
    var usarQuantidade by remember { mutableStateOf(false) }
    var valorTexto by remember { mutableStateOf(movimentacaoParaEditar?.valorTotal?.let { if (it > 0) "%.2f".format(it).replace(".", ",") else "" } ?: "") }
    var quantidadeTexto by remember { mutableStateOf("1") }
    var valorUnitarioTexto by remember { mutableStateOf("") }
    var numParcelasTexto by remember { mutableStateOf(movimentacaoParaEditar?.numParcelas?.toString() ?: "1") }
    var diaVencimentoTexto by remember { mutableStateOf(movimentacaoParaEditar?.diaVencimento?.toString() ?: "15") }
    var dataHoraMillis by remember { mutableStateOf(movimentacaoParaEditar?.dataCriacao ?: System.currentTimeMillis()) }
    var formaPagamento by remember {
        mutableStateOf(movimentacaoParaEditar?.formaPagamento ?: configuracoes.formaPagamentoPadrao)
    }
    var cartaoIdSelecionado by remember {
        mutableStateOf(movimentacaoParaEditar?.cartaoId?.takeIf { it.isNotBlank() } ?: configuracoes.cartaoPadraoId)
    }
    var expandirDropdownCartao by remember { mutableStateOf(false) }
    var salvando by remember { mutableStateOf(false) }
    var tentouSalvar by remember { mutableStateOf(false) }
    val snackbarHostState = remember { SnackbarHostState() }
    val erro = viewModel.erro.value
    val focusRequesterDescricao = remember { FocusRequester() }

    // Abre a tela já com o teclado focado na descrição, pra digitar direto (só na criação).
    LaunchedEffect(Unit) {
        if (movimentacaoParaEditar == null) focusRequesterDescricao.requestFocus()
    }

    LaunchedEffect(erro) {
        if (erro != null) {
            salvando = false
            snackbarHostState.showSnackbar(erro)
            viewModel.limparErro()
        }
    }

    val quantidade = quantidadeTexto.replace(",", ".").toDoubleOrNull() ?: 0.0
    val valorUnitario = valorUnitarioTexto.replace(",", ".").toDoubleOrNull() ?: 0.0
    val valorTotal = if (usarQuantidade) {
        quantidade * valorUnitario
    } else {
        valorTexto.replace(",", ".").toDoubleOrNull() ?: 0.0
    }
    val numParcelas = numParcelasTexto.toIntOrNull()?.coerceAtLeast(1) ?: 1
    val diaVencimento = diaVencimentoTexto.toIntOrNull()?.coerceIn(1, 31) ?: 15
    val cartaoSelecionado = cartoesDisponiveis.firstOrNull { it.id == cartaoIdSelecionado }

    val descricaoInvalida = tentouSalvar && descricao.isBlank()
    val valorInvalido = tentouSalvar && valorTotal <= 0
    val cartaoObrigatorioFaltando = tentouSalvar && formaPagamento == FormaPagamento.CARTAO && cartaoSelecionado == null
    val valido = descricao.isNotBlank() && valorTotal > 0 &&
        (formaPagamento == FormaPagamento.DINHEIRO || cartaoSelecionado != null)

    // Prévia ao vivo: recalcula as duplicatas geradas conforme a pessoa digita.
    val previa = remember(valorTotal, numParcelas, diaVencimento, dataHoraMillis, formaPagamento, cartaoSelecionado) {
        if (valorTotal > 0) {
            try {
                if (formaPagamento == FormaPagamento.CARTAO && cartaoSelecionado != null) {
                    ParcelaUtils.gerarParcelasCartao(valorTotal, numParcelas, dataHoraMillis, cartaoSelecionado.melhorDia, cartaoSelecionado.diaVencimento)
                } else {
                    ParcelaUtils.gerarParcelas(valorTotal, numParcelas, dataHoraMillis, diaVencimento)
                }
            } catch (e: Exception) {
                emptyList()
            }
        } else emptyList()
    }

    val ehEdicao = movimentacaoParaEditar != null

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        when {
                            ehEdicao -> "Editar cobrança"
                            tipo == TipoMovimentacao.RECEBER -> "Nova cobrança (a receber)"
                            else -> "Nova cobrança (a pagar)"
                        }
                    )
                },
                navigationIcon = {
                    IconButton(onClick = aoVoltar) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Cancelar")
                    }
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            OutlinedTextField(
                value = descricao, onValueChange = { descricao = it },
                label = { Text("Descrição *") },
                isError = descricaoInvalida,
                supportingText = { if (descricaoInvalida) Text("Campo obrigatório") },
                modifier = Modifier.fillMaxWidth().focusRequester(focusRequesterDescricao)
            )
            Spacer(Modifier.height(8.dp))

            Row(
                Modifier.fillMaxWidth().clickable { usarQuantidade = !usarQuantidade },
                verticalAlignment = Alignment.CenterVertically
            ) {
                Checkbox(checked = usarQuantidade, onCheckedChange = { usarQuantidade = it })
                Text("Usar quantidade × valor unitário", style = MaterialTheme.typography.bodyMedium)
            }

            if (usarQuantidade) {
                Row {
                    OutlinedTextField(
                        value = quantidadeTexto, onValueChange = { quantidadeTexto = it },
                        label = { Text("Quantidade") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(Modifier.width(8.dp))
                    OutlinedTextField(
                        value = valorUnitarioTexto, onValueChange = { valorUnitarioTexto = it },
                        label = { Text("Valor unitário (R$)") },
                        isError = valorInvalido,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f)
                    )
                }
                Spacer(Modifier.height(4.dp))
                Text(
                    "Valor total: R$ %.2f".format(valorTotal),
                    style = MaterialTheme.typography.bodyMedium,
                    color = if (valorInvalido) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface
                )
                if (valorInvalido) {
                    Text(
                        "Informe quantidade e valor unitário maiores que zero",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error
                    )
                }
            } else {
                OutlinedTextField(
                    value = valorTexto, onValueChange = { valorTexto = it },
                    label = { Text("Valor total (R$) *") },
                    isError = valorInvalido,
                    supportingText = { if (valorInvalido) Text("Informe um valor maior que zero") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth()
                )
            }

            Spacer(Modifier.height(8.dp))
            Row {
                OutlinedTextField(
                    value = numParcelasTexto, onValueChange = { numParcelasTexto = it },
                    label = { Text("Nº de duplicatas") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f)
                )
                Spacer(Modifier.width(8.dp))
                if (formaPagamento == FormaPagamento.DINHEIRO) {
                    OutlinedTextField(
                        value = diaVencimentoTexto, onValueChange = { diaVencimentoTexto = it },
                        label = { Text("Dia venc.") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            Spacer(Modifier.height(12.dp))
            Text("Forma de pagamento", style = MaterialTheme.typography.labelLarge)
            Spacer(Modifier.height(4.dp))
            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                SegmentedButton(
                    selected = formaPagamento == FormaPagamento.DINHEIRO,
                    onClick = { formaPagamento = FormaPagamento.DINHEIRO },
                    shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2)
                ) { Text("Dinheiro") }
                SegmentedButton(
                    selected = formaPagamento == FormaPagamento.CARTAO,
                    onClick = { formaPagamento = FormaPagamento.CARTAO },
                    shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2)
                ) { Text("Cartão") }
            }

            if (formaPagamento == FormaPagamento.CARTAO) {
                Spacer(Modifier.height(8.dp))
                if (cartoesDisponiveis.isEmpty()) {
                    Text(
                        "Nenhum cartão cadastrado. Cadastre um nas Configurações antes de continuar.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error
                    )
                } else {
                    ExposedDropdownMenuBox(
                        expanded = expandirDropdownCartao,
                        onExpandedChange = { expandirDropdownCartao = it }
                    ) {
                        OutlinedTextField(
                            value = cartaoSelecionado?.let { "${it.nome} (fecha dia ${it.melhorDia}, vence dia ${it.diaVencimento})" }
                                ?: "Selecione um cartão",
                            onValueChange = {},
                            readOnly = true,
                            isError = cartaoObrigatorioFaltando,
                            supportingText = { if (cartaoObrigatorioFaltando) Text("Selecione um cartão") },
                            modifier = Modifier.fillMaxWidth().menuAnchor(),
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandirDropdownCartao) }
                        )
                        ExposedDropdownMenu(
                            expanded = expandirDropdownCartao,
                            onDismissRequest = { expandirDropdownCartao = false }
                        ) {
                            cartoesDisponiveis.forEach { cartao ->
                                DropdownMenuItem(
                                    text = { Text("${cartao.nome} (fecha dia ${cartao.melhorDia}, vence dia ${cartao.diaVencimento})") },
                                    onClick = {
                                        cartaoIdSelecionado = cartao.id
                                        expandirDropdownCartao = false
                                    }
                                )
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.height(12.dp))
            Text("Data e hora", style = MaterialTheme.typography.labelLarge)
            Spacer(Modifier.height(4.dp))
            SeletorDataHora(
                dataHoraMillis = dataHoraMillis,
                onDataHoraChange = { dataHoraMillis = it }
            )

            Spacer(Modifier.height(16.dp))
            Text("Prévia das duplicatas", style = MaterialTheme.typography.labelLarge)
            Spacer(Modifier.height(4.dp))
            if (previa.isEmpty()) {
                Text(
                    "Digite um valor para ver a prévia.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                LazyColumn(Modifier.weight(1f)) {
                    items(previa) { p ->
                        ListItem(
                            headlineContent = { Text("Duplicata ${p.numero}/$numParcelas") },
                            supportingContent = { Text("Vence em ${fmtData.format(Date(p.dataVencimento))}") },
                            trailingContent = { Text("R$ %.2f".format(p.valorOriginal)) }
                        )
                        HorizontalDivider()
                    }
                }
            }

            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth()) {
                OutlinedButton(
                    onClick = aoVoltar,
                    enabled = !salvando,
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Cancelar")
                }
                Spacer(Modifier.width(8.dp))
                Button(
                    onClick = {
                        tentouSalvar = true
                        if (!valido) return@Button
                        salvando = true
                        if (ehEdicao) {
                            viewModel.editarMovimentacao(
                                movimentacaoExistente = movimentacaoParaEditar!!,
                                descricao = descricao,
                                valorTotal = valorTotal,
                                numParcelas = numParcelas,
                                diaVencimento = diaVencimento,
                                formaPagamento = formaPagamento,
                                cartao = cartaoSelecionado,
                                dataCriacao = dataHoraMillis
                            ) {
                                salvando = false
                                aoVoltar()
                            }
                        } else {
                            viewModel.criarMovimentacao(
                                clienteId = clienteId,
                                categoriaId = categoriaId,
                                tipo = tipo,
                                descricao = descricao,
                                valorTotal = valorTotal,
                                numParcelas = numParcelas,
                                diaVencimento = diaVencimento,
                                formaPagamento = formaPagamento,
                                cartao = cartaoSelecionado,
                                dataCriacao = dataHoraMillis
                            ) {
                                salvando = false
                                aoVoltar()
                            }
                        }
                    },
                    enabled = !salvando,
                    modifier = Modifier.weight(1f)
                ) {
                    if (salvando) {
                        CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                        Spacer(Modifier.width(8.dp))
                    }
                    Text(if (ehEdicao) "Salvar" else "Confirmar")
                }
            }
        }
    }
}
