package com.controlefinanceiro.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.controlefinanceiro.app.data.Categoria
import com.controlefinanceiro.app.data.Cliente
import com.controlefinanceiro.app.data.Movimentacao
import com.controlefinanceiro.app.data.Pagamento
import com.controlefinanceiro.app.data.Parcela
import com.controlefinanceiro.app.data.TipoMovimentacao
import com.controlefinanceiro.app.viewmodel.AppViewModel
import java.text.SimpleDateFormat
import java.util.Locale

private val fmtData = SimpleDateFormat("dd/MM/yyyy", Locale("pt", "BR"))
private val fmtDataHora = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("pt", "BR"))
private val VerdeSaldo = Color(0xFF2E7D32)
private val VermelhoSaldo = Color(0xFFC62828)

private enum class AbaCategoria { MOVIMENTACOES, EXTRATO }

/** Nível de detalhe mostrado na aba Movimentações:
 *  - PRINCIPAL: só a linha resumo de cada movimentação (com o contador de parcelas).
 *  - PRINCIPAL_BAIXADO: resumo + apenas as duplicatas que já têm alguma baixa
 *    registrada (parcial ou paga), detalhadas e coloridas (valor da duplicata,
 *    valor pago e saldo). Duplicatas ainda em aberto (sem nenhuma baixa) não
 *    aparecem nesse modo.
 *  - PRINCIPAL_PARCELAS: resumo + cada duplicata numa listagem simples (só
 *    número, vencimento e status), sem cores e sem as baixas individualmente. */
private enum class ModoDetalheMovimentacoes(val rotulo: String) {
    PRINCIPAL("Principal"),
    PRINCIPAL_BAIXADO("Principal + baixados"),
    PRINCIPAL_PARCELAS("Principal + parcelas")
}

// Evento de extrato: pode ser a criação de uma cobrança ou uma baixa registrada nela
// — juntos formam a linha do tempo completa da categoria.
private sealed class EventoExtrato(val data: Long) {
    class Criacao(data: Long, val mov: Movimentacao) : EventoExtrato(data)
    /** Uma baixa registrada. Normalmente afeta duplicatas de uma só movimentação, mas
     *  quando o valor pago é dividido entre duplicatas de mais de uma movimentação de
     *  uma vez, [itens] tem mais de um par (mov + pagamento) — todos compartilham o
     *  mesmo baixaId e aparecem juntos aqui, como uma única linha no extrato. */
    class Baixa(data: Long, val itens: List<Pair<Movimentacao, Pagamento>>) : EventoExtrato(data) {
        val valorTotal: Double get() = itens.sumOf { it.second.valorPago }
    }
}

/** Tela "do meio": fica dentro de uma categoria específica (ex: "Construção a pagar")
 *  e lista as movimentações (cobranças parceladas) dela — é aqui que se cria uma nova
 *  movimentação e se registra baixa, sempre dentro do tipo fixo da categoria. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MovimentacoesScreen(
    viewModel: AppViewModel,
    cliente: Cliente,
    categoria: Categoria,
    aoAbrirMovimentacao: (Movimentacao) -> Unit,
    aoAbrirBaixa: (List<Pair<Movimentacao, Pagamento>>) -> Unit,
    aoNovaMovimentacao: () -> Unit,
    aoDarBaixa: () -> Unit,
    aoVoltar: () -> Unit
) {
    LaunchedEffect(cliente.id, categoria.id) { viewModel.observarMovimentacoes(cliente.id, categoria.id) }
    val movimentacoes by viewModel.movimentacoes
    val snackbarHostState = remember { SnackbarHostState() }
    val erro = viewModel.erro.value
    var aba by remember { mutableStateOf(AbaCategoria.MOVIMENTACOES) }
    var mostrarQuitadas by remember { mutableStateOf(false) }
    var modoDetalhe by remember { mutableStateOf(ModoDetalheMovimentacoes.PRINCIPAL) }
    var expandirMenuDetalhe by remember { mutableStateOf(false) }
    var detalharExtrato by remember { mutableStateOf(false) }

    LaunchedEffect(erro) {
        if (erro != null) {
            snackbarHostState.showSnackbar(erro)
            viewModel.limparErro()
        }
    }

    val corCategoria = if (categoria.tipo == TipoMovimentacao.RECEBER) VerdeSaldo else VermelhoSaldo
    val totalEmAberto = movimentacoes.sumOf { it.valorEmAberto }

    val movimentacoesVisiveis = remember(movimentacoes, mostrarQuitadas) {
        if (mostrarQuitadas) movimentacoes else movimentacoes.filterNot { it.quitada }
    }

    val eventosExtrato = remember(movimentacoes) {
        val lista = mutableListOf<EventoExtrato>()
        movimentacoes.forEach { mov -> lista += EventoExtrato.Criacao(mov.dataCriacao, mov) }

        // Agrupa as baixas de todas as movimentações pelo baixaId — assim, uma baixa que
        // cobriu duplicatas de mais de uma movimentação de uma vez aparece como uma única
        // linha no extrato, em vez de uma linha separada por movimentação. Baixas antigas
        // sem baixaId (dados de antes dessa mudança) usam o próprio id do pagamento, então
        // continuam aparecendo individualmente, como já apareciam.
        val baixasPorGrupo = mutableMapOf<String, MutableList<Pair<Movimentacao, Pagamento>>>()
        movimentacoes.forEach { mov ->
            mov.historicoPagamentos.forEach { pag ->
                val chaveGrupo = pag.baixaId.ifBlank { pag.id }
                baixasPorGrupo.getOrPut(chaveGrupo) { mutableListOf() } += mov to pag
            }
        }
        baixasPorGrupo.values.forEach { itens ->
            lista += EventoExtrato.Baixa(itens.first().second.data, itens)
        }

        // Mais recente primeiro.
        lista.sortedByDescending { it.data }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(categoria.nome) },
                navigationIcon = {
                    IconButton(onClick = aoVoltar) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Voltar")
                    }
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        bottomBar = {
            BottomAppBar {
                Button(
                    onClick = aoNovaMovimentacao,
                    modifier = Modifier.weight(1f).padding(horizontal = 8.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null)
                    Spacer(Modifier.width(4.dp))
                    Text("Nova cobrança")
                }
                Button(
                    onClick = aoDarBaixa,
                    modifier = Modifier.weight(1f).padding(horizontal = 8.dp),
                    enabled = movimentacoes.any { it.valorEmAberto > 0.01 }
                ) {
                    Text("Dar baixa")
                }
            }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            Text(
                cliente.nome,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
            )
            Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text(
                        if (categoria.tipo == TipoMovimentacao.RECEBER) "A receber" else "A pagar",
                        style = MaterialTheme.typography.labelLarge,
                        color = corCategoria
                    )
                    Text(
                        "R$ %.2f em aberto".format(totalEmAberto),
                        style = MaterialTheme.typography.headlineMedium,
                        color = corCategoria
                    )
                }
            }
            Spacer(Modifier.height(8.dp))

            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
                SegmentedButton(
                    selected = aba == AbaCategoria.MOVIMENTACOES,
                    onClick = { aba = AbaCategoria.MOVIMENTACOES },
                    shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2)
                ) { Text("Movimentações") }
                SegmentedButton(
                    selected = aba == AbaCategoria.EXTRATO,
                    onClick = { aba = AbaCategoria.EXTRATO },
                    shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2)
                ) { Text("Extrato") }
            }
            Spacer(Modifier.height(4.dp))

            Row(
                Modifier.fillMaxWidth().padding(horizontal = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (aba == AbaCategoria.MOVIMENTACOES) {
                    Row(
                        Modifier.clickable { mostrarQuitadas = !mostrarQuitadas },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(checked = mostrarQuitadas, onCheckedChange = { mostrarQuitadas = it })
                        Text("Mostrar quitadas", style = MaterialTheme.typography.bodySmall)
                    }
                    Box {
                        TextButton(onClick = { expandirMenuDetalhe = true }) {
                            Text(modoDetalhe.rotulo, style = MaterialTheme.typography.bodySmall)
                            Icon(Icons.Default.ArrowDropDown, contentDescription = "Nível de detalhe")
                        }
                        DropdownMenu(
                            expanded = expandirMenuDetalhe,
                            onDismissRequest = { expandirMenuDetalhe = false }
                        ) {
                            ModoDetalheMovimentacoes.values().forEach { modo ->
                                DropdownMenuItem(
                                    text = { Text(modo.rotulo) },
                                    onClick = {
                                        modoDetalhe = modo
                                        expandirMenuDetalhe = false
                                    }
                                )
                            }
                        }
                    }
                } else {
                    Spacer(Modifier.width(1.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Detalhar", style = MaterialTheme.typography.bodySmall)
                        Spacer(Modifier.width(8.dp))
                        Switch(checked = detalharExtrato, onCheckedChange = { detalharExtrato = it })
                    }
                }
            }

            when (aba) {
                AbaCategoria.MOVIMENTACOES -> {
                    if (movimentacoesVisiveis.isEmpty()) {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text(
                                if (movimentacoes.isEmpty())
                                    "Nenhuma movimentação ainda. Toque em \"Nova cobrança\" para lançar a primeira."
                                else
                                    "Nenhuma movimentação em aberto. Marque \"Mostrar quitadas\" para ver as já quitadas.",
                                modifier = Modifier.padding(horizontal = 32.dp)
                            )
                        }
                    } else {
                        LazyColumn(Modifier.fillMaxSize()) {
                            items(movimentacoesVisiveis, key = { it.id }) { mov ->
                                val parcelasPagas = mov.parcelas.count { it.status == "paga" }
                                ListItem(
                                    headlineContent = { Text(mov.descricao) },
                                    supportingContent = {
                                        Column {
                                            Text("Desde ${fmtData.format(java.util.Date(mov.dataCriacao))}")
                                            Text(
                                                if (mov.quitada) "Quitada — R$ %.2f".format(mov.valorTotal)
                                                else "Em aberto: R$ %.2f de R$ %.2f".format(mov.valorEmAberto, mov.valorTotal)
                                            )
                                        }
                                    },
                                    trailingContent = {
                                        Text(
                                            "$parcelasPagas/${mov.numParcelas}",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = if (mov.quitada) VerdeSaldo else MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    },
                                    modifier = Modifier.clickable { aoAbrirMovimentacao(mov) }
                                )
                                HorizontalDivider()

                                // Duplicatas detalhadas e coloridas (modo "Principal + baixados"),
                                // mostrando só as que já receberam alguma baixa (parcial ou paga) —
                                // as que ainda estão em aberto (sem nenhum pagamento) ficam de fora.
                                if (modoDetalhe == ModoDetalheMovimentacoes.PRINCIPAL_BAIXADO) {
                                    mov.parcelas
                                        .filter { it.valorPago > 0.0 }
                                        .sortedBy { it.numero }
                                        .forEach { p ->
                                            LinhaDuplicataDetalhada(parcela = p, numParcelas = mov.numParcelas)
                                            HorizontalDivider()
                                        }
                                }

                                // Duplicatas em listagem simples, sem cores (modo "Principal + parcelas"),
                                // igual à listagem que já existia antes — sem mostrar as baixas individualmente.
                                if (modoDetalhe == ModoDetalheMovimentacoes.PRINCIPAL_PARCELAS) {
                                    mov.parcelas.sortedBy { it.numero }.forEach { p ->
                                        LinhaDuplicataSimples(parcela = p, numParcelas = mov.numParcelas)
                                        HorizontalDivider()
                                    }
                                }
                            }
                        }
                    }
                }

                AbaCategoria.EXTRATO -> {
                    if (eventosExtrato.isEmpty()) {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text("Nenhuma movimentação registrada ainda.")
                        }
                    } else {
                        LazyColumn(Modifier.fillMaxSize()) {
                            items(eventosExtrato) { evento ->
                                when (evento) {
                                    is EventoExtrato.Criacao -> {
                                        // Criação de uma cobrança: do ponto de vista do fluxo de caixa,
                                        // "a receber" é uma Saída (você concedeu o crédito, vermelho e
                                        // negativo) e "a pagar" é uma Entrada (você recebeu o crédito,
                                        // verde e positivo). Sempre alinhada à esquerda, como uma "compra".
                                        val mov = evento.mov
                                        val ehSaida = mov.tipo == TipoMovimentacao.RECEBER
                                        val corEvento = if (ehSaida) VermelhoSaldo else VerdeSaldo
                                        val valorTexto = if (ehSaida) "-R$ %.2f".format(mov.valorTotal) else "R$ %.2f".format(mov.valorTotal)
                                        LinhaEventoExtrato(
                                            titulo = mov.descricao,
                                            valorTexto = valorTexto,
                                            cor = corEvento,
                                            dataTexto = fmtDataHora.format(java.util.Date(evento.data)),
                                            alinharDireita = false,
                                            onClick = { aoAbrirMovimentacao(mov) }
                                        )
                                        HorizontalDivider()
                                    }
                                    is EventoExtrato.Baixa -> {
                                        // Baixa/pagamento registrado: inverte em relação à criação —
                                        // baixa de "a receber" é Entrada (dinheiro chegando, verde e
                                        // positivo), baixa de "a pagar" é Saída (dinheiro saindo,
                                        // vermelho e negativo). Sempre alinhada à direita, como um
                                        // "pagamento". Clicável: abre o detalhe com tudo que essa baixa
                                        // quitou (em uma ou mais movimentações).
                                        val primeiraMov = evento.itens.first().first
                                        val ehSaida = primeiraMov.tipo != TipoMovimentacao.RECEBER
                                        val corEvento = if (ehSaida) VermelhoSaldo else VerdeSaldo
                                        val valorTexto = if (ehSaida)
                                            "-R$ %.2f".format(evento.valorTotal)
                                        else
                                            "R$ %.2f".format(evento.valorTotal)
                                        // Quando a baixa cobriu mais de uma movimentação, mostra os nomes
                                        // delas juntos, menorzinho, embaixo do valor; com uma só, não
                                        // precisa repetir o nome dela aqui.
                                        val descricoes = evento.itens.map { it.first.descricao }.distinct()
                                        val subtitulo = if (descricoes.size > 1) descricoes.joinToString(", ") else null
                                        LinhaEventoExtrato(
                                            titulo = "Pagamento",
                                            subtitulo = subtitulo,
                                            valorTexto = valorTexto,
                                            cor = corEvento,
                                            dataTexto = fmtDataHora.format(java.util.Date(evento.data)),
                                            alinharDireita = true,
                                            onClick = { aoAbrirBaixa(evento.itens) }
                                        )
                                        HorizontalDivider()

                                        // Duplicatas quitadas por essa baixa, detalhadas (só com "Detalhar" ligado),
                                        // percorrendo cada movimentação envolvida nela.
                                        if (detalharExtrato) {
                                            evento.itens.forEach { (mov, pagamento) ->
                                                val numerosQuitados = pagamento.parcelasNumeros.toSet()
                                                mov.parcelas
                                                    .filter { it.numero in numerosQuitados }
                                                    .sortedBy { it.numero }
                                                    .forEach { p ->
                                                        LinhaDuplicataDetalhada(
                                                            parcela = p,
                                                            numParcelas = mov.numParcelas,
                                                            valorPagoNestaBaixa = pagamento.parcelasAplicadas[p.numero.toString()],
                                                            nomeMovimentacao = mov.descricao
                                                        )
                                                        HorizontalDivider()
                                                    }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/** Uma linha do extrato no formato "compra/pagamento": título e valor empilhados e
 *  alinhados à esquerda (compra) ou à direita (pagamento), com a data sempre centralizada
 *  embaixo, ocupando a largura toda — mesmo padrão visual de extratos de fiado/caderneta. */
@Composable
private fun LinhaEventoExtrato(
    titulo: String,
    valorTexto: String,
    cor: Color,
    dataTexto: String,
    alinharDireita: Boolean,
    subtitulo: String? = null,
    onClick: () -> Unit
) {
    Column(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 10.dp)
    ) {
        Box(Modifier.fillMaxWidth()) {
            Column(
                horizontalAlignment = if (alinharDireita) Alignment.End else Alignment.Start,
                modifier = Modifier.align(if (alinharDireita) Alignment.CenterEnd else Alignment.CenterStart)
            ) {
                Text(titulo, color = cor, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium)
                Text(valorTexto, color = cor, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                if (subtitulo != null) {
                    Text(
                        subtitulo,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        style = MaterialTheme.typography.bodySmall,
                        textAlign = if (alinharDireita) TextAlign.End else TextAlign.Start
                    )
                }
            }
        }
        Spacer(Modifier.height(4.dp))
        Text(
            dataTexto,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )
    }
}

/** Linha simples de uma duplicata, sem cores nem valor pago/falta — só número,
 *  vencimento, status textual e o valor original. É a listagem "como já era antes",
 *  usada no modo "Principal + parcelas". */
@Composable
private fun LinhaDuplicataSimples(parcela: Parcela, numParcelas: Int) {
    ListItem(
        headlineContent = { Text("Duplicata ${parcela.numero}/$numParcelas") },
        supportingContent = {
            Text(
                "Vence ${fmtData.format(java.util.Date(parcela.dataVencimento))} — " +
                    when (parcela.status) {
                        "paga" -> "paga"
                        "parcial" -> "parcialmente paga (R$ %.2f de R$ %.2f)".format(parcela.valorPago, parcela.valorOriginal)
                        else -> "em aberto"
                    }
            )
        },
        trailingContent = { Text("R$ %.2f".format(parcela.valorOriginal)) },
        modifier = Modifier.padding(start = 16.dp)
    )
}

/** Linha indentada com o detalhamento colorido de uma duplicata: valor original,
 *  quanto já foi pago (verde) e quanto falta (vermelho), ou "Quitada" (verde) se
 *  não sobrar nada. Se `valorPagoNestaBaixa` for passado (visão do extrato), mostra
 *  quanto especificamente essa baixa aplicou, em vez do total pago na duplicata.
 *  Se `nomeMovimentacao` for passado, mostra o nome da cobrança junto (útil no
 *  extrato, onde a linha não está mais aninhada visualmente sob a movimentação). */
@Composable
private fun LinhaDuplicataDetalhada(
    parcela: Parcela,
    numParcelas: Int,
    valorPagoNestaBaixa: Double? = null,
    nomeMovimentacao: String? = null
) {
    val valorPagoExibido = valorPagoNestaBaixa ?: parcela.valorPago
    val valorQueFalta = (parcela.valorOriginal - parcela.valorPago).coerceAtLeast(0.0)
    Row(
        Modifier.fillMaxWidth().padding(start = 32.dp, end = 16.dp, top = 8.dp, bottom = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(
                if (nomeMovimentacao != null) "$nomeMovimentacao — parcela ${parcela.numero}/$numParcelas"
                else "Duplicata ${parcela.numero}/$numParcelas",
                style = MaterialTheme.typography.bodyMedium
            )
            Text(
                "Vence ${fmtData.format(java.util.Date(parcela.dataVencimento))} • Original: R$ %.2f".format(parcela.valorOriginal),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Column(horizontalAlignment = Alignment.End) {
            Text(
                "Pago: R$ %.2f".format(valorPagoExibido),
                color = VerdeSaldo,
                style = MaterialTheme.typography.bodyMedium
            )
            if (valorQueFalta > 0.01) {
                Text(
                    "Falta: R$ %.2f".format(valorQueFalta),
                    color = VermelhoSaldo,
                    style = MaterialTheme.typography.bodySmall
                )
            } else {
                Text("Quitada", color = VerdeSaldo, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
