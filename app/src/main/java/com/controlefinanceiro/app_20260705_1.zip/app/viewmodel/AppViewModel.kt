package com.controlefinanceiro.app.viewmodel

import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.controlefinanceiro.app.data.Categoria
import com.controlefinanceiro.app.data.Cliente
import com.controlefinanceiro.app.data.FirebaseRepository
import com.controlefinanceiro.app.data.Movimentacao
import com.controlefinanceiro.app.data.ParcelaRef
import com.controlefinanceiro.app.data.ParcelaUtils
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.launch

class AppViewModel : ViewModel() {

    private val repo = FirebaseRepository()

    val clientes = mutableStateOf<List<Cliente>>(emptyList())
    val categorias = mutableStateOf<List<Categoria>>(emptyList())
    val movimentacoes = mutableStateOf<List<Movimentacao>>(emptyList())
    val carregando = mutableStateOf(false)
    val erro = mutableStateOf<String?>(null)

    private var jobClientes: Job? = null
    private var jobCategorias: Job? = null
    private var jobMovimentacoes: Job? = null

    fun usuarioLogado() = repo.usuarioLogado()

    fun limparErro() {
        erro.value = null
    }

    /** Começa a escuta contínua dos clientes. Só deve ser chamada quando já existe um
     *  usuário autenticado (por isso não fica mais no init: instanciar o ViewModel
     *  cedo demais, antes do login, fazia a escuta falhar e nunca mais religar).
     *  Continua funcionando offline normalmente: entrega o cache local na hora e
     *  atualiza sozinho quando sincroniza com o servidor. */
    fun iniciarEscutaClientes() {
        if (jobClientes != null) return // já está escutando, evita duplicar
        jobClientes = viewModelScope.launch {
            repo.escutarClientes()
                .catch { e -> erro.value = e.message }
                .collect { clientes.value = it }
        }
    }

    /** Começa (ou reinicia, se o cliente mudou) a escuta das categorias desse cliente. */
    fun observarCategorias(clienteId: String) {
        jobCategorias?.cancel()
        jobCategorias = viewModelScope.launch {
            repo.escutarCategorias(clienteId)
                .catch { e -> erro.value = e.message }
                .collect { categorias.value = it }
        }
    }

    fun criarCategoria(clienteId: String, nome: String, tipo: String, aoConcluir: () -> Unit = {}) {
        viewModelScope.launch {
            try {
                repo.salvarCategoria(clienteId, Categoria(clienteId = clienteId, nome = nome, tipo = tipo))
                aoConcluir()
            } catch (e: Exception) {
                erro.value = e.message
            }
        }
    }

    fun excluirCategoria(clienteId: String, categoriaId: String, aoConcluir: () -> Unit = {}) {
        viewModelScope.launch {
            try {
                repo.excluirCategoria(clienteId, categoriaId)
                aoConcluir()
            } catch (e: Exception) {
                erro.value = e.message
            }
        }
    }

    /** Começa (ou reinicia, se mudou) a escuta das movimentações de uma categoria. */
    fun observarMovimentacoes(clienteId: String, categoriaId: String) {
        jobMovimentacoes?.cancel()
        jobMovimentacoes = viewModelScope.launch {
            carregando.value = true
            repo.escutarMovimentacoes(clienteId, categoriaId)
                .catch { e ->
                    erro.value = e.message
                    carregando.value = false
                }
                .collect { lista ->
                    movimentacoes.value = lista
                    carregando.value = false
                }
        }
    }

    fun salvarCliente(cliente: Cliente, aoConcluir: () -> Unit = {}) {
        viewModelScope.launch {
            try {
                repo.salvarCliente(cliente)
                aoConcluir()
            } catch (e: Exception) {
                erro.value = e.message
            }
        }
    }

    fun excluirCliente(clienteId: String) {
        viewModelScope.launch {
            try {
                repo.excluirCliente(clienteId)
            } catch (e: Exception) {
                erro.value = e.message
            }
        }
    }

    fun criarMovimentacao(
        clienteId: String,
        categoriaId: String,
        tipo: String,
        descricao: String,
        valorTotal: Double,
        numParcelas: Int,
        diaVencimento: Int,
        dataCriacao: Long = System.currentTimeMillis(),
        aoConcluir: () -> Unit = {}
    ) {
        viewModelScope.launch {
            try {
                val parcelas = ParcelaUtils.gerarParcelas(
                    valorTotal = valorTotal,
                    numParcelas = numParcelas,
                    dataCriacao = dataCriacao,
                    diaVencimento = diaVencimento
                )
                val movimentacao = Movimentacao(
                    clienteId = clienteId,
                    categoriaId = categoriaId,
                    tipo = tipo,
                    descricao = descricao,
                    valorTotal = valorTotal,
                    numParcelas = numParcelas,
                    diaVencimento = diaVencimento,
                    dataCriacao = dataCriacao,
                    parcelas = parcelas
                )
                repo.salvarMovimentacao(clienteId, categoriaId, movimentacao)
                aoConcluir()
            } catch (e: Exception) {
                erro.value = e.message
            }
        }
    }

    fun excluirMovimentacao(clienteId: String, categoriaId: String, movimentacaoId: String, aoConcluir: () -> Unit = {}) {
        viewModelScope.launch {
            try {
                repo.excluirMovimentacao(clienteId, categoriaId, movimentacaoId)
                aoConcluir()
            } catch (e: Exception) {
                erro.value = e.message
            }
        }
    }

    /** Dá baixa distribuindo `valorPago` pelas parcelas selecionadas (de uma ou mais
     *  movimentações da mesma categoria), sempre respeitando a ordem em que foram
     *  passadas (a tela já manda as mais antigas primeiro). */
    fun darBaixa(
        clienteId: String,
        categoriaId: String,
        selecionadas: List<ParcelaRef>,
        valorPago: Double,
        descricaoManual: String,
        aoConcluir: () -> Unit = {}
    ) {
        viewModelScope.launch {
            try {
                val movimentacoesPorId = movimentacoes.value.associateBy { it.id }
                val atualizadas = ParcelaUtils.aplicarBaixaConsolidada(
                    movimentacoesPorId = movimentacoesPorId,
                    selecionadas = selecionadas,
                    valorPago = valorPago,
                    descricaoManual = descricaoManual
                )
                repo.aplicarBaixa(clienteId, categoriaId, atualizadas)
                aoConcluir()
            } catch (e: Exception) {
                erro.value = e.message
            }
        }
    }
}
