package com.controlefinanceiro.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.controlefinanceiro.app.data.ParcelaUtils
import com.controlefinanceiro.app.data.TipoMovimentacao
import com.controlefinanceiro.app.viewmodel.AppViewModel
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private val fmtData = SimpleDateFormat("dd/MM/yyyy", Locale("pt", "BR"))
private val fmtHora = SimpleDateFormat("HH:mm", Locale("pt", "BR"))

/** Cria uma nova movimentação (cobrança parcelada) dentro de uma categoria já existente.
 *  O tipo (a pagar/a receber) vem fixo da categoria — não é escolhido aqui. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EntradaScreen(
    viewModel: AppViewModel,
    clienteId: String,
    categoriaId: String,
    tipo: String,
    aoVoltar: () -> Unit
) {
    var descricao by remember { mutableStateOf("") }
    var valorTexto by remember { mutableStateOf("") }
    var numParcelasTexto by remember { mutableStateOf("1") }
    var diaVencimentoTexto by remember { mutableStateOf("15") }
    // Data/hora da movimentação: já inicializa com o momento atual, mas pode ser alterada.
    var dataHoraMillis by remember { mutableStateOf(System.currentTimeMillis()) }
    var salvando by remember { mutableStateOf(false) }
    var tentouSalvar by remember { mutableStateOf(false) }
    val snackbarHostState = remember { SnackbarHostState() }
    val erro = viewModel.erro.value
    val focusRequesterDescricao = remember { FocusRequester() }

    // Abre a tela já com o teclado focado na descrição, pra digitar direto.
    LaunchedEffect(Unit) {
        focusRequesterDescricao.requestFocus()
    }

    LaunchedEffect(erro) {
        if (erro != null) {
            salvando = false
            snackbarHostState.showSnackbar(erro)
            viewModel.limparErro()
        }
    }

    val valorTotal = valorTexto.replace(",", ".").toDoubleOrNull() ?: 0.0
    val numParcelas = numParcelasTexto.toIntOrNull()?.coerceAtLeast(1) ?: 1
    val diaVencimento = diaVencimentoTexto.toIntOrNull()?.coerceIn(1, 31) ?: 15

    val descricaoInvalida = tentouSalvar && descricao.isBlank()
    val valorInvalido = tentouSalvar && valorTotal <= 0
    val valido = descricao.isNotBlank() && valorTotal > 0

    // Prévia ao vivo: recalcula as duplicatas geradas conforme a pessoa digita,
    // para confirmar antes de salvar de verdade.
    val previa = remember(valorTotal, numParcelas, diaVencimento, dataHoraMillis) {
        if (valorTotal > 0) {
            try {
                ParcelaUtils.gerarParcelas(valorTotal, numParcelas, dataHoraMillis, diaVencimento)
            } catch (e: Exception) {
                emptyList()
            }
        } else emptyList()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (tipo == TipoMovimentacao.RECEBER) "Nova cobrança (a receber)" else "Nova cobrança (a pagar)") },
                navigationIcon = {
                    IconButton(onClick = aoVoltar) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Cancelar")
                    }
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            OutlinedTextField(
                value = descricao, onValueChange = { descricao = it },
                label = { Text("Descrição *") },
                isError = descricaoInvalida,
                supportingText = { if (descricaoInvalida) Text("Campo obrigatório") },
                modifier = Modifier.fillMaxWidth().focusRequester(focusRequesterDescricao)
            )
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = valorTexto, onValueChange = { valorTexto = it },
                label = { Text("Valor total (R$) *") },
                isError = valorInvalido,
                supportingText = { if (valorInvalido) Text("Informe um valor maior que zero") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            Row {
                OutlinedTextField(
                    value = numParcelasTexto, onValueChange = { numParcelasTexto = it },
                    label = { Text("Nº de duplicatas") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f)
                )
                Spacer(Modifier.width(8.dp))
                OutlinedTextField(
                    value = diaVencimentoTexto, onValueChange = { diaVencimentoTexto = it },
                    label = { Text("Dia venc.") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(Modifier.height(12.dp))
            Text("Data e hora", style = MaterialTheme.typography.labelLarge)
            Spacer(Modifier.height(4.dp))
            SeletorDataHora(
                dataHoraMillis = dataHoraMillis,
                onDataHoraChange = { dataHoraMillis = it }
            )

            Spacer(Modifier.height(16.dp))
            Text("Prévia das duplicatas", style = MaterialTheme.typography.labelLarge)
            Spacer(Modifier.height(4.dp))
            if (previa.isEmpty()) {
                Text(
                    "Digite um valor para ver a prévia.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                LazyColumn(Modifier.weight(1f)) {
                    items(previa) { p ->
                        ListItem(
                            headlineContent = { Text("Duplicata ${p.numero}/$numParcelas") },
                            supportingContent = { Text("Vence em ${fmtData.format(Date(p.dataVencimento))}") },
                            trailingContent = { Text("R$ %.2f".format(p.valorOriginal)) }
                        )
                        HorizontalDivider()
                    }
                }
            }

            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth()) {
                OutlinedButton(
                    onClick = aoVoltar,
                    enabled = !salvando,
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Cancelar")
                }
                Spacer(Modifier.width(8.dp))
                Button(
                    onClick = {
                        tentouSalvar = true
                        if (!valido) return@Button
                        salvando = true
                        viewModel.criarMovimentacao(
                            clienteId = clienteId,
                            categoriaId = categoriaId,
                            tipo = tipo,
                            descricao = descricao,
                            valorTotal = valorTotal,
                            numParcelas = numParcelas,
                            diaVencimento = diaVencimento,
                            dataCriacao = dataHoraMillis
                        ) {
                            salvando = false
                            aoVoltar()
                        }
                    },
                    enabled = !salvando,
                    modifier = Modifier.weight(1f)
                ) {
                    if (salvando) {
                        CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                        Spacer(Modifier.width(8.dp))
                    }
                    Text("Confirmar")
                }
            }
        }
    }
}

/** Botões lado a lado pra escolher data e hora, cada um abrindo seu próprio diálogo.
 *  Já chega preenchido com o valor atual de [dataHoraMillis] (padrão: agora). */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SeletorDataHora(
    dataHoraMillis: Long,
    onDataHoraChange: (Long) -> Unit
) {
    var mostrarDatePicker by remember { mutableStateOf(false) }
    var mostrarTimePicker by remember { mutableStateOf(false) }

    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        OutlinedButton(onClick = { mostrarDatePicker = true }, modifier = Modifier.weight(1f)) {
            Text(fmtData.format(Date(dataHoraMillis)))
        }
        Spacer(Modifier.width(8.dp))
        OutlinedButton(onClick = { mostrarTimePicker = true }, modifier = Modifier.weight(1f)) {
            Text(fmtHora.format(Date(dataHoraMillis)))
        }
    }

    if (mostrarDatePicker) {
        val estado = rememberDatePickerState(initialSelectedDateMillis = dataHoraMillis)
        DatePickerDialog(
            onDismissRequest = { mostrarDatePicker = false },
            confirmButton = {
                TextButton(onClick = {
                    estado.selectedDateMillis?.let { novaDataEscolhida ->
                        // Mantém a hora que já estava escolhida, só troca o dia/mês/ano.
                        val calNovo = Calendar.getInstance().apply { timeInMillis = novaDataEscolhida }
                        val calAtual = Calendar.getInstance().apply { timeInMillis = dataHoraMillis }
                        calNovo.set(Calendar.HOUR_OF_DAY, calAtual.get(Calendar.HOUR_OF_DAY))
                        calNovo.set(Calendar.MINUTE, calAtual.get(Calendar.MINUTE))
                        onDataHoraChange(calNovo.timeInMillis)
                    }
                    mostrarDatePicker = false
                }) { Text("OK") }
            },
            dismissButton = {
                TextButton(onClick = { mostrarDatePicker = false }) { Text("Cancelar") }
            }
        ) {
            DatePicker(state = estado)
        }
    }

    if (mostrarTimePicker) {
        val calAtual = remember { Calendar.getInstance().apply { timeInMillis = dataHoraMillis } }
        val estado = rememberTimePickerState(
            initialHour = calAtual.get(Calendar.HOUR_OF_DAY),
            initialMinute = calAtual.get(Calendar.MINUTE),
            is24Hour = true
        )
        AlertDialog(
            onDismissRequest = { mostrarTimePicker = false },
            title = { Text("Escolha o horário") },
            text = { TimePicker(state = estado) },
            confirmButton = {
                TextButton(onClick = {
                    val calNovo = Calendar.getInstance().apply { timeInMillis = dataHoraMillis }
                    calNovo.set(Calendar.HOUR_OF_DAY, estado.hour)
                    calNovo.set(Calendar.MINUTE, estado.minute)
                    onDataHoraChange(calNovo.timeInMillis)
                    mostrarTimePicker = false
                }) { Text("OK") }
            },
            dismissButton = {
                TextButton(onClick = { mostrarTimePicker = false }) { Text("Cancelar") }
            }
        )
    }
}
