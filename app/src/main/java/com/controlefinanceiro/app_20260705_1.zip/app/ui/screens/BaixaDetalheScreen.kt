package com.controlefinanceiro.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.controlefinanceiro.app.data.Movimentacao
import com.controlefinanceiro.app.data.Pagamento
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val fmtData = SimpleDateFormat("dd/MM/yyyy", Locale("pt", "BR"))
private val fmtDataHora = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("pt", "BR"))

/** Tela simples que mostra apenas as duplicatas quitadas por uma baixa específica
 *  (aberta a partir do extrato do cliente, ao tocar num evento de Entrada/Saída de baixa). */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BaixaDetalheScreen(
    movimentacao: Movimentacao,
    pagamento: Pagamento,
    aoVoltar: () -> Unit
) {
    val duplicatasQuitadas = movimentacao.parcelas
        .filter { it.numero in pagamento.parcelasNumeros }
        .sortedBy { it.numero }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Detalhe da baixa") },
                navigationIcon = {
                    IconButton(onClick = aoVoltar) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Voltar")
                    }
                }
            )
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            Text(movimentacao.descricao, style = MaterialTheme.typography.titleMedium)
            Text(
                "R$ %.2f".format(pagamento.valorPago),
                style = MaterialTheme.typography.headlineMedium
            )
            Text(
                fmtDataHora.format(Date(pagamento.data)),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            if (pagamento.descricao.isNotBlank()) {
                Spacer(Modifier.height(8.dp))
                Text(pagamento.descricao, style = MaterialTheme.typography.bodyMedium)
            }

            Spacer(Modifier.height(16.dp))
            Text("Duplicatas quitadas nesta baixa", style = MaterialTheme.typography.labelLarge)
            Spacer(Modifier.height(4.dp))

            if (duplicatasQuitadas.isEmpty()) {
                Text(
                    "Nenhuma duplicata encontrada para esta baixa.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            } else {
                LazyColumn(Modifier.weight(1f)) {
                    items(duplicatasQuitadas) { p ->
                        ListItem(
                            headlineContent = { Text("Duplicata ${p.numero}/${movimentacao.numParcelas}") },
                            supportingContent = {
                                Text("Vencia ${fmtData.format(Date(p.dataVencimento))} — R$ %.2f".format(p.valorOriginal))
                            },
                            trailingContent = {
                                Text(if (p.status == "paga") "Paga" else "Parcial")
                            }
                        )
                        HorizontalDivider()
                    }
                }
            }
        }
    }
}
