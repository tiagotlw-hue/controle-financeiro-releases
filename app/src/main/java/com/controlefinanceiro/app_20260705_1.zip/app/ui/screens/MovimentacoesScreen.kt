package com.controlefinanceiro.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.controlefinanceiro.app.data.Categoria
import com.controlefinanceiro.app.data.Cliente
import com.controlefinanceiro.app.data.Movimentacao
import com.controlefinanceiro.app.data.Pagamento
import com.controlefinanceiro.app.data.TipoMovimentacao
import com.controlefinanceiro.app.viewmodel.AppViewModel
import java.text.SimpleDateFormat
import java.util.Locale

private val fmtData = SimpleDateFormat("dd/MM/yyyy", Locale("pt", "BR"))
private val fmtDataHora = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("pt", "BR"))
private val VerdeSaldo = Color(0xFF2E7D32)
private val VermelhoSaldo = Color(0xFFC62828)

private enum class AbaCategoria { MOVIMENTACOES, EXTRATO }

// Evento de extrato: pode ser a criação de uma cobrança ou uma baixa registrada nela
// — juntos formam a linha do tempo completa da categoria.
private sealed class EventoExtrato(val data: Long) {
    class Criacao(data: Long, val mov: Movimentacao) : EventoExtrato(data)
    class Baixa(data: Long, val mov: Movimentacao, val pagamento: Pagamento) : EventoExtrato(data)
}

/** Tela "do meio": fica dentro de uma categoria específica (ex: "Construção a pagar")
 *  e lista as movimentações (cobranças parceladas) dela — é aqui que se cria uma nova
 *  movimentação e se registra baixa, sempre dentro do tipo fixo da categoria. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MovimentacoesScreen(
    viewModel: AppViewModel,
    cliente: Cliente,
    categoria: Categoria,
    aoAbrirMovimentacao: (Movimentacao) -> Unit,
    aoAbrirBaixa: (Movimentacao, Pagamento) -> Unit,
    aoNovaMovimentacao: () -> Unit,
    aoDarBaixa: () -> Unit,
    aoVoltar: () -> Unit
) {
    LaunchedEffect(cliente.id, categoria.id) { viewModel.observarMovimentacoes(cliente.id, categoria.id) }
    val movimentacoes by viewModel.movimentacoes
    val snackbarHostState = remember { SnackbarHostState() }
    val erro = viewModel.erro.value
    var aba by remember { mutableStateOf(AbaCategoria.MOVIMENTACOES) }
    var mostrarQuitadas by remember { mutableStateOf(false) }

    LaunchedEffect(erro) {
        if (erro != null) {
            snackbarHostState.showSnackbar(erro)
            viewModel.limparErro()
        }
    }

    val corCategoria = if (categoria.tipo == TipoMovimentacao.RECEBER) VerdeSaldo else VermelhoSaldo
    val totalEmAberto = movimentacoes.sumOf { it.valorEmAberto }

    val movimentacoesVisiveis = remember(movimentacoes, mostrarQuitadas) {
        if (mostrarQuitadas) movimentacoes else movimentacoes.filterNot { it.quitada }
    }

    val eventosExtrato = remember(movimentacoes) {
        val lista = mutableListOf<EventoExtrato>()
        movimentacoes.forEach { mov ->
            lista += EventoExtrato.Criacao(mov.dataCriacao, mov)
            mov.historicoPagamentos.forEach { pag -> lista += EventoExtrato.Baixa(pag.data, mov, pag) }
        }
        lista.sortedByDescending { it.data }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(categoria.nome) },
                navigationIcon = {
                    IconButton(onClick = aoVoltar) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Voltar")
                    }
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        bottomBar = {
            BottomAppBar {
                Button(
                    onClick = aoNovaMovimentacao,
                    modifier = Modifier.weight(1f).padding(horizontal = 8.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null)
                    Spacer(Modifier.width(4.dp))
                    Text("Nova cobrança")
                }
                Button(
                    onClick = aoDarBaixa,
                    modifier = Modifier.weight(1f).padding(horizontal = 8.dp),
                    enabled = movimentacoes.any { it.valorEmAberto > 0.01 }
                ) {
                    Text("Dar baixa")
                }
            }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            Text(
                cliente.nome,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
            )
            Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text(
                        if (categoria.tipo == TipoMovimentacao.RECEBER) "A receber" else "A pagar",
                        style = MaterialTheme.typography.labelLarge,
                        color = corCategoria
                    )
                    Text(
                        "R$ %.2f em aberto".format(totalEmAberto),
                        style = MaterialTheme.typography.headlineMedium,
                        color = corCategoria
                    )
                }
            }
            Spacer(Modifier.height(8.dp))

            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
                SegmentedButton(
                    selected = aba == AbaCategoria.MOVIMENTACOES,
                    onClick = { aba = AbaCategoria.MOVIMENTACOES },
                    shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2)
                ) { Text("Movimentações") }
                SegmentedButton(
                    selected = aba == AbaCategoria.EXTRATO,
                    onClick = { aba = AbaCategoria.EXTRATO },
                    shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2)
                ) { Text("Extrato") }
            }
            Spacer(Modifier.height(8.dp))

            when (aba) {
                AbaCategoria.MOVIMENTACOES -> {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 16.dp).clickable { mostrarQuitadas = !mostrarQuitadas },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(checked = mostrarQuitadas, onCheckedChange = { mostrarQuitadas = it })
                        Text("Mostrar quitadas", style = MaterialTheme.typography.bodySmall)
                    }

                    if (movimentacoesVisiveis.isEmpty()) {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text(
                                if (movimentacoes.isEmpty())
                                    "Nenhuma movimentação ainda. Toque em \"Nova cobrança\" para lançar a primeira."
                                else
                                    "Nenhuma movimentação em aberto. Marque \"Mostrar quitadas\" para ver as já quitadas.",
                                modifier = Modifier.padding(horizontal = 32.dp)
                            )
                        }
                    } else {
                        LazyColumn(Modifier.fillMaxSize()) {
                            items(movimentacoesVisiveis, key = { it.id }) { mov ->
                                ListItem(
                                    headlineContent = { Text(mov.descricao) },
                                    supportingContent = {
                                        Column {
                                            Text("Desde ${fmtData.format(java.util.Date(mov.dataCriacao))}")
                                            Text(
                                                if (mov.quitada) "Quitada — R$ %.2f".format(mov.valorTotal)
                                                else "Em aberto: R$ %.2f de R$ %.2f".format(mov.valorEmAberto, mov.valorTotal)
                                            )
                                        }
                                    },
                                    modifier = Modifier.clickable { aoAbrirMovimentacao(mov) }
                                )
                                HorizontalDivider()
                            }
                        }
                    }
                }

                AbaCategoria.EXTRATO -> {
                    if (eventosExtrato.isEmpty()) {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text("Nenhuma movimentação registrada ainda.")
                        }
                    } else {
                        LazyColumn(Modifier.fillMaxSize()) {
                            items(eventosExtrato) { evento ->
                                when (evento) {
                                    is EventoExtrato.Criacao -> {
                                        // Criação de uma cobrança: do ponto de vista do fluxo de caixa,
                                        // "a receber" é uma Saída (você concedeu o crédito) e
                                        // "a pagar" é uma Entrada (você recebeu o crédito).
                                        val mov = evento.mov
                                        val rotulo = if (mov.tipo == TipoMovimentacao.RECEBER) "Saída" else "Entrada"
                                        val icone = if (rotulo == "Entrada") Icons.Default.ArrowDownward else Icons.Default.ArrowUpward
                                        ListItem(
                                            leadingContent = {
                                                Icon(icone, contentDescription = null, tint = corCategoria)
                                            },
                                            headlineContent = { Text("$rotulo — ${mov.descricao}") },
                                            supportingContent = {
                                                Text(fmtDataHora.format(java.util.Date(evento.data)))
                                            },
                                            trailingContent = {
                                                Text("R$ %.2f".format(mov.valorTotal), color = corCategoria)
                                            },
                                            modifier = Modifier.clickable { aoAbrirMovimentacao(mov) }
                                        )
                                    }
                                    is EventoExtrato.Baixa -> {
                                        // Baixa/pagamento registrado: inverte em relação à criação —
                                        // baixa de "a receber" é Entrada (dinheiro chegando), baixa de
                                        // "a pagar" é Saída (dinheiro saindo). Clicável: abre só as
                                        // duplicatas que essa baixa específica quitou.
                                        val mov = evento.mov
                                        val rotulo = if (mov.tipo == TipoMovimentacao.RECEBER) "Entrada" else "Saída"
                                        val icone = if (rotulo == "Entrada") Icons.Default.ArrowDownward else Icons.Default.ArrowUpward
                                        ListItem(
                                            leadingContent = {
                                                Icon(icone, contentDescription = null, tint = corCategoria)
                                            },
                                            headlineContent = { Text("$rotulo — ${mov.descricao}") },
                                            supportingContent = {
                                                Text(fmtDataHora.format(java.util.Date(evento.data)))
                                            },
                                            trailingContent = {
                                                Text("R$ %.2f".format(evento.pagamento.valorPago), color = corCategoria)
                                            },
                                            modifier = Modifier.clickable { aoAbrirBaixa(mov, evento.pagamento) }
                                        )
                                    }
                                }
                                HorizontalDivider()
                            }
                        }
                    }
                }
            }
        }
    }
}
