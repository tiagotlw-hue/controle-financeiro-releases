package com.controlefinanceiro.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.controlefinanceiro.app.data.Categoria
import com.controlefinanceiro.app.data.Cliente
import com.controlefinanceiro.app.data.TipoMovimentacao
import com.controlefinanceiro.app.viewmodel.AppViewModel

private val VerdeSaldo = Color(0xFF2E7D32)
private val VermelhoSaldo = Color(0xFFC62828)

/** Primeira tela ao entrar num cliente: lista as "contas" (categorias) dele, tipo
 *  "Construção a pagar", "Mercado a pagar", "Empréstimo a receber". Cada categoria
 *  agrupa várias movimentações. Essa tela NÃO cria movimentação nenhuma — só cria
 *  a categoria em si; as movimentações são criadas de dentro da categoria. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CategoriasScreen(
    viewModel: AppViewModel,
    cliente: Cliente,
    aoAbrirCategoria: (Categoria) -> Unit,
    aoVoltar: () -> Unit
) {
    LaunchedEffect(cliente.id) { viewModel.observarCategorias(cliente.id) }
    val categorias by viewModel.categorias
    val snackbarHostState = remember { SnackbarHostState() }
    val erro = viewModel.erro.value
    var mostrarNovaCategoria by remember { mutableStateOf(false) }
    var categoriaParaExcluir by remember { mutableStateOf<Categoria?>(null) }

    LaunchedEffect(erro) {
        if (erro != null) {
            snackbarHostState.showSnackbar(erro)
            viewModel.limparErro()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(cliente.nome) },
                navigationIcon = {
                    IconButton(onClick = aoVoltar) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Voltar")
                    }
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        floatingActionButton = {
            FloatingActionButton(onClick = { mostrarNovaCategoria = true }) {
                Icon(Icons.Default.Add, contentDescription = "Nova categoria")
            }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            Card(Modifier.fillMaxWidth().padding(16.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text("Saldo do cliente", style = MaterialTheme.typography.labelLarge)
                    Text(
                        "R$ %.2f".format(cliente.saldo),
                        style = MaterialTheme.typography.headlineMedium,
                        color = if (cliente.saldo >= 0) VerdeSaldo else VermelhoSaldo
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("A receber: R$ %.2f".format(cliente.totalAReceber), color = VerdeSaldo, style = MaterialTheme.typography.bodyMedium)
                        Text("A pagar: R$ %.2f".format(cliente.totalAPagar), color = VermelhoSaldo, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }

            if (categorias.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(
                        "Nenhuma categoria ainda. Toque em + para criar, ex: \"Construção a pagar\".",
                        modifier = Modifier.padding(horizontal = 32.dp)
                    )
                }
            } else {
                LazyColumn(Modifier.fillMaxSize()) {
                    items(categorias, key = { it.id }) { categoria ->
                        val cor = if (categoria.tipo == TipoMovimentacao.RECEBER) VerdeSaldo else VermelhoSaldo
                        ListItem(
                            headlineContent = { Text(categoria.nome) },
                            supportingContent = {
                                Text(
                                    if (categoria.tipo == TipoMovimentacao.RECEBER) "A receber" else "A pagar",
                                    color = cor
                                )
                            },
                            trailingContent = {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        "R$ %.2f".format(categoria.totalAberto),
                                        style = MaterialTheme.typography.bodyMedium
                                    )
                                    IconButton(onClick = { categoriaParaExcluir = categoria }) {
                                        Icon(Icons.Default.Delete, contentDescription = "Excluir categoria")
                                    }
                                }
                            },
                            modifier = Modifier.clickable { aoAbrirCategoria(categoria) }
                        )
                        HorizontalDivider()
                    }
                }
            }
        }
    }

    if (mostrarNovaCategoria) {
        NovaCategoriaDialog(
            onConfirmar = { nome, tipo ->
                viewModel.criarCategoria(cliente.id, nome, tipo) {
                    mostrarNovaCategoria = false
                }
            },
            onCancelar = { mostrarNovaCategoria = false }
        )
    }

    categoriaParaExcluir?.let { categoria ->
        AlertDialog(
            onDismissRequest = { categoriaParaExcluir = null },
            title = { Text("Excluir categoria") },
            text = {
                Text(
                    "Tem certeza que deseja excluir \"${categoria.nome}\"? Todas as movimentações, " +
                        "duplicatas e baixas dentro dela serão perdidas. Essa ação não pode ser desfeita."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.excluirCategoria(cliente.id, categoria.id)
                    categoriaParaExcluir = null
                }) { Text("Excluir") }
            },
            dismissButton = {
                TextButton(onClick = { categoriaParaExcluir = null }) { Text("Cancelar") }
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun NovaCategoriaDialog(
    onConfirmar: (nome: String, tipo: String) -> Unit,
    onCancelar: () -> Unit
) {
    var nome by remember { mutableStateOf("") }
    var tipo by remember { mutableStateOf(TipoMovimentacao.RECEBER) }
    var tentouSalvar by remember { mutableStateOf(false) }
    val nomeInvalido = tentouSalvar && nome.isBlank()

    AlertDialog(
        onDismissRequest = onCancelar,
        title = { Text("Nova categoria") },
        text = {
            Column {
                OutlinedTextField(
                    value = nome,
                    onValueChange = { nome = it },
                    label = { Text("Nome (ex: Construção) *") },
                    isError = nomeInvalido,
                    supportingText = { if (nomeInvalido) Text("Campo obrigatório") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(12.dp))
                SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                    SegmentedButton(
                        selected = tipo == TipoMovimentacao.RECEBER,
                        onClick = { tipo = TipoMovimentacao.RECEBER },
                        shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2)
                    ) { Text("A receber") }
                    SegmentedButton(
                        selected = tipo == TipoMovimentacao.PAGAR,
                        onClick = { tipo = TipoMovimentacao.PAGAR },
                        shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2)
                    ) { Text("A pagar") }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                tentouSalvar = true
                if (nome.isNotBlank()) onConfirmar(nome, tipo)
            }) { Text("Criar") }
        },
        dismissButton = {
            TextButton(onClick = onCancelar) { Text("Cancelar") }
        }
    )
}
