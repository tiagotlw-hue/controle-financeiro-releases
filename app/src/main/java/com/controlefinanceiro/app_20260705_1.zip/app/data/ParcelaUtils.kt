package com.controlefinanceiro.app.data

import java.util.Calendar
import kotlin.math.min
import kotlin.math.round

object ParcelaUtils {

    /**
     * Gera as parcelas/duplicatas de uma movimentação (a pagar ou a receber).
     * Cada parcela vence sempre no mesmo "diaVencimento" (ex: dia 15),
     * começando no mês seguinte à criação. Se o mês não tiver esse dia
     * (ex: dia 31 em fevereiro), usa o último dia do mês.
     * A diferença de arredondamento é jogada na última parcela.
     */
    fun gerarParcelas(
        valorTotal: Double,
        numParcelas: Int,
        dataCriacao: Long,
        diaVencimento: Int
    ): List<Parcela> {
        require(numParcelas >= 1) { "Número de parcelas deve ser >= 1" }
        val valorParcelaBase = round((valorTotal / numParcelas) * 100) / 100.0
        val calendarBase = Calendar.getInstance().apply { timeInMillis = dataCriacao }

        val parcelas = mutableListOf<Parcela>()
        var somaAcumulada = 0.0

        for (i in 1..numParcelas) {
            val cal = calendarBase.clone() as Calendar
            cal.add(Calendar.MONTH, i)
            val ultimoDiaDoMes = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
            cal.set(Calendar.DAY_OF_MONTH, min(diaVencimento, ultimoDiaDoMes))
            cal.set(Calendar.HOUR_OF_DAY, 0)
            cal.set(Calendar.MINUTE, 0)
            cal.set(Calendar.SECOND, 0)
            cal.set(Calendar.MILLISECOND, 0)

            val valorDaParcela = if (i == numParcelas) {
                round((valorTotal - somaAcumulada) * 100) / 100.0
            } else {
                valorParcelaBase
            }
            somaAcumulada += valorDaParcela

            parcelas.add(
                Parcela(
                    numero = i,
                    valorOriginal = valorDaParcela,
                    dataVencimento = cal.timeInMillis
                )
            )
        }
        return parcelas
    }

    /**
     * Dado o valor digitado, seleciona automaticamente as parcelas em aberto mais antigas
     * (já ordenadas) até esse valor se esgotar. Usado tanto para pré-seleção automática
     * quanto para saber o total das parcelas marcadas manualmente.
     */
    fun selecionarMaisAntigasAte(abertasOrdenadas: List<ParcelaRef>, valor: Double): Set<Pair<String, Int>> {
        val selecionadas = mutableSetOf<Pair<String, Int>>()
        var restante = valor
        for (ref in abertasOrdenadas) {
            if (restante <= 0.0) break
            val faltante = round((ref.parcela.valorOriginal - ref.parcela.valorPago) * 100) / 100.0
            selecionadas.add(ref.movimentacaoId to ref.parcela.numero)
            restante -= faltante
        }
        return selecionadas
    }

    /**
     * Aplica uma baixa (pagamento/recebimento) espalhando o valor pelas parcelas
     * selecionadas, na ordem em que aparecem em `selecionadas`. Parcelas de várias
     * movimentações podem estar envolvidas (por isso o retorno é um mapa por movimentação).
     * Se o valor não cobrir tudo, a última parcela fica "parcial".
     */
    fun aplicarBaixaConsolidada(
        movimentacoesPorId: Map<String, Movimentacao>,
        selecionadas: List<ParcelaRef>,
        valorPago: Double,
        descricaoManual: String = ""
    ): Map<String, Movimentacao> {
        var restante = valorPago
        val agora = System.currentTimeMillis()
        val resultado = mutableMapOf<String, Movimentacao>()
        // agrupa números de parcela aplicados por movimentação, para montar o registro de Pagamento
        val numerosAplicadosPorMovimentacao = mutableMapOf<String, MutableList<Int>>()
        var valorTotalAplicado = 0.0

        for (ref in selecionadas) {
            if (restante <= 0.0) break
            val mov = resultado[ref.movimentacaoId] ?: movimentacoesPorId[ref.movimentacaoId] ?: continue
            val parcelaAtual = mov.parcelas.firstOrNull { it.numero == ref.parcela.numero } ?: continue
            if (parcelaAtual.status == "paga") continue

            val faltante = round((parcelaAtual.valorOriginal - parcelaAtual.valorPago) * 100) / 100.0
            val valorAplicado = min(restante, faltante)
            restante = round((restante - valorAplicado) * 100) / 100.0
            valorTotalAplicado = round((valorTotalAplicado + valorAplicado) * 100) / 100.0

            val novoValorPago = round((parcelaAtual.valorPago + valorAplicado) * 100) / 100.0
            val novoStatus = if (novoValorPago >= parcelaAtual.valorOriginal - 0.005) "paga" else "parcial"

            val novasParcelas = mov.parcelas.map { p ->
                if (p.numero == parcelaAtual.numero) {
                    p.copy(valorPago = novoValorPago, status = novoStatus, dataUltimoPagamento = agora)
                } else p
            }
            numerosAplicadosPorMovimentacao.getOrPut(ref.movimentacaoId) { mutableListOf() }.add(parcelaAtual.numero)
            resultado[ref.movimentacaoId] = mov.copy(parcelas = novasParcelas)
        }

        // adiciona o histórico de pagamento em cada movimentação afetada
        return resultado.mapValues { (movId, mov) ->
            val numeros = numerosAplicadosPorMovimentacao[movId].orEmpty()
            val descricaoAuto = buildString {
                append("Baixa de R$ %.2f".format(valorPago))
                if (descricaoManual.isNotBlank()) append(" - $descricaoManual")
                append(". Parcelas ${numeros.joinToString(", ")} desta movimentação.")
            }
            mov.copy(
                historicoPagamentos = mov.historicoPagamentos + Pagamento(
                    data = agora,
                    valorPago = valorTotalAplicado,
                    parcelasNumeros = numeros,
                    descricao = descricaoAuto
                )
            )
        }
    }
}
